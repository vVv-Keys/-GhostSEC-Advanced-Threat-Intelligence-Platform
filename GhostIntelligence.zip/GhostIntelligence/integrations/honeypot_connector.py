"""
Honeypot Integration Module
Real-time ingestion from honeypots and security sensors
"""

import asyncio
import aiohttp
import json
from datetime import datetime
from typing import Dict, List
import logging
import hashlib
from flask import Flask, request, jsonify

class HoneypotConnector:
    def __init__(self, webhook_port=5001):
        self.logger = logging.getLogger(__name__)
        self.webhook_port = webhook_port
        self.app = Flask(__name__)
        self.threat_queue = asyncio.Queue()
        self.setup_webhook_routes()
        
    def setup_webhook_routes(self):
        """Setup webhook endpoints for honeypot data ingestion"""
        
        @self.app.route('/webhook/cowrie', methods=['POST'])
        def cowrie_webhook():
            """Cowrie SSH/Telnet honeypot webhook"""
            try:
                data = request.get_json()
                threat = self.parse_cowrie_event(data)
                if threat:
                    self.threat_queue.put_nowait(threat)
                    return jsonify({'status': 'received', 'threat_id': threat.get('hash')})
                return jsonify({'status': 'ignored'})
            except Exception as e:
                self.logger.error(f"Cowrie webhook error: {e}")
                return jsonify({'error': str(e)}), 400
        
        @self.app.route('/webhook/dionaea', methods=['POST'])
        def dionaea_webhook():
            """Dionaea malware honeypot webhook"""
            try:
                data = request.get_json()
                threat = self.parse_dionaea_event(data)
                if threat:
                    self.threat_queue.put_nowait(threat)
                    return jsonify({'status': 'received', 'threat_id': threat.get('hash')})
                return jsonify({'status': 'ignored'})
            except Exception as e:
                self.logger.error(f"Dionaea webhook error: {e}")
                return jsonify({'error': str(e)}), 400
        
        @self.app.route('/webhook/generic', methods=['POST'])
        def generic_webhook():
            """Generic honeypot/sensor webhook"""
            try:
                data = request.get_json()
                threat = self.parse_generic_event(data)
                if threat:
                    self.threat_queue.put_nowait(threat)
                    return jsonify({'status': 'received', 'threat_id': threat.get('hash')})
                return jsonify({'status': 'ignored'})
            except Exception as e:
                self.logger.error(f"Generic webhook error: {e}")
                return jsonify({'error': str(e)}), 400
        
        @self.app.route('/webhook/dshield', methods=['POST'])
        def dshield_webhook():
            """DShield log submission webhook"""
            try:
                data = request.get_json()
                threat = self.parse_dshield_event(data)
                if threat:
                    self.threat_queue.put_nowait(threat)
                    return jsonify({'status': 'received', 'threat_id': threat.get('hash')})
                return jsonify({'status': 'ignored'})
            except Exception as e:
                self.logger.error(f"DShield webhook error: {e}")
                return jsonify({'error': str(e)}), 400
        
        @self.app.route('/health', methods=['GET'])
        def health_check():
            """Health check endpoint"""
            return jsonify({
                'status': 'healthy',
                'queue_size': self.threat_queue.qsize(),
                'timestamp': datetime.utcnow().isoformat()
            })
    
    def parse_cowrie_event(self, data: Dict) -> Dict:
        """Parse Cowrie honeypot event"""
        try:
            event_id = data.get('eventid', '')
            
            # Filter for relevant events
            relevant_events = [
                'cowrie.login.success',
                'cowrie.login.failed',
                'cowrie.command.input',
                'cowrie.session.file_download',
                'cowrie.session.file_upload'
            ]
            
            if event_id not in relevant_events:
                return None
            
            src_ip = data.get('src_ip', '')
            username = data.get('username', '')
            password = data.get('password', '')
            command = data.get('input', '')
            
            # Create threat from honeypot data
            threat_id = hashlib.md5(f"cowrie_{src_ip}_{event_id}_{data.get('timestamp', '')}".encode()).hexdigest()
            
            # Determine severity based on event type
            severity_map = {
                'cowrie.login.success': 'high',
                'cowrie.session.file_download': 'critical',
                'cowrie.session.file_upload': 'critical',
                'cowrie.command.input': 'medium',
                'cowrie.login.failed': 'low'
            }
            
            description = f"Honeypot activity detected from {src_ip}. "
            if username and password:
                description += f"Login attempt: {username}:{password}. "
            if command:
                description += f"Command executed: {command}"
            
            return {
                'hash': threat_id,
                'title': f"Cowrie Honeypot Alert: {event_id}",
                'description': description,
                'severity': severity_map.get(event_id, 'medium'),
                'category': 'honeypot',
                'source': 'Cowrie Honeypot',
                'timestamp': self.parse_timestamp(data.get('timestamp')),
                'iocs': [src_ip] if src_ip else [],
                'tags': ['honeypot', 'cowrie', 'ssh', 'telnet'],
                'raw_data': data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing Cowrie event: {e}")
            return None
    
    def parse_dionaea_event(self, data: Dict) -> Dict:
        """Parse Dionaea honeypot event"""
        try:
            connection_type = data.get('connection_type', '')
            src_ip = data.get('remote_host', '')
            dst_port = data.get('local_port', '')
            
            threat_id = hashlib.md5(f"dionaea_{src_ip}_{dst_port}_{data.get('timestamp', '')}".encode()).hexdigest()
            
            description = f"Malware honeypot interaction from {src_ip} on port {dst_port}."
            
            # Check for file downloads/uploads
            if 'download' in data:
                description += f" File downloaded: {data['download'].get('url', 'Unknown')}"
            
            return {
                'hash': threat_id,
                'title': f"Dionaea Honeypot Alert: {connection_type}",
                'description': description,
                'severity': 'high',
                'category': 'malware',
                'source': 'Dionaea Honeypot',
                'timestamp': self.parse_timestamp(data.get('timestamp')),
                'iocs': [src_ip] if src_ip else [],
                'tags': ['honeypot', 'dionaea', 'malware', connection_type],
                'raw_data': data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing Dionaea event: {e}")
            return None
    
    def parse_generic_event(self, data: Dict) -> Dict:
        """Parse generic honeypot/sensor event"""
        try:
            # Generic format expected:
            # {
            #   "timestamp": "ISO format",
            #   "source_ip": "attacker IP",
            #   "target_port": "target port",
            #   "event_type": "event description",
            #   "severity": "low/medium/high/critical",
            #   "details": "additional details"
            # }
            
            src_ip = data.get('source_ip', '')
            event_type = data.get('event_type', 'Generic Alert')
            severity = data.get('severity', 'medium')
            details = data.get('details', '')
            
            threat_id = hashlib.md5(f"generic_{src_ip}_{event_type}_{data.get('timestamp', '')}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"Security Sensor Alert: {event_type}",
                'description': f"Security event detected from {src_ip}. {details}",
                'severity': severity,
                'category': 'sensor',
                'source': 'Security Sensor',
                'timestamp': self.parse_timestamp(data.get('timestamp')),
                'iocs': [src_ip] if src_ip else [],
                'tags': ['sensor', 'generic', event_type.lower().replace(' ', '_')],
                'raw_data': data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing generic event: {e}")
            return None
    
    def parse_dshield_event(self, data: Dict) -> Dict:
        """Parse DShield log submission"""
        try:
            # DShield format
            logs = data.get('logs', [])
            if not logs:
                return None
            
            # Aggregate multiple log entries
            src_ips = set()
            dst_ports = set()
            total_packets = 0
            
            for log in logs:
                src_ips.add(log.get('srcip', ''))
                dst_ports.add(str(log.get('dstport', '')))
                total_packets += int(log.get('packets', 1))
            
            threat_id = hashlib.md5(f"dshield_{len(logs)}_{data.get('timestamp', '')}".encode()).hexdigest()
            
            description = f"DShield log submission: {len(logs)} log entries, "
            description += f"{total_packets} packets from {len(src_ips)} unique IPs "
            description += f"targeting ports {', '.join(list(dst_ports)[:5])}"
            
            return {
                'hash': threat_id,
                'title': f"DShield Log Submission ({len(logs)} entries)",
                'description': description,
                'severity': 'medium' if len(logs) < 10 else 'high',
                'category': 'scanning',
                'source': 'DShield',
                'timestamp': self.parse_timestamp(data.get('timestamp')),
                'iocs': list(src_ips)[:10],  # Limit to 10 IPs
                'tags': ['dshield', 'scanning', 'firewall'],
                'raw_data': data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing DShield event: {e}")
            return None
    
    def parse_timestamp(self, timestamp_str: str) -> str:
        """Parse and normalize timestamp"""
        if not timestamp_str:
            return datetime.utcnow().isoformat()
        
        try:
            # Handle different timestamp formats
            formats = [
                '%Y-%m-%dT%H:%M:%S.%fZ',
                '%Y-%m-%dT%H:%M:%SZ',
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M:%S.%f'
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(timestamp_str, fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
                    
            # If no format matches, try ISO format
            return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00')).isoformat()
            
        except Exception:
            return datetime.utcnow().isoformat()
    
    async def start_webhook_server(self):
        """Start the webhook server"""
        try:
            from threading import Thread
            
            def run_flask():
                self.app.run(host='0.0.0.0', port=self.webhook_port, debug=False)
            
            webhook_thread = Thread(target=run_flask, daemon=True)
            webhook_thread.start()
            
            self.logger.info(f"Honeypot webhook server started on port {self.webhook_port}")
            
        except Exception as e:
            self.logger.error(f"Error starting webhook server: {e}")
    
    async def get_queued_threats(self) -> List[Dict]:
        """Get all queued threats from honeypots"""
        threats = []
        
        while not self.threat_queue.empty():
            try:
                threat = self.threat_queue.get_nowait()
                threats.append(threat)
            except asyncio.QueueEmpty:
                break
        
        return threats
    
    async def fetch_dshield_data(self) -> List[Dict]:
        """Fetch data from DShield API"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                # Get DShield summary data
                url = 'https://isc.sans.edu/api/topports/records/1000/json'
                
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        for port_data in data.get('topports', []):
                            threat = self.parse_dshield_port_data(port_data)
                            if threat:
                                threats.append(threat)
                        
                        self.logger.info(f"Fetched {len(threats)} threats from DShield")
                        
        except Exception as e:
            self.logger.error(f"Error fetching DShield data: {e}")
        
        return threats
    
    def parse_dshield_port_data(self, port_data: Dict) -> Dict:
        """Parse DShield port scanning data"""
        try:
            port = port_data.get('targetport', '')
            records = int(port_data.get('records', 0))
            
            if records < 10:  # Filter low-activity ports
                return None
            
            threat_id = hashlib.md5(f"dshield_port_{port}_{records}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"DShield Port Scan Activity: Port {port}",
                'description': f"High scanning activity detected on port {port}. {records} scan attempts reported.",
                'severity': 'high' if records > 1000 else 'medium',
                'category': 'scanning',
                'source': 'DShield Port Report',
                'timestamp': datetime.utcnow().isoformat(),
                'iocs': [],
                'tags': ['dshield', 'port_scan', f'port_{port}'],
                'raw_data': port_data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing DShield port data: {e}")
            return None