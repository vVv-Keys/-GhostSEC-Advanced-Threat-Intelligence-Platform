"""
MISP Integration Module
Connect with MISP (Malware Information Sharing Platform) for enhanced threat intelligence
"""

import requests
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
import os
from typing import Dict, List, Optional

try:
    from pymisp import PyMISP, MISPEvent, MISPAttribute
    MISP_AVAILABLE = True
except ImportError:
    MISP_AVAILABLE = False

class MISPConnector:
    def __init__(self, misp_url=None, misp_key=None, misp_verify_cert=True):
        self.logger = logging.getLogger(__name__)
        
        # Configuration
        self.misp_url = misp_url or os.getenv('MISP_URL')
        self.misp_key = misp_key or os.getenv('MISP_API_KEY')
        self.verify_cert = misp_verify_cert
        
        # Initialize MISP connection
        self.misp = None
        self.connected = False
        
        if MISP_AVAILABLE and self.misp_url and self.misp_key:
            self.connect()
        else:
            self.logger.warning("MISP integration not available - missing pymisp or credentials")
    
    def connect(self):
        """Establish connection to MISP instance"""
        try:
            self.misp = PyMISP(
                url=self.misp_url,
                key=self.misp_key,
                ssl=self.verify_cert,
                debug=False
            )
            
            # Test connection
            version = self.misp.get_version()
            if version:
                self.connected = True
                self.logger.info(f"Connected to MISP instance: {self.misp_url}")
                self.logger.info(f"MISP version: {version.get('version', 'Unknown')}")
            else:
                self.logger.error("Failed to get MISP version - connection failed")
                
        except Exception as e:
            self.logger.error(f"Error connecting to MISP: {e}")
            self.connected = False
    
    def search_iocs(self, iocs: List[str], days_back: int = 30) -> Dict:
        """Search MISP for existing IOCs"""
        if not self.connected:
            return {'found': [], 'not_found': iocs, 'events': []}
        
        try:
            found_iocs = []
            not_found = []
            related_events = []
            
            # Search for each IOC
            for ioc in iocs:
                try:
                    # Search attributes
                    search_result = self.misp.search(
                        value=ioc,
                        type_attribute=['ip-dst', 'ip-src', 'domain', 'hostname', 'md5', 'sha1', 'sha256', 'url'],
                        published=True,
                        last=f"{days_back}d"
                    )
                    
                    if search_result and len(search_result) > 0:
                        found_iocs.append({
                            'ioc': ioc,
                            'matches': len(search_result),
                            'first_seen': min([event.date for event in search_result if hasattr(event, 'date')], default='Unknown'),
                            'events': [event.id for event in search_result[:5] if hasattr(event, 'id')]
                        })
                        
                        # Collect related events
                        for event in search_result[:3]:  # Top 3 events
                            if hasattr(event, 'info') and hasattr(event, 'id'):
                                related_events.append({
                                    'id': event.id,
                                    'info': event.info,
                                    'date': getattr(event, 'date', 'Unknown'),
                                    'threat_level': getattr(event, 'threat_level_id', 'Unknown'),
                                    'analysis': getattr(event, 'analysis', 'Unknown')
                                })
                    else:
                        not_found.append(ioc)
                        
                except Exception as e:
                    self.logger.debug(f"Error searching IOC {ioc}: {e}")
                    not_found.append(ioc)
            
            return {
                'found': found_iocs,
                'not_found': not_found,
                'events': related_events
            }
            
        except Exception as e:
            self.logger.error(f"Error searching MISP IOCs: {e}")
            return {'found': [], 'not_found': iocs, 'events': []}
    
    def create_event(self, threat_data: Dict) -> Optional[str]:
        """Create new MISP event from threat data"""
        if not self.connected:
            return None
        
        try:
            # Create MISP event
            event = MISPEvent()
            event.info = threat_data.get('title', 'GhostSEC Threat Alert')
            event.distribution = 1  # This community only
            event.analysis = 1  # Ongoing
            
            # Set threat level based on severity
            severity_to_threat_level = {
                'low': 3,      # Low
                'medium': 2,   # Medium  
                'high': 1,     # High
                'critical': 1  # High (MISP doesn't have critical)
            }
            
            event.threat_level_id = severity_to_threat_level.get(
                threat_data.get('severity', 'medium').lower(), 2
            )
            
            # Add description as comment
            if threat_data.get('description'):
                event.add_attribute('comment', threat_data['description'])
            
            # Add IOCs as attributes
            iocs = threat_data.get('iocs', [])
            for ioc in iocs:
                try:
                    # Determine IOC type
                    ioc_type = self.determine_ioc_type(ioc)
                    if ioc_type:
                        event.add_attribute(ioc_type, ioc, to_ids=True)
                except Exception as e:
                    self.logger.debug(f"Error adding IOC {ioc}: {e}")
            
            # Add tags
            tags = threat_data.get('tags', [])
            for tag in tags[:5]:  # Limit to 5 tags
                try:
                    event.add_tag(f"ghostsec:{tag}")
                except:
                    pass
            
            # Add source information
            if threat_data.get('source'):
                event.add_attribute('comment', f"Source: {threat_data['source']}")
            
            if threat_data.get('url'):
                event.add_attribute('link', threat_data['url'])
            
            # Create event in MISP
            response = self.misp.add_event(event)
            
            if response and 'Event' in response:
                event_id = response['Event']['id']
                self.logger.info(f"Created MISP event {event_id} for threat: {threat_data.get('title', 'Unknown')}")
                return event_id
            else:
                self.logger.error(f"Failed to create MISP event: {response}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating MISP event: {e}")
            return None
    
    def determine_ioc_type(self, ioc: str) -> Optional[str]:
        """Determine MISP attribute type for IOC"""
        import re
        
        # IP address
        if re.match(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ioc):
            return 'ip-dst'
        
        # Domain/hostname
        if re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$', ioc):
            return 'domain'
        
        # Hash values
        if re.match(r'^[a-fA-F0-9]{32}$', ioc):  # MD5
            return 'md5'
        elif re.match(r'^[a-fA-F0-9]{40}$', ioc):  # SHA1
            return 'sha1'
        elif re.match(r'^[a-fA-F0-9]{64}$', ioc):  # SHA256
            return 'sha256'
        
        # URL
        if ioc.startswith(('http://', 'https://')):
            return 'url'
        
        # Email
        if '@' in ioc and '.' in ioc.split('@')[1]:
            return 'email-src'
        
        return None
    
    def get_recent_events(self, days_back: int = 7, limit: int = 50) -> List[Dict]:
        """Retrieve recent MISP events for correlation"""
        if not self.connected:
            return []
        
        try:
            events = self.misp.search(
                published=True,
                last=f"{days_back}d",
                limit=limit
            )
            
            processed_events = []
            for event in events:
                try:
                    processed_event = {
                        'id': getattr(event, 'id', ''),
                        'info': getattr(event, 'info', ''),
                        'date': getattr(event, 'date', ''),
                        'threat_level': getattr(event, 'threat_level_id', 'Unknown'),
                        'analysis': getattr(event, 'analysis', 'Unknown'),
                        'org': getattr(event, 'Org', {}).get('name', 'Unknown') if hasattr(event, 'Org') else 'Unknown',
                        'attributes': []
                    }
                    
                    # Extract attributes (IOCs)
                    if hasattr(event, 'Attribute'):
                        for attr in event.Attribute[:10]:  # Limit attributes
                            processed_event['attributes'].append({
                                'type': getattr(attr, 'type', ''),
                                'value': getattr(attr, 'value', ''),
                                'category': getattr(attr, 'category', '')
                            })
                    
                    processed_events.append(processed_event)
                    
                except Exception as e:
                    self.logger.debug(f"Error processing MISP event: {e}")
                    continue
            
            return processed_events
            
        except Exception as e:
            self.logger.error(f"Error retrieving MISP events: {e}")
            return []
    
    def enrich_threat_data(self, threat_data: Dict) -> Dict:
        """Enrich threat data with MISP intelligence"""
        if not self.connected:
            return threat_data
        
        enriched_data = threat_data.copy()
        
        try:
            # Search for IOCs in MISP
            iocs = threat_data.get('iocs', [])
            if iocs:
                misp_results = self.search_iocs(iocs)
                
                enriched_data['misp_enrichment'] = {
                    'found_iocs': len(misp_results['found']),
                    'total_iocs': len(iocs),
                    'related_events': len(misp_results['events']),
                    'misp_matches': misp_results['found'],
                    'related_misp_events': misp_results['events']
                }
                
                # Increase priority if IOCs found in MISP
                if misp_results['found']:
                    current_severity = threat_data.get('severity', 'medium')
                    severity_levels = ['low', 'medium', 'high', 'critical']
                    
                    try:
                        current_index = severity_levels.index(current_severity.lower())
                        if current_index < len(severity_levels) - 1:
                            enriched_data['severity'] = severity_levels[current_index + 1]
                            enriched_data['misp_enhanced'] = True
                    except ValueError:
                        pass
            
            return enriched_data
            
        except Exception as e:
            self.logger.error(f"Error enriching threat data with MISP: {e}")
            return threat_data
    
    def get_connection_status(self) -> Dict:
        """Get MISP connection status"""
        return {
            'connected': self.connected,
            'misp_available': MISP_AVAILABLE,
            'url': self.misp_url if self.misp_url else 'Not configured',
            'version': 'Unknown'
        }


class ThreatExchangeConnector:
    """Facebook ThreatExchange integration"""
    
    def __init__(self, app_id=None, app_secret=None):
        self.logger = logging.getLogger(__name__)
        self.app_id = app_id or os.getenv('THREATEXCHANGE_APP_ID')
        self.app_secret = app_secret or os.getenv('THREATEXCHANGE_APP_SECRET')
        self.access_token = None
        self.connected = False
        
        if self.app_id and self.app_secret:
            self.connect()
    
    def connect(self):
        """Get access token for ThreatExchange API"""
        try:
            url = "https://graph.facebook.com/oauth/access_token"
            params = {
                'client_id': self.app_id,
                'client_secret': self.app_secret,
                'grant_type': 'client_credentials'
            }
            
            response = requests.get(url, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                self.access_token = data.get('access_token')
                self.connected = True
                self.logger.info("Connected to Facebook ThreatExchange")
            else:
                self.logger.error(f"Failed to connect to ThreatExchange: {response.status_code}")
                
        except Exception as e:
            self.logger.error(f"Error connecting to ThreatExchange: {e}")
    
    def search_indicators(self, iocs: List[str]) -> Dict:
        """Search ThreatExchange for indicators"""
        if not self.connected:
            return {'found': [], 'not_found': iocs}
        
        found = []
        not_found = []
        
        for ioc in iocs:
            try:
                url = "https://graph.facebook.com/v18.0/threat_indicators"
                params = {
                    'access_token': self.access_token,
                    'text': ioc,
                    'limit': 10
                }
                
                response = requests.get(url, params=params, timeout=30)
                if response.status_code == 200:
                    data = response.json()
                    if data.get('data'):
                        found.append({
                            'ioc': ioc,
                            'matches': len(data['data']),
                            'indicators': data['data'][:3]
                        })
                    else:
                        not_found.append(ioc)
                else:
                    not_found.append(ioc)
                    
            except Exception as e:
                self.logger.debug(f"Error searching ThreatExchange for {ioc}: {e}")
                not_found.append(ioc)
        
        return {'found': found, 'not_found': not_found}


class OTXConnector:
    """AlienVault OTX (Open Threat Exchange) integration"""
    
    def __init__(self, api_key=None):
        self.logger = logging.getLogger(__name__)
        self.api_key = api_key or os.getenv('ALIENVAULT_API_KEY')
        self.base_url = "https://otx.alienvault.com/api/v1"
        self.connected = bool(self.api_key)
    
    def search_pulses(self, query: str, limit: int = 20) -> List[Dict]:
        """Search OTX pulses"""
        if not self.connected:
            return []
        
        try:
            url = f"{self.base_url}/pulses/subscribed"
            headers = {'X-OTX-API-KEY': self.api_key}
            params = {'limit': limit, 'page': 1}
            
            response = requests.get(url, headers=headers, params=params, timeout=30)
            if response.status_code == 200:
                data = response.json()
                return data.get('results', [])
            else:
                self.logger.error(f"OTX API error: {response.status_code}")
                return []
                
        except Exception as e:
            self.logger.error(f"Error searching OTX pulses: {e}")
            return []
    
    def get_indicator_details(self, indicator: str, indicator_type: str) -> Dict:
        """Get detailed information about an indicator"""
        if not self.connected:
            return {}
        
        try:
            url = f"{self.base_url}/indicators/{indicator_type}/{indicator}"
            headers = {'X-OTX-API-KEY': self.api_key}
            
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 200:
                return response.json()
            else:
                return {}
                
        except Exception as e:
            self.logger.debug(f"Error getting OTX indicator details: {e}")
            return {}