"""
STIX/TAXII Integration Module
Export threat intelligence in STIX 2.1 format and TAXII 2.0 compatibility
"""

import json
import uuid
from datetime import datetime
from typing import Dict, List
import logging

class STIXExporter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.stix_version = "2.1"
        
    def export_threats_to_stix(self, threats: List[Dict]) -> Dict:
        """Export threats to STIX 2.1 bundle"""
        try:
            # Create STIX bundle
            bundle = {
                "type": "bundle",
                "id": f"bundle--{str(uuid.uuid4())}",
                "spec_version": self.stix_version,
                "objects": []
            }
            
            # Add identity object (organization)
            identity = self.create_identity_object()
            bundle["objects"].append(identity)
            
            # Convert each threat to STIX objects
            for threat in threats:
                stix_objects = self.threat_to_stix_objects(threat, identity["id"])
                bundle["objects"].extend(stix_objects)
            
            return bundle
            
        except Exception as e:
            self.logger.error(f"Error exporting to STIX: {e}")
            return {}
    
    def create_identity_object(self) -> Dict:
        """Create STIX identity object for GhostSEC"""
        return {
            "type": "identity",
            "spec_version": self.stix_version,
            "id": f"identity--{str(uuid.uuid4())}",
            "created": datetime.utcnow().isoformat() + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "name": "GhostSEC Threat Intelligence",
            "identity_class": "organization",
            "sectors": ["technology"],
            "description": "Automated threat intelligence collection and analysis platform"
        }
    
    def threat_to_stix_objects(self, threat: Dict, identity_id: str) -> List[Dict]:
        """Convert threat to STIX objects"""
        objects = []
        
        # Create main indicator object
        indicator = self.create_indicator_object(threat, identity_id)
        if indicator:
            objects.append(indicator)
        
        # Create malware object if applicable
        malware = self.create_malware_object(threat, identity_id)
        if malware:
            objects.append(malware)
            
            # Create relationship between indicator and malware
            relationship = self.create_relationship(
                indicator["id"], 
                malware["id"], 
                "indicates",
                identity_id
            )
            objects.append(relationship)
        
        # Create attack pattern if applicable
        attack_pattern = self.create_attack_pattern_object(threat, identity_id)
        if attack_pattern:
            objects.append(attack_pattern)
            
            # Create relationship between malware and attack pattern
            if malware:
                relationship = self.create_relationship(
                    malware["id"],
                    attack_pattern["id"],
                    "uses",
                    identity_id
                )
                objects.append(relationship)
        
        # Create threat actor if applicable
        threat_actor = self.create_threat_actor_object(threat, identity_id)
        if threat_actor:
            objects.append(threat_actor)
            
            # Create relationship between threat actor and malware/indicator
            if malware:
                relationship = self.create_relationship(
                    threat_actor["id"],
                    malware["id"],
                    "uses",
                    identity_id
                )
                objects.append(relationship)
        
        return objects
    
    def create_indicator_object(self, threat: Dict, identity_id: str) -> Dict:
        """Create STIX indicator object"""
        iocs = threat.get('iocs', [])
        if not iocs:
            return None
        
        # Build pattern based on IOCs
        patterns = []
        for ioc in iocs[:5]:  # Limit to 5 IOCs
            pattern = self.ioc_to_stix_pattern(ioc)
            if pattern:
                patterns.append(pattern)
        
        if not patterns:
            return None
        
        # Combine patterns
        if len(patterns) == 1:
            final_pattern = patterns[0]
        else:
            final_pattern = "[" + " OR ".join(patterns) + "]"
        
        # Map severity to labels
        severity = threat.get('severity', 'medium').lower()
        labels = self.get_indicator_labels(threat)
        
        return {
            "type": "indicator",
            "spec_version": self.stix_version,
            "id": f"indicator--{str(uuid.uuid4())}",
            "created": threat.get('timestamp', datetime.utcnow().isoformat()) + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "labels": labels,
            "pattern": final_pattern,
            "pattern_type": "stix",
            "valid_from": threat.get('timestamp', datetime.utcnow().isoformat()) + "Z",
            "description": threat.get('description', '')[:1000],
            "created_by_ref": identity_id,
            "confidence": self.severity_to_confidence(severity),
            "external_references": [
                {
                    "source_name": threat.get('source', 'GhostSEC'),
                    "url": threat.get('url', ''),
                    "description": f"Original source: {threat.get('source', 'Unknown')}"
                }
            ] if threat.get('url') else [],
            "object_marking_refs": ["marking-definition--f88d31f6-486f-44da-b317-01333bde0b82"]  # TLP:GREEN
        }
    
    def create_malware_object(self, threat: Dict, identity_id: str) -> Dict:
        """Create STIX malware object"""
        # Check if threat contains malware indicators
        category = threat.get('category', '').lower()
        tags = [tag.lower() for tag in threat.get('tags', [])]
        
        malware_indicators = ['malware', 'trojan', 'ransomware', 'backdoor', 'apt']
        if not any(indicator in category or any(indicator in tag for tag in tags) for indicator in malware_indicators):
            return None
        
        # Determine malware family
        family_name = self.extract_malware_family(threat)
        
        return {
            "type": "malware",
            "spec_version": self.stix_version,
            "id": f"malware--{str(uuid.uuid4())}",
            "created": threat.get('timestamp', datetime.utcnow().isoformat()) + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "name": family_name,
            "description": threat.get('description', '')[:1000],
            "malware_types": self.get_malware_types(threat),
            "is_family": True,
            "created_by_ref": identity_id,
            "confidence": self.severity_to_confidence(threat.get('severity', 'medium')),
            "labels": self.get_malware_labels(threat)
        }
    
    def create_attack_pattern_object(self, threat: Dict, identity_id: str) -> Dict:
        """Create STIX attack pattern object"""
        # Extract attack patterns from threat data
        patterns = self.extract_attack_patterns(threat)
        if not patterns:
            return None
        
        primary_pattern = patterns[0]
        
        return {
            "type": "attack-pattern",
            "spec_version": self.stix_version,
            "id": f"attack-pattern--{str(uuid.uuid4())}",
            "created": threat.get('timestamp', datetime.utcnow().isoformat()) + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "name": primary_pattern["name"],
            "description": primary_pattern["description"],
            "created_by_ref": identity_id,
            "external_references": primary_pattern.get("external_references", [])
        }
    
    def create_threat_actor_object(self, threat: Dict, identity_id: str) -> Dict:
        """Create STIX threat actor object"""
        # Only create threat actor for APT or attributed threats
        category = threat.get('category', '').lower()
        tags = [tag.lower() for tag in threat.get('tags', [])]
        
        if 'apt' not in category and not any('apt' in tag for tag in tags):
            return None
        
        # Extract threat actor name
        actor_name = self.extract_threat_actor_name(threat)
        
        return {
            "type": "threat-actor",
            "spec_version": self.stix_version,
            "id": f"threat-actor--{str(uuid.uuid4())}",
            "created": threat.get('timestamp', datetime.utcnow().isoformat()) + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "name": actor_name,
            "description": f"Threat actor identified in: {threat.get('title', 'Unknown threat')}",
            "threat_actor_types": ["unknown"],
            "sophistication": "intermediate",
            "resource_level": "unknown",
            "primary_motivation": "unknown",
            "created_by_ref": identity_id
        }
    
    def create_relationship(self, source_ref: str, target_ref: str, relationship_type: str, identity_id: str) -> Dict:
        """Create STIX relationship object"""
        return {
            "type": "relationship",
            "spec_version": self.stix_version,
            "id": f"relationship--{str(uuid.uuid4())}",
            "created": datetime.utcnow().isoformat() + "Z",
            "modified": datetime.utcnow().isoformat() + "Z",
            "relationship_type": relationship_type,
            "source_ref": source_ref,
            "target_ref": target_ref,
            "created_by_ref": identity_id
        }
    
    def ioc_to_stix_pattern(self, ioc: str) -> str:
        """Convert IOC to STIX pattern"""
        import re
        
        # IP address
        if re.match(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ioc):
            return f"[ipv4-addr:value = '{ioc}']"
        
        # Domain
        if re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$', ioc):
            return f"[domain-name:value = '{ioc}']"
        
        # URL
        if ioc.startswith(('http://', 'https://')):
            return f"[url:value = '{ioc}']"
        
        # Email
        if '@' in ioc and '.' in ioc.split('@')[1]:
            return f"[email-addr:value = '{ioc}']"
        
        # File hash
        if re.match(r'^[a-fA-F0-9]{32}$', ioc):  # MD5
            return f"[file:hashes.MD5 = '{ioc.upper()}']"
        elif re.match(r'^[a-fA-F0-9]{40}$', ioc):  # SHA1
            return f"[file:hashes.SHA1 = '{ioc.upper()}']"
        elif re.match(r'^[a-fA-F0-9]{64}$', ioc):  # SHA256
            return f"[file:hashes.SHA256 = '{ioc.upper()}']"
        
        # Generic file name or path
        return f"[file:name = '{ioc}']"
    
    def get_indicator_labels(self, threat: Dict) -> List[str]:
        """Get indicator labels based on threat data"""
        labels = ["malicious-activity"]
        
        category = threat.get('category', '').lower()
        
        if 'malware' in category:
            labels.append("malicious-code")
        elif 'phishing' in category:
            labels.append("malicious-code")
        elif 'apt' in category:
            labels.append("attribution")
        elif 'vulnerability' in category:
            labels.append("vulnerable")
        
        return labels
    
    def get_malware_types(self, threat: Dict) -> List[str]:
        """Get malware types from threat data"""
        category = threat.get('category', '').lower()
        tags = [tag.lower() for tag in threat.get('tags', [])]
        
        types = []
        
        if 'ransomware' in category or any('ransom' in tag for tag in tags):
            types.append("ransomware")
        elif 'trojan' in category or any('trojan' in tag for tag in tags):
            types.append("trojan")
        elif 'backdoor' in category or any('backdoor' in tag for tag in tags):
            types.append("backdoor")
        else:
            types.append("unknown")
        
        return types
    
    def get_malware_labels(self, threat: Dict) -> List[str]:
        """Get malware labels"""
        return [threat.get('category', 'malware'), "threat-intelligence"]
    
    def severity_to_confidence(self, severity: str) -> int:
        """Convert severity to confidence score"""
        mapping = {
            'critical': 90,
            'high': 75,
            'medium': 60,
            'low': 40
        }
        return mapping.get(severity.lower(), 50)
    
    def extract_malware_family(self, threat: Dict) -> str:
        """Extract malware family name"""
        tags = threat.get('tags', [])
        title = threat.get('title', '')
        
        # Common malware families
        families = [
            'emotet', 'trickbot', 'qakbot', 'ryuk', 'maze', 'revil',
            'cobalt_strike', 'metasploit', 'mimikatz', 'powershell'
        ]
        
        for family in families:
            if any(family in tag.lower() for tag in tags) or family in title.lower():
                return family.title()
        
        # Extract from category or title
        category = threat.get('category', '').replace('_', ' ').title()
        if category and category != 'General':
            return category
        
        return "Unknown Malware"
    
    def extract_attack_patterns(self, threat: Dict) -> List[Dict]:
        """Extract attack patterns from threat data"""
        patterns = []
        
        # MITRE ATT&CK mapping based on keywords
        attack_mappings = {
            'phishing': {
                'name': 'Spearphishing Link',
                'description': 'Adversaries may send spearphishing emails with a malicious link.',
                'external_references': [
                    {
                        'source_name': 'mitre-attack',
                        'external_id': 'T1566.002',
                        'url': 'https://attack.mitre.org/techniques/T1566/002/'
                    }
                ]
            },
            'command': {
                'name': 'Command and Scripting Interpreter',
                'description': 'Adversaries may abuse command and script interpreters.',
                'external_references': [
                    {
                        'source_name': 'mitre-attack',
                        'external_id': 'T1059',
                        'url': 'https://attack.mitre.org/techniques/T1059/'
                    }
                ]
            },
            'powershell': {
                'name': 'PowerShell',
                'description': 'Adversaries may abuse PowerShell commands and scripts.',
                'external_references': [
                    {
                        'source_name': 'mitre-attack',
                        'external_id': 'T1059.001',
                        'url': 'https://attack.mitre.org/techniques/T1059/001/'
                    }
                ]
            }
        }
        
        text = (threat.get('title', '') + ' ' + threat.get('description', '')).lower()
        
        for keyword, pattern_data in attack_mappings.items():
            if keyword in text:
                patterns.append(pattern_data)
        
        return patterns
    
    def extract_threat_actor_name(self, threat: Dict) -> str:
        """Extract threat actor name"""
        title = threat.get('title', '')
        tags = threat.get('tags', [])
        
        # Look for APT group names
        apt_groups = [
            'apt1', 'apt28', 'apt29', 'apt40', 'lazarus', 'carbanak',
            'equation', 'turla', 'winnti', 'comment_crew'
        ]
        
        for group in apt_groups:
            if group in title.lower() or any(group in tag.lower() for tag in tags):
                return group.upper()
        
        return "Unknown Threat Actor"

class TAXIIExporter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.stix_exporter = STIXExporter()
    
    def create_taxii_collection(self, threats: List[Dict], collection_name: str = "GhostSEC Collection") -> Dict:
        """Create TAXII 2.0 compatible collection"""
        try:
            # Create STIX bundle
            stix_bundle = self.stix_exporter.export_threats_to_stix(threats)
            
            # Create TAXII collection envelope
            collection = {
                "id": str(uuid.uuid4()),
                "title": collection_name,
                "description": "Threat intelligence collection from GhostSEC platform",
                "can_read": True,
                "can_write": False,
                "media_types": [
                    "application/stix+json;version=2.1"
                ],
                "objects": stix_bundle.get("objects", [])
            }
            
            return collection
            
        except Exception as e:
            self.logger.error(f"Error creating TAXII collection: {e}")
            return {}
    
    def format_for_taxii_server(self, threats: List[Dict]) -> Dict:
        """Format data for TAXII server ingestion"""
        collection = self.create_taxii_collection(threats)
        
        return {
            "more": False,
            "objects": collection.get("objects", [])
        }