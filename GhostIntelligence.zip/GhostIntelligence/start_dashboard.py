#!/usr/bin/env python3
"""
Standalone Dashboard Launcher
Launch the threat intelligence dashboard independently
"""

import sys
from pathlib import Path
import asyncio
import logging

# Add project root to path
sys.path.append(str(Path(__file__).parent))

from dashboard.web_dashboard import ThreatDashboard, create_dashboard_template
from utils.logger import setup_logger

async def main():
    """Launch standalone dashboard"""
    logger = setup_logger("dashboard")
    
    print("Starting GhostSEC Threat Intelligence Dashboard")
    print("=" * 50)
    
    try:
        # Create dashboard template
        create_dashboard_template()
        logger.info("Dashboard template created")
        
        # Initialize dashboard
        dashboard = ThreatDashboard(bot=None, port=5000)
        
        # Add sample data for demonstration
        sample_threats = [
            {
                'hash': 'demo1',
                'title': 'Critical Zero-Day Vulnerability in Web Framework',
                'description': 'Security researchers discovered a critical RCE vulnerability affecting popular web frameworks.',
                'severity': 'critical',
                'category': 'vulnerability',
                'source': 'Security Research Team',
                'timestamp': '2025-06-21T10:00:00Z',
                'iocs': ['evil-domain.com', '203.0.113.42', 'malicious.exe'],
                'tags': ['zero-day', 'rce', 'framework'],
                'priority_analysis': {
                    'priority_score': 85,
                    'priority_level': 'critical'
                }
            },
            {
                'hash': 'demo2', 
                'title': 'APT Campaign Targeting Financial Sector',
                'description': 'Advanced persistent threat group conducting sophisticated attacks against financial institutions.',
                'severity': 'high',
                'category': 'apt',
                'source': 'Threat Intelligence Platform',
                'timestamp': '2025-06-21T09:30:00Z',
                'iocs': ['apt-c2.evil', '198.51.100.5'],
                'tags': ['apt', 'financial', 'targeted'],
                'priority_analysis': {
                    'priority_score': 78,
                    'priority_level': 'high'
                }
            },
            {
                'hash': 'demo3',
                'title': 'Ransomware Campaign Using New Encryption Method',
                'description': 'New ransomware variant detected with advanced encryption targeting healthcare organizations.',
                'severity': 'high',
                'category': 'ransomware',
                'source': 'Malware Analysis Lab',
                'timestamp': '2025-06-21T08:45:00Z',
                'iocs': ['ransom-pay.onion', 'encryption.dll'],
                'tags': ['ransomware', 'healthcare', 'encryption'],
                'priority_analysis': {
                    'priority_score': 72,
                    'priority_level': 'high'
                }
            }
        ]
        
        # Add sample threats to dashboard with enhanced data
        enhanced_threats = []
        for i, threat in enumerate(sample_threats):
            # Add geographic enrichment simulation
            threat['geo_enrichment'] = {
                threat['iocs'][0] if threat['iocs'] else 'unknown': {
                    'country': ['United States', 'China', 'Russia', 'Germany', 'Brazil'][i % 5],
                    'country_code': ['US', 'CN', 'RU', 'DE', 'BR'][i % 5],
                    'asn': [f'AS{13335 + i}', f'AS{4134 + i}', f'AS{12389 + i}'][i % 3],
                    'asn_name': ['CLOUDFLARENET', 'CHINANET', 'ROSTELECOM'][i % 3],
                    'latitude': [37.7749, 39.9042, 55.7558][i % 3],
                    'longitude': [-122.4194, 116.4074, 37.6176][i % 3]
                }
            }
            enhanced_threats.append(threat)
            dashboard.add_threat(threat)
        
        logger.info("Sample threat data loaded")
        
        print("\nDashboard Features:")
        print("• Real-time threat visualization")
        print("• IOC correlation network")
        print("• Advanced search and filtering")
        print("• Export capabilities")
        print("• ML-powered insights")
        print("\nAccess URL: http://localhost:5000")
        print("Press Ctrl+C to stop")
        
        # Start dashboard
        dashboard.start_dashboard()
        
    except KeyboardInterrupt:
        print("\nDashboard stopped by user")
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        print(f"Error starting dashboard: {e}")

if __name__ == "__main__":
    asyncio.run(main())