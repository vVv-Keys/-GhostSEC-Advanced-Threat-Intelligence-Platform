"""
GhostSEC Bot Embeds
Rich embed formatting for threat alerts and bot messages
"""

import discord
from datetime import datetime
import random

def get_severity_color(severity):
    """Get color code based on threat severity"""
    colors = {
        'low': 0x00ff00,      # Green
        'medium': 0xffff00,   # Yellow
        'high': 0xff8000,     # Orange
        'critical': 0xff0000  # Red
    }
    return colors.get(severity.lower(), 0x7289da)

def get_severity_emoji(severity):
    """Get emoji based on threat severity"""
    emojis = {
        'low': '🟢',
        'medium': '🟡', 
        'high': '🟠',
        'critical': '🔴'
    }
    return emojis.get(severity.lower(), '⚪')

def get_category_emoji(category):
    """Get emoji based on threat category"""
    emojis = {
        'malware': '🦠',
        'vulnerability': '🛡️',
        'breach': '💥',
        'phishing': '🎣',
        'ransomware': '🔒',
        'apt': '🎯',
        'general': '⚠️'
    }
    return emojis.get(category.lower(), '⚠️')

def create_threat_embed(threat_data):
    """Create rich embed for threat intelligence alert"""
    severity = threat_data.get('severity', 'medium')
    category = threat_data.get('category', 'general')
    
    embed = discord.Embed(
        title=f"{get_severity_emoji(severity)} {threat_data.get('title', 'Threat Alert')}",
        description=threat_data.get('description', 'No description available'),
        color=get_severity_color(severity),
        timestamp=datetime.utcnow()
    )
    
    # Add fields
    embed.add_field(
        name="🔍 Severity",
        value=f"{get_severity_emoji(severity)} {severity.upper()}",
        inline=True
    )
    
    # Add ML priority score if available
    if threat_data.get('priority_analysis'):
        priority = threat_data['priority_analysis']
        embed.add_field(
            name="🧠 ML Priority",
            value=f"Score: {priority.get('priority_score', 'N/A')}\n"
                  f"Level: {priority.get('priority_level', 'Unknown').title()}",
            inline=True
        )
    
    embed.add_field(
        name="📊 Category", 
        value=f"{get_category_emoji(category)} {category.title()}",
        inline=True
    )
    
    if threat_data.get('source'):
        embed.add_field(
            name="📡 Source",
            value=threat_data['source'],
            inline=True
        )
    
    if threat_data.get('iocs'):
        ioc_text = '\n'.join([f"`{ioc}`" for ioc in threat_data['iocs'][:5]])
        if len(threat_data['iocs']) > 5:
            ioc_text += f"\n... and {len(threat_data['iocs']) - 5} more"
        embed.add_field(
            name="🔗 Indicators of Compromise",
            value=ioc_text,
            inline=False
        )
    
    if threat_data.get('tags'):
        tag_text = ' '.join([f"`{tag}`" for tag in threat_data['tags'][:10]])
        embed.add_field(
            name="🏷️ Tags",
            value=tag_text,
            inline=False
        )
    
    # Add correlation information if available
    if threat_data.get('correlation_analysis'):
        correlation = threat_data['correlation_analysis']
        if correlation.get('related_threats', 0) > 0:
            embed.add_field(
                name="🔗 Correlations",
                value=f"Related threats: {correlation.get('related_threats', 0)}\n"
                      f"Confidence: {correlation.get('confidence', 0):.1f}%",
                inline=True
            )
    
    # Add MISP enrichment info if available
    if threat_data.get('misp_enrichment'):
        misp_data = threat_data['misp_enrichment']
        if misp_data.get('found_iocs', 0) > 0:
            embed.add_field(
                name="🔍 MISP Intel",
                value=f"Known IOCs: {misp_data.get('found_iocs', 0)}/{misp_data.get('total_iocs', 0)}\n"
                      f"Related events: {misp_data.get('related_events', 0)}",
                inline=True
            )
    
    if threat_data.get('url'):
        embed.add_field(
            name="🔗 Reference",
            value=f"[Read More]({threat_data['url']})",
            inline=False
        )
    
    # Footer with source attribution
    embed.set_footer(
        text=f"👻 GhostSEC • {threat_data.get('source', 'Unknown Source')}",
        icon_url="https://cdn.discordapp.com/emojis/ghost.png"
    )
    
    return embed

def create_startup_embed(bot):
    """Create embed for bot startup notification"""
    embed = discord.Embed(
        title="👻 GhostSEC Bot Online",
        description="Cyber Threat Intelligence monitoring has started!",
        color=0x00ff00,
        timestamp=datetime.utcnow()
    )
    
    embed.add_field(
        name="🔄 Update Frequency",
        value="Every 15 minutes",
        inline=True
    )
    
    embed.add_field(
        name="📡 Sources",
        value=f"{len(bot.feed_manager.sources)} active feeds",
        inline=True
    )
    
    embed.add_field(
        name="⚡ Status",
        value="All systems operational",
        inline=True
    )
    
    embed.set_footer(text="Use !ghost help for commands")
    
    return embed

def create_help_embed():
    """Create help embed with available commands"""
    embed = discord.Embed(
        title="👻 GhostSEC Bot Commands",
        description="Cyber Threat Intelligence Bot Command Reference",
        color=0x7289da
    )
    
    embed.add_field(
        name="📊 Information Commands",
        value="`!ghost help` - Show this help message\n"
              "`!ghost status` - Bot status and stats\n"
              "`!ghost sources` - List CTI sources\n"
              "`!ghost info` - Bot information\n"
              "`!ghost ping` - Check bot latency",
        inline=False
    )
    
    embed.add_field(
        name="⚙️ Management Commands",
        value="`!ghost update` - Manual feed update\n"
              "`!ghost test [severity]` - Send test alert\n"
              "`!ghost schedule` - Update schedule info\n"
              "`!ghost channels` - List available channels\n"
              "`!ghost clear_cache` - Clear duplicate cache",
        inline=False
    )
    
    embed.add_field(
        name="🔒 Permissions Required",
        value="• **Manage Messages**: update, test\n"
              "• **Manage Channels**: channels\n"
              "• **Administrator**: clear_cache",
        inline=False
    )
    
    embed.set_footer(text="Stay vigilant! Security never sleeps 🛡️")
    
    return embed

def create_status_embed(bot):
    """Create status embed with bot statistics"""
    uptime = datetime.utcnow() - bot.start_time
    
    embed = discord.Embed(
        title="👻 GhostSEC Bot Status",
        color=0x00ff00,
        timestamp=datetime.utcnow()
    )
    
    embed.add_field(
        name="⏱️ Uptime",
        value=str(uptime).split('.')[0],
        inline=True
    )
    
    embed.add_field(
        name="🏓 Latency",
        value=f"{round(bot.latency * 1000)}ms",
        inline=True
    )
    
    embed.add_field(
        name="🏢 Servers",
        value=str(len(bot.guilds)),
        inline=True
    )
    
    embed.add_field(
        name="📡 Active Sources",
        value=str(len(bot.feed_manager.sources)),
        inline=True
    )
    
    embed.add_field(
        name="🚨 Alerts Sent",
        value=str(bot.alerts_sent),
        inline=True
    )
    
    embed.add_field(
        name="🔄 Feeds Processed",
        value=str(bot.feeds_processed),
        inline=True
    )
    
    return embed

def create_sources_embed(sources):
    """Create embed listing all CTI sources"""
    embed = discord.Embed(
        title="📡 Threat Intelligence Sources",
        description="Currently monitored CTI feeds",
        color=0x7289da
    )
    
    for source in sources[:10]:  # Limit to first 10 sources
        status_emoji = "🟢" if source.get('active', True) else "🔴"
        embed.add_field(
            name=f"{status_emoji} {source.get('name', 'Unknown')}",
            value=f"Type: {source.get('type', 'RSS')}\nCategory: {source.get('category', 'General')}",
            inline=True
        )
    
    if len(sources) > 10:
        embed.add_field(
            name="➕ Additional Sources",
            value=f"... and {len(sources) - 10} more sources",
            inline=False
        )
    
    embed.set_footer(text=f"Total Sources: {len(sources)}")
    
    return embed

def create_test_alert_embed(severity):
    """Create test alert embed"""
    test_threats = [
        "Suspicious network activity detected",
        "New malware variant identified", 
        "Phishing campaign targeting financial sector",
        "Zero-day vulnerability disclosed",
        "Ransomware attack on critical infrastructure"
    ]
    
    threat_data = {
        'title': f"TEST ALERT: {random.choice(test_threats)}",
        'description': "This is a test alert to verify bot functionality. No actual threat detected.",
        'severity': severity,
        'category': 'general',
        'source': 'GhostSEC Test System',
        'iocs': ['192.168.1.1', 'test-domain.com', 'suspicious-file.exe'],
        'tags': ['test', 'simulation', severity],
        'url': 'https://example.com/test'
    }
    
    embed = create_threat_embed(threat_data)
    embed.title = f"🧪 {embed.title}"
    
    return embed

def create_stats_embed(bot):
    """Create detailed statistics embed"""
    uptime = datetime.utcnow() - bot.start_time
    
    embed = discord.Embed(
        title="📊 GhostSEC Detailed Statistics",
        color=0x7289da,
        timestamp=datetime.utcnow()
    )
    
    # Bot stats
    embed.add_field(
        name="🤖 Bot Statistics",
        value=f"**Uptime:** {str(uptime).split('.')[0]}\n"
              f"**Latency:** {round(bot.latency * 1000)}ms\n"
              f"**Servers:** {len(bot.guilds)}\n"
              f"**Active Sources:** {len(bot.feed_manager.sources)}",
        inline=True
    )
    
    # Activity stats
    embed.add_field(
        name="📈 Activity",
        value=f"**Alerts Sent:** {bot.alerts_sent}\n"
              f"**Feeds Processed:** {bot.feeds_processed}\n"
              f"**Cache Size:** {len(bot.duplicate_filter.seen_hashes)}\n"
              f"**Commands Used:** N/A",
        inline=True
    )
    
    # Source stats
    active_sources = sum(1 for s in bot.feed_manager.sources if s.get('active', True))
    embed.add_field(
        name="📡 Sources",
        value=f"**Total Sources:** {len(bot.feed_manager.sources)}\n"
              f"**Active Sources:** {active_sources}\n"
              f"**RSS Feeds:** {sum(1 for s in bot.feed_manager.sources if s.get('type') == 'rss')}\n"
              f"**API Sources:** {sum(1 for s in bot.feed_manager.sources if s.get('type') == 'api')}",
        inline=True
    )
    
    return embed
