"""
GhostSEC Bot Commands
Command handlers for bot management and manual operations
"""

import discord
from discord.ext import commands
import asyncio
from datetime import datetime, timedelta
import json

from bot.embeds import (
    create_help_embed, create_status_embed, create_sources_embed,
    create_test_alert_embed, create_stats_embed
)
import discord

async def setup_commands(bot):
    """Setup all bot commands"""
    
    @bot.command(name='help', aliases=['h'])
    async def help_command(ctx):
        """Show bot help and available commands"""
        embed = create_help_embed()
        await ctx.send(embed=embed)
    
    @bot.command(name='status', aliases=['s'])
    async def status_command(ctx):
        """Show bot status and statistics"""
        embed = create_status_embed(bot)
        await ctx.send(embed=embed)
    
    @bot.command(name='sources', aliases=['src'])
    async def sources_command(ctx):
        """List all configured threat intelligence sources"""
        embed = create_sources_embed(bot.feed_manager.sources)
        await ctx.send(embed=embed)
    
    @bot.command(name='update', aliases=['u'])
    @commands.has_permissions(manage_messages=True)
    async def manual_update(ctx):
        """Manually trigger feed updates"""
        msg = await ctx.send("🔄 Starting manual feed update...")
        
        try:
            await bot.feed_manager.update_all_feeds()
            await msg.edit(content="✅ Manual feed update completed successfully!")
        except Exception as e:
            await msg.edit(content=f"❌ Feed update failed: {str(e)}")
            bot.logger.error(f"Manual update error: {e}")
    
    @bot.command(name='test', aliases=['t'])
    @commands.has_permissions(manage_messages=True)
    async def test_alert(ctx, severity: str = "medium"):
        """Send a test threat alert"""
        if severity.lower() not in ['low', 'medium', 'high', 'critical']:
            await ctx.send("❌ Invalid severity. Use: low, medium, high, or critical")
            return
        
        embed = create_test_alert_embed(severity.lower())
        await ctx.send(embed=embed)
        await bot.increment_alerts_sent()
    
    @bot.command(name='stats', aliases=['statistics'])
    async def stats_command(ctx):
        """Show detailed bot statistics"""
        embed = create_stats_embed(bot)
        await ctx.send(embed=embed)
    
    @bot.command(name='ping', aliases=['p'])
    async def ping_command(ctx):
        """Check bot latency"""
        latency = round(bot.latency * 1000)
        embed = discord.Embed(
            title="🏓 Pong!",
            description=f"Bot latency: **{latency}ms**",
            color=0x00ff00 if latency < 100 else 0xffff00 if latency < 200 else 0xff0000
        )
        await ctx.send(embed=embed)
    
    @bot.command(name='channels', aliases=['ch'])
    @commands.has_permissions(manage_channels=True)
    async def list_channels(ctx):
        """List all channels where bot can send alerts"""
        guild = ctx.guild
        channels = []
        
        for channel in guild.text_channels:
            if channel.permissions_for(guild.me).send_messages:
                channels.append(f"#{channel.name}")
        
        embed = discord.Embed(
            title="📋 Available Channels",
            description="\n".join(channels) if channels else "No accessible channels found",
            color=0x7289da
        )
        embed.set_footer(text=f"Total: {len(channels)} channels")
        await ctx.send(embed=embed)
    
    @bot.command(name='clear_cache', aliases=['cc'])
    @commands.has_permissions(administrator=True)
    async def clear_cache(ctx):
        """Clear the duplicate detection cache"""
        try:
            bot.duplicate_filter.clear_cache()
            embed = discord.Embed(
                title="🗑️ Cache Cleared",
                description="Duplicate detection cache has been cleared.",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"❌ Error clearing cache: {str(e)}")
    
    @bot.command(name='schedule', aliases=['sched'])
    @commands.has_permissions(manage_messages=True)
    async def schedule_info(ctx):
        """Show current update schedule information"""
        embed = discord.Embed(
            title="⏰ Update Schedule",
            color=0x7289da
        )
        embed.add_field(
            name="Automatic Updates",
            value="Every 15 minutes",
            inline=True
        )
        embed.add_field(
            name="Next Update",
            value=f"<t:{int((datetime.utcnow() + timedelta(minutes=15)).timestamp())}:R>",
            inline=True
        )
        embed.add_field(
            name="Manual Updates",
            value="Use `!ghost update` command",
            inline=False
        )
        await ctx.send(embed=embed)
    
    @bot.command(name='info', aliases=['about'])
    async def info_command(ctx):
        """Show bot information"""
        embed = discord.Embed(
            title="👻 GhostSEC - Cyber Threat Intelligence Bot",
            description="Advanced Discord bot for automated cyber threat intelligence feeds",
            color=0x2f3136
        )
        embed.add_field(
            name="Features",
            value="• Multi-source CTI aggregation\n• Duplicate filtering\n• Rich embed formatting\n• Automated scheduling\n• Threat categorization",
            inline=False
        )
        embed.add_field(
            name="Uptime",
            value=f"{datetime.utcnow() - bot.start_time}".split('.')[0],
            inline=True
        )
        embed.add_field(
            name="Servers",
            value=str(len(bot.guilds)),
            inline=True
        )
        embed.set_thumbnail(url=bot.user.avatar.url if bot.user.avatar else None)
        embed.set_footer(text="Stay secure! 🔒")
        await ctx.send(embed=embed)
    
    # Error handlers for specific commands
    @manual_update.error
    async def update_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Manage Messages' permission to use this command.")
    
    @test_alert.error
    async def test_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Manage Messages' permission to use this command.")
    
    @clear_cache.error
    async def clear_cache_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Administrator' permission to use this command.")
    
    @bot.command(name='dashboard', aliases=['dash'])
    async def dashboard_command(ctx):
        """Show dashboard access information"""
        embed = discord.Embed(
            title="🌐 GhostSEC Threat Intelligence Dashboard",
            description="Access the interactive web dashboard for advanced threat analysis",
            color=0xff6b35
        )
        embed.add_field(
            name="Dashboard URL",
            value="http://localhost:5000",
            inline=False
        )
        embed.add_field(
            name="Features",
            value="• Real-time threat visualization\n• IOC correlation maps\n• Advanced search and filtering\n• Export capabilities\n• ML-powered insights",
            inline=False
        )
        embed.add_field(
            name="Access Note",
            value="Dashboard is accessible while the bot is running",
            inline=False
        )
        await ctx.send(embed=embed)
    
    @bot.command(name='correlate', aliases=['corr'])
    @commands.has_permissions(manage_messages=True)
    async def correlate_command(ctx, *, search_term: str = None):
        """Search for threat correlations"""
        if not search_term:
            await ctx.send("❌ Please provide a search term (IOC, keyword, etc.)")
            return
        
        try:
            # Search through recent threats
            correlations = []
            recent_threats = bot.feed_manager.historical_threats[-100:]  # Last 100 threats
            
            for threat in recent_threats:
                threat_text = f"{threat.get('title', '')} {threat.get('description', '')}".lower()
                threat_iocs = [ioc.lower() for ioc in threat.get('iocs', [])]
                
                if (search_term.lower() in threat_text or 
                    search_term.lower() in threat_iocs):
                    correlations.append(threat)
            
            if correlations:
                embed = discord.Embed(
                    title=f"🔍 Correlation Results for '{search_term}'",
                    description=f"Found {len(correlations)} related threats",
                    color=0x7289da
                )
                
                for i, threat in enumerate(correlations[:5]):  # Show top 5
                    embed.add_field(
                        name=f"Match {i+1}",
                        value=f"**{threat.get('title', 'Unknown')[:50]}**\n"
                              f"Severity: {threat.get('severity', 'Unknown')}\n"
                              f"Source: {threat.get('source', 'Unknown')}\n"
                              f"IOCs: {len(threat.get('iocs', []))}",
                        inline=True
                    )
                
                if len(correlations) > 5:
                    embed.add_field(
                        name="Additional Matches",
                        value=f"+ {len(correlations) - 5} more threats found",
                        inline=False
                    )
                
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"🔍 No correlations found for '{search_term}'")
                
        except Exception as e:
            await ctx.send(f"❌ Error searching correlations: {str(e)}")
    
    @bot.command(name='ml_status', aliases=['ml'])
    async def ml_status_command(ctx):
        """Show machine learning analysis status"""
        try:
            analyzer = bot.feed_manager.threat_analyzer
            correlator = bot.feed_manager.correlator
            
            embed = discord.Embed(
                title="🧠 Machine Learning Status",
                color=0x00ff00
            )
            
            # ML Analyzer status
            embed.add_field(
                name="Threat Analyzer",
                value=f"Model trained: {'Yes' if analyzer.priority_classifier else 'No'}\n"
                      f"Training data: {len(bot.feed_manager.historical_threats)} samples\n"
                      f"Feature weights: {len(analyzer.feature_weights)} factors",
                inline=True
            )
            
            # Correlation engine status
            corr_stats = correlator.get_correlation_statistics()
            embed.add_field(
                name="Correlation Engine",
                value=f"Threat history: {corr_stats['threat_history_size']}\n"
                      f"IOC index: {corr_stats['ioc_index_size']} entries\n"
                      f"Correlations found: {corr_stats['total_correlations']}",
                inline=True
            )
            
            # Recent analysis
            embed.add_field(
                name="Recent Activity",
                value=f"Pattern matches: {corr_stats['pattern_matches']}\n"
                      f"Campaign detections: {corr_stats['campaign_detections']}\n"
                      f"Temporal clusters: {corr_stats['temporal_clusters']}",
                inline=True
            )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Error retrieving ML status: {str(e)}")
    
    @bot.command(name='webhooks', aliases=['wh'])
    @commands.has_permissions(administrator=True)
    async def webhook_status_command(ctx):
        """Show webhook delivery status"""
        try:
            webhook_stats = bot.feed_manager.webhook_manager.get_webhook_stats()
            
            embed = discord.Embed(
                title="🔗 Enterprise Webhook Status",
                color=0x7289da
            )
            
            embed.add_field(
                name="Overview",
                value=f"Total webhooks: {webhook_stats['total_webhooks']}\n"
                      f"Enabled: {webhook_stats['enabled_webhooks']}\n"
                      f"Success rate: {webhook_stats['success_rate']}%",
                inline=True
            )
            
            embed.add_field(
                name="Delivery Stats",
                value=f"Total deliveries: {webhook_stats['total_deliveries']}\n"
                      f"Successful: {webhook_stats['successful_deliveries']}\n"
                      f"Failed: {webhook_stats['failed_deliveries']}",
                inline=True
            )
            
            embed.add_field(
                name="Queue Status",
                value=f"Pending: {webhook_stats['queue_size']}\n"
                      f"Retrying: {webhook_stats['pending_retries']}",
                inline=True
            )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Error retrieving webhook status: {str(e)}")
    
    @bot.command(name='export', aliases=['exp'])
    @commands.has_permissions(manage_messages=True)
    async def export_threats_command(ctx, format_type: str = "json", limit: int = 100):
        """Export recent threats data"""
        if format_type.lower() not in ['json', 'csv']:
            await ctx.send("❌ Format must be 'json' or 'csv'")
            return
        
        try:
            recent_threats = bot.feed_manager.historical_threats[:limit]
            
            if format_type.lower() == 'json':
                import io
                import json
                
                output = io.StringIO()
                json.dump(recent_threats, output, indent=2, default=str)
                
                file_content = output.getvalue().encode('utf-8')
                file = discord.File(io.BytesIO(file_content), filename=f"ghostsec_threats_{limit}.json")
                
            else:  # CSV
                import io
                import csv
                
                output = io.StringIO()
                writer = csv.writer(output)
                
                # Write header
                writer.writerow(['Timestamp', 'Title', 'Severity', 'Category', 'Source', 'IOCs', 'Priority_Score'])
                
                # Write data
                for threat in recent_threats:
                    writer.writerow([
                        threat.get('timestamp', ''),
                        threat.get('title', ''),
                        threat.get('severity', ''),
                        threat.get('category', ''),
                        threat.get('source', ''),
                        len(threat.get('iocs', [])),
                        threat.get('priority_analysis', {}).get('priority_score', '')
                    ])
                
                file_content = output.getvalue().encode('utf-8')
                file = discord.File(io.BytesIO(file_content), filename=f"ghostsec_threats_{limit}.csv")
            
            embed = discord.Embed(
                title="📤 Threat Data Export",
                description=f"Exported {len(recent_threats)} recent threats in {format_type.upper()} format",
                color=0x00ff00
            )
            
            await ctx.send(embed=embed, file=file)
            
        except Exception as e:
            await ctx.send(f"❌ Export failed: {str(e)}")
    
    # Enhanced error handlers
    @correlate_command.error
    async def correlate_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Manage Messages' permission to use this command.")
    
    @webhook_status_command.error
    async def webhook_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Administrator' permission to use this command.")
    
    @export_threats_command.error
    async def export_error(ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need 'Manage Messages' permission to use this command.")
