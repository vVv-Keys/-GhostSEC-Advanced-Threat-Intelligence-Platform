"""
GhostSEC Discord Bot Core
Main bot class with event handlers and initialization
"""

import asyncio
import discord
from discord.ext import commands, tasks
import logging
from datetime import datetime, timedelta

from feeds.feed_manager import FeedManager
from utils.scheduler import FeedScheduler
from utils.duplicate_filter import DuplicateFilter
from bot.commands import setup_commands
from bot.embeds import create_startup_embed
from dashboard.web_dashboard import ThreatDashboard, create_dashboard_template

class GhostSECBot(commands.Bot):
    def __init__(self, settings):
        # Bot intents - minimal required intents
        intents = discord.Intents.default()
        intents.message_content = True  # Required for commands
        intents.guilds = True
        intents.guild_messages = True
        
        super().__init__(
            command_prefix='!ghost ',
            intents=intents,
            description="👻 GhostSEC - Cyber Threat Intelligence Bot",
            help_command=None
        )
        
        self.settings = settings
        self.logger = logging.getLogger(__name__)
        self.feed_manager = FeedManager(self)
        self.scheduler = FeedScheduler(self)
        self.duplicate_filter = DuplicateFilter()
        self.start_time = datetime.utcnow()
        self.alerts_sent = 0
        self.feeds_processed = 0
        
        # Enhanced enterprise features
        self.dashboard = None
        self.ml_training_enabled = True
        
    async def setup_hook(self):
        """Enhanced bot setup with enterprise features"""
        self.logger.info("Setting up GhostSEC Bot with enterprise features...")
        
        # Setup commands
        await setup_commands(self)
        
        # Initialize dashboard
        try:
            create_dashboard_template()
            self.dashboard = ThreatDashboard(self, port=5000)
            
            # Start dashboard in background thread
            import threading
            dashboard_thread = threading.Thread(target=self.dashboard.start_dashboard)
            dashboard_thread.daemon = True
            dashboard_thread.start()
            
            self.logger.info("Threat intelligence dashboard started on port 5000")
        except Exception as e:
            self.logger.warning(f"Dashboard initialization failed: {e}")
        
        # Start webhook manager
        try:
            await self.feed_manager.webhook_manager.start()
            self.logger.info("Enterprise webhook manager started")
        except Exception as e:
            self.logger.warning(f"Webhook manager initialization failed: {e}")
        
        # Start notification system
        try:
            await self.feed_manager.notification_system.start()
            self.logger.info("Alert notification system started")
        except Exception as e:
            self.logger.warning(f"Notification system initialization failed: {e}")
        
        # Start background tasks
        self.feed_update_task.start()
        self.stats_update_task.start()
        self.ml_training_task.start()
        
        self.logger.info("Enhanced bot setup complete")
    
    async def on_ready(self):
        """Called when bot connects to Discord"""
        self.logger.info(f"👻 GhostSEC Bot logged in as {self.user}")
        self.logger.info(f"Connected to {len(self.guilds)} guilds")
        
        # Set bot status
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="cyber threats 👁️"
            ),
            status=discord.Status.online
        )
        
        # Send startup notification to main channels
        await self.send_startup_notification()
    
    async def on_command_error(self, ctx, error):
        """Global error handler for commands"""
        if isinstance(error, commands.CommandNotFound):
            return
        elif isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You don't have permission to use this command.")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I don't have the required permissions to execute this command.")
        else:
            self.logger.error(f"Command error in {ctx.command}: {error}")
            await ctx.send(f"❌ An error occurred: {str(error)}")
    
    async def send_startup_notification(self):
        """Send startup notification to configured channels"""
        embed = create_startup_embed(self)
        
        for guild in self.guilds:
            # Try to find a suitable channel
            channel = None
            
            # Look for configured channels first
            for channel_name in self.settings.DEFAULT_CHANNELS:
                channel = discord.utils.get(guild.channels, name=channel_name)
                if channel:
                    break
            
            # Fallback to general or first text channel
            if not channel:
                channel = discord.utils.get(guild.channels, name='general')
            if not channel:
                channel = next((ch for ch in guild.channels if isinstance(ch, discord.TextChannel)), None)
            
            if channel:
                try:
                    await channel.send(embed=embed)
                    self.logger.info(f"Sent startup notification to {guild.name}#{channel.name}")
                except discord.Forbidden:
                    self.logger.warning(f"No permission to send to {guild.name}#{channel.name}")
                except Exception as e:
                    self.logger.error(f"Error sending startup notification: {e}")
    
    @tasks.loop(minutes=15)
    async def feed_update_task(self):
        """Background task to update feeds"""
        try:
            self.logger.info("Starting scheduled feed update")
            await self.feed_manager.update_all_feeds()
            self.feeds_processed += 1
            self.logger.info("Scheduled feed update completed")
        except Exception as e:
            self.logger.error(f"Error in feed update task: {e}")
    
    @tasks.loop(hours=1)
    async def stats_update_task(self):
        """Background task to update bot statistics"""
        try:
            uptime = datetime.utcnow() - self.start_time
            self.logger.info(f"Bot stats - Uptime: {uptime}, Alerts sent: {self.alerts_sent}, Feeds processed: {self.feeds_processed}")
        except Exception as e:
            self.logger.error(f"Error in stats update task: {e}")
    
    @feed_update_task.before_loop
    async def before_feed_update(self):
        """Wait for bot to be ready before starting feed updates"""
        await self.wait_until_ready()
        # Wait additional 30 seconds for everything to settle
        await asyncio.sleep(30)
    
    @stats_update_task.before_loop
    async def before_stats_update(self):
        """Wait for bot to be ready before starting stats updates"""
        await self.wait_until_ready()
    
    @tasks.loop(hours=6)
    async def ml_training_task(self):
        """Background task for ML model training and optimization"""
        try:
            if not self.ml_training_enabled:
                return
            
            self.logger.info("Starting ML model training cycle")
            
            # Get historical threat data
            historical_data = self.feed_manager.historical_threats
            
            if len(historical_data) >= 50:
                # Train ML models
                success = self.feed_manager.threat_analyzer.train_models(historical_data)
                
                if success:
                    self.logger.info("ML models trained successfully")
                else:
                    self.logger.warning("ML model training failed")
            else:
                self.logger.debug(f"Insufficient data for ML training: {len(historical_data)} samples")
            
            # Retry failed webhook deliveries
            await self.feed_manager.webhook_manager.retry_failed_deliveries()
            
        except Exception as e:
            self.logger.error(f"Error in ML training task: {e}")
    
    @ml_training_task.before_loop
    async def before_ml_training(self):
        """Wait for bot to be ready before starting ML training"""
        await self.wait_until_ready()
        await asyncio.sleep(300)  # Wait 5 minutes before first training
    
    async def increment_alerts_sent(self):
        """Increment the alerts sent counter"""
        self.alerts_sent += 1
    
    async def get_channel_by_category(self, guild, category):
        """Get appropriate channel for threat category"""
        channel_mapping = {
            'malware': 'malware-alerts',
            'vulnerability': 'vuln-alerts', 
            'breach': 'breach-alerts',
            'phishing': 'phishing-alerts',
            'general': 'threat-intel',
            'critical': 'critical-alerts'
        }
        
        channel_name = channel_mapping.get(category, 'threat-intel')
        channel = discord.utils.get(guild.channels, name=channel_name)
        
        # Fallback to general threat intel channel
        if not channel:
            channel = discord.utils.get(guild.channels, name='threat-intel')
        
        # Final fallback to any suitable channel
        if not channel:
            channel = discord.utils.get(guild.channels, name='general')
        
        return channel
