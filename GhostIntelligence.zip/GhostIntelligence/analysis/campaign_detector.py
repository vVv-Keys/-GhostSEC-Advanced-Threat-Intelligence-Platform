"""
Threat Campaign Detection Engine
Automatically detect and track threat campaigns based on IOC patterns
"""

import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Set
import logging
from pathlib import Path

class CampaignDetector:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.campaigns = {}
        self.campaign_rules = self.load_campaign_rules()
        self.campaign_counter = 1
        
    def load_campaign_rules(self) -> Dict:
        """Load campaign detection rules"""
        return {
            'c2_domain_similarity': {
                'enabled': True,
                'threshold': 0.8,
                'weight': 3.0
            },
            'malware_family_correlation': {
                'enabled': True,
                'weight': 2.5
            },
            'infrastructure_overlap': {
                'enabled': True,
                'ip_subnet_weight': 2.0,
                'asn_weight': 1.5
            },
            'temporal_clustering': {
                'enabled': True,
                'time_window_hours': 72,
                'weight': 1.0
            },
            'tactic_similarity': {
                'enabled': True,
                'weight': 2.0
            }
        }
    
    def detect_campaigns(self, threats: List[Dict]) -> List[Dict]:
        """Detect threat campaigns from list of threats"""
        # Group threats by potential campaigns
        potential_campaigns = {}
        
        for threat in threats:
            campaign_indicators = self.analyze_threat_indicators(threat, threats)
            
            for indicator in campaign_indicators:
                campaign_id = indicator['campaign_id']
                
                if campaign_id not in potential_campaigns:
                    potential_campaigns[campaign_id] = {
                        'id': campaign_id,
                        'name': self.generate_campaign_name(indicator),
                        'threats': [],
                        'confidence_score': 0.0,
                        'indicators': [],
                        'first_seen': threat.get('timestamp', ''),
                        'last_seen': threat.get('timestamp', ''),
                        'countries': set(),
                        'malware_families': set(),
                        'c2_infrastructure': set(),
                        'attack_patterns': set()
                    }
                
                campaign = potential_campaigns[campaign_id]
                campaign['threats'].append(threat.get('hash', ''))
                campaign['indicators'].append(indicator)
                campaign['confidence_score'] += indicator['confidence']
                
                # Update metadata
                self.update_campaign_metadata(campaign, threat)
        
        # Filter and rank campaigns
        confirmed_campaigns = []
        for campaign_id, campaign in potential_campaigns.items():
            if len(campaign['threats']) >= 2 and campaign['confidence_score'] >= 5.0:
                # Convert sets to lists
                campaign['countries'] = list(campaign['countries'])
                campaign['malware_families'] = list(campaign['malware_families'])
                campaign['c2_infrastructure'] = list(campaign['c2_infrastructure'])
                campaign['attack_patterns'] = list(campaign['attack_patterns'])
                
                # Calculate final confidence
                campaign['confidence_score'] = min(100.0, campaign['confidence_score'] * 10)
                campaign['threat_count'] = len(set(campaign['threats']))
                
                confirmed_campaigns.append(campaign)
        
        # Sort by confidence and threat count
        confirmed_campaigns.sort(key=lambda x: (x['confidence_score'], x['threat_count']), reverse=True)
        return confirmed_campaigns
    
    def analyze_threat_indicators(self, threat: Dict, all_threats: List[Dict]) -> List[Dict]:
        """Analyze threat for campaign indicators"""
        indicators = []
        threat_iocs = set(threat.get('iocs', []))
        threat_tags = set(threat.get('tags', []))
        threat_time = datetime.fromisoformat(threat.get('timestamp', ''))
        
        for other_threat in all_threats:
            if other_threat.get('hash') == threat.get('hash'):
                continue
            
            other_iocs = set(other_threat.get('iocs', []))
            other_tags = set(other_threat.get('tags', []))
            other_time = datetime.fromisoformat(other_threat.get('timestamp', ''))
            
            # Check various correlation methods
            correlations = []
            
            # 1. C2 Domain Similarity
            c2_correlation = self.detect_c2_correlation(threat_iocs, other_iocs)
            if c2_correlation['score'] > 0:
                correlations.append(c2_correlation)
            
            # 2. Malware Family Correlation
            family_correlation = self.detect_family_correlation(threat_tags, other_tags)
            if family_correlation['score'] > 0:
                correlations.append(family_correlation)
            
            # 3. Infrastructure Overlap
            infra_correlation = self.detect_infrastructure_overlap(threat, other_threat)
            if infra_correlation['score'] > 0:
                correlations.append(infra_correlation)
            
            # 4. Temporal Clustering
            temporal_correlation = self.detect_temporal_clustering(threat_time, other_time)
            if temporal_correlation['score'] > 0:
                correlations.append(temporal_correlation)
            
            # 5. Tactic Similarity
            tactic_correlation = self.detect_tactic_similarity(threat, other_threat)
            if tactic_correlation['score'] > 0:
                correlations.append(tactic_correlation)
            
            # Generate campaign indicator if sufficient correlation
            if correlations:
                total_score = sum(c['score'] for c in correlations)
                if total_score >= 3.0:
                    campaign_id = self.generate_campaign_id(threat, other_threat, correlations)
                    
                    indicators.append({
                        'campaign_id': campaign_id,
                        'confidence': total_score,
                        'correlations': correlations,
                        'related_threat': other_threat.get('hash'),
                        'primary_indicator': max(correlations, key=lambda x: x['score'])['type']
                    })
        
        return indicators
    
    def detect_c2_correlation(self, iocs1: Set[str], iocs2: Set[str]) -> Dict:
        """Detect C2 domain correlation"""
        domains1 = {ioc for ioc in iocs1 if self.is_domain(ioc)}
        domains2 = {ioc for ioc in iocs2 if self.is_domain(ioc)}
        
        if not domains1 or not domains2:
            return {'type': 'c2_domain', 'score': 0.0}
        
        # Check for exact matches
        shared_domains = domains1 & domains2
        if shared_domains:
            return {
                'type': 'c2_domain',
                'score': 4.0,
                'details': f"Shared domains: {', '.join(list(shared_domains)[:3])}"
            }
        
        # Check for domain similarity (same parent domain, similar patterns)
        similarity_score = 0.0
        similar_pairs = []
        
        for d1 in domains1:
            for d2 in domains2:
                sim = self.calculate_domain_similarity(d1, d2)
                if sim > 0.8:
                    similarity_score += sim
                    similar_pairs.append((d1, d2))
        
        if similarity_score > 0:
            return {
                'type': 'c2_domain',
                'score': min(3.0, similarity_score * 2),
                'details': f"Similar domains: {similar_pairs[:2]}"
            }
        
        return {'type': 'c2_domain', 'score': 0.0}
    
    def detect_family_correlation(self, tags1: Set[str], tags2: Set[str]) -> Dict:
        """Detect malware family correlation"""
        malware_families = {
            'emotet', 'trickbot', 'qakbot', 'cobalt_strike', 'metasploit',
            'ransomware', 'banking_trojan', 'apt', 'backdoor', 'loader'
        }
        
        family_tags1 = tags1 & malware_families
        family_tags2 = tags2 & malware_families
        
        shared_families = family_tags1 & family_tags2
        if shared_families:
            return {
                'type': 'malware_family',
                'score': 3.0,
                'details': f"Shared families: {', '.join(shared_families)}"
            }
        
        return {'type': 'malware_family', 'score': 0.0}
    
    def detect_infrastructure_overlap(self, threat1: Dict, threat2: Dict) -> Dict:
        """Detect infrastructure overlap"""
        score = 0.0
        details = []
        
        # Get geo enrichment data
        geo1 = threat1.get('geo_enrichment', {})
        geo2 = threat2.get('geo_enrichment', {})
        
        # Check ASN overlap
        asns1 = {data.get('asn') for data in geo1.values() if data.get('asn')}
        asns2 = {data.get('asn') for data in geo2.values() if data.get('asn')}
        
        shared_asns = asns1 & asns2
        if shared_asns:
            score += 2.0
            details.append(f"Shared ASNs: {', '.join(shared_asns)}")
        
        # Check IP subnet overlap
        ips1 = {data.get('ip') for data in geo1.values() if data.get('ip')}
        ips2 = {data.get('ip') for data in geo2.values() if data.get('ip')}
        
        subnets1 = {self.ip_to_subnet(ip) for ip in ips1 if ip}
        subnets2 = {self.ip_to_subnet(ip) for ip in ips2 if ip}
        
        shared_subnets = subnets1 & subnets2
        if shared_subnets:
            score += 1.5
            details.append(f"Shared subnets: {len(shared_subnets)}")
        
        return {
            'type': 'infrastructure',
            'score': score,
            'details': '; '.join(details) if details else ''
        }
    
    def detect_temporal_clustering(self, time1: datetime, time2: datetime) -> Dict:
        """Detect temporal clustering"""
        time_diff = abs((time1 - time2).total_seconds() / 3600)  # Hours
        
        if time_diff <= 6:  # Within 6 hours
            return {
                'type': 'temporal',
                'score': 2.0,
                'details': f"Within {time_diff:.1f} hours"
            }
        elif time_diff <= 24:  # Within 24 hours
            return {
                'type': 'temporal',
                'score': 1.5,
                'details': f"Within {time_diff:.1f} hours"
            }
        elif time_diff <= 72:  # Within 72 hours
            return {
                'type': 'temporal',
                'score': 1.0,
                'details': f"Within {time_diff:.1f} hours"
            }
        
        return {'type': 'temporal', 'score': 0.0}
    
    def detect_tactic_similarity(self, threat1: Dict, threat2: Dict) -> Dict:
        """Detect attack tactic similarity"""
        # Simple keyword-based tactic detection
        tactic_keywords = {
            'reconnaissance': ['recon', 'scanning', 'enumeration'],
            'initial_access': ['phishing', 'exploit', 'vulnerability'],
            'execution': ['powershell', 'cmd', 'script'],
            'persistence': ['registry', 'startup', 'service'],
            'privilege_escalation': ['escalation', 'admin', 'root'],
            'defense_evasion': ['bypass', 'evasion', 'obfuscation'],
            'credential_access': ['password', 'credential', 'keylog'],
            'discovery': ['discovery', 'network', 'system'],
            'lateral_movement': ['lateral', 'remote', 'rdp'],
            'collection': ['collection', 'data', 'files'],
            'command_control': ['c2', 'command', 'control'],
            'exfiltration': ['exfil', 'data', 'upload'],
            'impact': ['ransom', 'destroy', 'wipe']
        }
        
        def extract_tactics(threat):
            text = (threat.get('title', '') + ' ' + threat.get('description', '')).lower()
            detected_tactics = set()
            
            for tactic, keywords in tactic_keywords.items():
                if any(keyword in text for keyword in keywords):
                    detected_tactics.add(tactic)
            
            return detected_tactics
        
        tactics1 = extract_tactics(threat1)
        tactics2 = extract_tactics(threat2)
        
        shared_tactics = tactics1 & tactics2
        if shared_tactics:
            return {
                'type': 'tactics',
                'score': len(shared_tactics) * 0.5,
                'details': f"Shared tactics: {', '.join(shared_tactics)}"
            }
        
        return {'type': 'tactics', 'score': 0.0}
    
    def generate_campaign_id(self, threat1: Dict, threat2: Dict, correlations: List[Dict]) -> str:
        """Generate unique campaign ID"""
        # Create deterministic ID based on threat hashes and correlation types
        threat_ids = sorted([threat1.get('hash', ''), threat2.get('hash', '')])
        correlation_types = sorted([c['type'] for c in correlations])
        
        id_string = '|'.join(threat_ids + correlation_types)
        campaign_hash = hashlib.md5(id_string.encode()).hexdigest()[:8]
        
        return f"campaign_{campaign_hash}"
    
    def generate_campaign_name(self, indicator: Dict) -> str:
        """Generate human-readable campaign name"""
        primary_type = indicator['primary_indicator']
        
        name_patterns = {
            'c2_domain': ['Arachne', 'Hydra', 'Kraken', 'Leviathan', 'Minotaur'],
            'malware_family': ['Cerberus', 'Phoenix', 'Chimera', 'Griffin', 'Sphinx'],
            'infrastructure': ['Titan', 'Atlas', 'Colossus', 'Goliath', 'Behemoth'],
            'temporal': ['Chronos', 'Tempest', 'Vortex', 'Cyclone', 'Maelstrom'],
            'tactics': ['Stealth', 'Shadow', 'Phantom', 'Wraith', 'Specter']
        }
        
        base_names = name_patterns.get(primary_type, ['Unknown'])
        base_name = base_names[self.campaign_counter % len(base_names)]
        
        campaign_name = f"Campaign.{base_name}{self.campaign_counter:02d}"
        self.campaign_counter += 1
        
        return campaign_name
    
    def update_campaign_metadata(self, campaign: Dict, threat: Dict):
        """Update campaign metadata with threat information"""
        # Update timestamps
        threat_time = threat.get('timestamp', '')
        if threat_time < campaign['first_seen']:
            campaign['first_seen'] = threat_time
        if threat_time > campaign['last_seen']:
            campaign['last_seen'] = threat_time
        
        # Update geographic data
        geo_data = threat.get('geo_enrichment', {})
        for ioc_geo in geo_data.values():
            country = ioc_geo.get('country')
            if country:
                campaign['countries'].add(country)
        
        # Update malware families
        for tag in threat.get('tags', []):
            if any(family in tag.lower() for family in ['trojan', 'ransomware', 'apt', 'backdoor']):
                campaign['malware_families'].add(tag)
        
        # Update C2 infrastructure
        for ioc in threat.get('iocs', []):
            if self.is_domain(ioc) or self.is_ip(ioc):
                campaign['c2_infrastructure'].add(ioc)
        
        # Update attack patterns
        category = threat.get('category', '')
        if category:
            campaign['attack_patterns'].add(category)
    
    def is_domain(self, ioc: str) -> bool:
        """Check if IOC is a domain"""
        import re
        return bool(re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$', ioc))
    
    def is_ip(self, ioc: str) -> bool:
        """Check if IOC is an IP address"""
        import re
        return bool(re.match(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ioc))
    
    def calculate_domain_similarity(self, domain1: str, domain2: str) -> float:
        """Calculate domain similarity score"""
        # Check for same parent domain
        parts1 = domain1.split('.')
        parts2 = domain2.split('.')
        
        if len(parts1) >= 2 and len(parts2) >= 2:
            if parts1[-2:] == parts2[-2:]:  # Same parent domain
                return 0.9
        
        # Check for character similarity
        from difflib import SequenceMatcher
        return SequenceMatcher(None, domain1, domain2).ratio()
    
    def ip_to_subnet(self, ip: str) -> str:
        """Convert IP to /24 subnet"""
        if '.' in ip:
            parts = ip.split('.')
            if len(parts) == 4:
                return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
        return ip
    
    def get_campaign_timeline(self, campaign: Dict, threats: List[Dict]) -> List[Dict]:
        """Generate timeline for campaign"""
        campaign_threats = {t.get('hash') for t in threats if t.get('hash') in campaign['threats']}
        
        timeline = []
        for threat in threats:
            if threat.get('hash') in campaign_threats:
                timeline.append({
                    'timestamp': threat.get('timestamp'),
                    'title': threat.get('title'),
                    'severity': threat.get('severity'),
                    'iocs': threat.get('iocs', []),
                    'source': threat.get('source')
                })
        
        # Sort by timestamp
        timeline.sort(key=lambda x: x['timestamp'])
        return timeline