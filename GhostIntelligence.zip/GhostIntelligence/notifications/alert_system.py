"""
Customizable Alert Notification System
Advanced notification routing and delivery system
"""

import logging
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from pathlib import Path
import os
import aiohttp
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class AlertNotificationSystem:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.notification_rules = {}
        self.delivery_methods = {}
        self.notification_queue = asyncio.Queue()
        self.running = False
        
        # Load configuration
        self.load_notification_config()
        self.setup_delivery_methods()
        
        # Statistics
        self.stats = {
            'total_notifications': 0,
            'successful_deliveries': 0,
            'failed_deliveries': 0,
            'delivery_methods': {}
        }
    
    def load_notification_config(self):
        """Load notification configuration"""
        config_file = Path("config/notifications.json")
        
        default_config = {
            "version": "1.0",
            "notification_rules": [
                {
                    "name": "critical_alerts",
                    "enabled": True,
                    "conditions": {
                        "min_severity": "critical",
                        "categories": ["ransomware", "apt", "breach"]
                    },
                    "delivery_methods": ["email", "sms", "discord", "slack"],
                    "escalation": {
                        "enabled": True,
                        "delay_minutes": 30,
                        "max_escalations": 3
                    }
                },
                {
                    "name": "high_priority_alerts",
                    "enabled": True,
                    "conditions": {
                        "min_severity": "high",
                        "min_priority_score": 70
                    },
                    "delivery_methods": ["email", "discord"],
                    "throttle": {
                        "enabled": True,
                        "max_per_hour": 10
                    }
                },
                {
                    "name": "correlation_alerts",
                    "enabled": True,
                    "conditions": {
                        "min_correlations": 3,
                        "campaign_detected": True
                    },
                    "delivery_methods": ["email", "teams", "webhook"]
                }
            ],
            "delivery_methods": {
                "email": {
                    "enabled": True,
                    "smtp_server": os.getenv("SMTP_SERVER", "smtp.gmail.com"),
                    "smtp_port": int(os.getenv("SMTP_PORT", "587")),
                    "username": os.getenv("SMTP_USERNAME"),
                    "password": os.getenv("SMTP_PASSWORD"),
                    "from_address": os.getenv("ALERT_FROM_EMAIL"),
                    "to_addresses": os.getenv("ALERT_TO_EMAILS", "").split(",")
                },
                "sms": {
                    "enabled": bool(os.getenv("TWILIO_ACCOUNT_SID")),
                    "provider": "twilio",
                    "account_sid": os.getenv("TWILIO_ACCOUNT_SID"),
                    "auth_token": os.getenv("TWILIO_AUTH_TOKEN"),
                    "from_number": os.getenv("TWILIO_PHONE_NUMBER"),
                    "to_numbers": os.getenv("ALERT_PHONE_NUMBERS", "").split(",")
                },
                "slack": {
                    "enabled": bool(os.getenv("SLACK_WEBHOOK_URL")),
                    "webhook_url": os.getenv("SLACK_WEBHOOK_URL"),
                    "channel": os.getenv("SLACK_ALERT_CHANNEL", "#security-alerts"),
                    "username": "GhostSEC"
                },
                "teams": {
                    "enabled": bool(os.getenv("TEAMS_WEBHOOK_URL")),
                    "webhook_url": os.getenv("TEAMS_WEBHOOK_URL")
                },
                "discord": {
                    "enabled": True,
                    "channel_mapping": {
                        "critical": "critical-alerts",
                        "high": "high-alerts",
                        "medium": "medium-alerts",
                        "low": "low-alerts"
                    }
                }
            }
        }
        
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    config = json.load(f)
                    self.notification_rules = {
                        rule['name']: rule for rule in config.get('notification_rules', [])
                    }
                    self.delivery_methods = config.get('delivery_methods', {})
            except Exception as e:
                self.logger.error(f"Error loading notification config: {e}")
                self.notification_rules = {
                    rule['name']: rule for rule in default_config['notification_rules']
                }
                self.delivery_methods = default_config['delivery_methods']
        else:
            # Create default config
            with open(config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
            
            self.notification_rules = {
                rule['name']: rule for rule in default_config['notification_rules']
            }
            self.delivery_methods = default_config['delivery_methods']
    
    def setup_delivery_methods(self):
        """Initialize delivery method handlers"""
        for method_name, config in self.delivery_methods.items():
            if config.get('enabled'):
                self.stats['delivery_methods'][method_name] = {
                    'total_sent': 0,
                    'successful': 0,
                    'failed': 0
                }
    
    async def process_threat_alert(self, threat_data: Dict, bot=None):
        """Process threat and determine notification requirements"""
        try:
            # Check each notification rule
            for rule_name, rule in self.notification_rules.items():
                if not rule.get('enabled', True):
                    continue
                
                if self.matches_notification_rule(threat_data, rule):
                    notification = {
                        'rule_name': rule_name,
                        'threat_data': threat_data,
                        'delivery_methods': rule.get('delivery_methods', []),
                        'priority': self.calculate_notification_priority(threat_data, rule),
                        'timestamp': datetime.utcnow().isoformat(),
                        'escalation': rule.get('escalation', {}),
                        'throttle': rule.get('throttle', {}),
                        'bot': bot
                    }
                    
                    await self.notification_queue.put(notification)
                    self.stats['total_notifications'] += 1
        
        except Exception as e:
            self.logger.error(f"Error processing threat alert: {e}")
    
    def matches_notification_rule(self, threat_data: Dict, rule: Dict) -> bool:
        """Check if threat matches notification rule conditions"""
        conditions = rule.get('conditions', {})
        
        # Severity check
        if 'min_severity' in conditions:
            severity_levels = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}
            threat_severity = severity_levels.get(threat_data.get('severity', 'medium').lower(), 2)
            min_severity = severity_levels.get(conditions['min_severity'].lower(), 1)
            
            if threat_severity < min_severity:
                return False
        
        # Priority score check
        if 'min_priority_score' in conditions:
            priority_analysis = threat_data.get('priority_analysis', {})
            priority_score = priority_analysis.get('priority_score', 0)
            
            if priority_score < conditions['min_priority_score']:
                return False
        
        # Category check
        if 'categories' in conditions:
            threat_category = threat_data.get('category', '').lower()
            allowed_categories = [c.lower() for c in conditions['categories']]
            
            if threat_category not in allowed_categories:
                return False
        
        # Correlation check
        if 'min_correlations' in conditions:
            correlation_analysis = threat_data.get('correlation_analysis', {})
            correlation_count = correlation_analysis.get('related_threats', 0)
            
            if correlation_count < conditions['min_correlations']:
                return False
        
        # Campaign detection check
        if conditions.get('campaign_detected'):
            correlation_analysis = threat_data.get('correlation_analysis', {})
            campaigns = correlation_analysis.get('campaign_indicators', [])
            
            if not campaigns:
                return False
        
        return True
    
    def calculate_notification_priority(self, threat_data: Dict, rule: Dict) -> int:
        """Calculate notification priority (1-10)"""
        base_priority = 5
        
        # Adjust based on severity
        severity_map = {'low': -2, 'medium': 0, 'high': 2, 'critical': 4}
        severity_adj = severity_map.get(threat_data.get('severity', 'medium').lower(), 0)
        
        # Adjust based on ML priority score
        priority_analysis = threat_data.get('priority_analysis', {})
        ml_score = priority_analysis.get('priority_score', 50)
        ml_adj = (ml_score - 50) / 25  # -2 to +2 adjustment
        
        # Adjust based on correlations
        correlation_analysis = threat_data.get('correlation_analysis', {})
        correlation_count = correlation_analysis.get('related_threats', 0)
        correlation_adj = min(2, correlation_count * 0.2)
        
        final_priority = int(base_priority + severity_adj + ml_adj + correlation_adj)
        return max(1, min(10, final_priority))
    
    async def notification_worker(self):
        """Background worker to process notification queue"""
        while self.running:
            try:
                notification = await asyncio.wait_for(
                    self.notification_queue.get(), timeout=1.0
                )
                
                await self.deliver_notification(notification)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Error in notification worker: {e}")
    
    async def deliver_notification(self, notification: Dict):
        """Deliver notification via specified methods"""
        threat_data = notification['threat_data']
        delivery_methods = notification['delivery_methods']
        
        for method in delivery_methods:
            try:
                if method not in self.delivery_methods or not self.delivery_methods[method].get('enabled'):
                    continue
                
                success = await self.send_via_method(method, threat_data, notification)
                
                # Update statistics
                method_stats = self.stats['delivery_methods'].get(method, {})
                method_stats['total_sent'] = method_stats.get('total_sent', 0) + 1
                
                if success:
                    method_stats['successful'] = method_stats.get('successful', 0) + 1
                    self.stats['successful_deliveries'] += 1
                else:
                    method_stats['failed'] = method_stats.get('failed', 0) + 1
                    self.stats['failed_deliveries'] += 1
                
            except Exception as e:
                self.logger.error(f"Error delivering notification via {method}: {e}")
    
    async def send_via_method(self, method: str, threat_data: Dict, notification: Dict) -> bool:
        """Send notification via specific delivery method"""
        config = self.delivery_methods[method]
        
        try:
            if method == 'email':
                return await self.send_email_notification(threat_data, config)
            elif method == 'sms':
                return await self.send_sms_notification(threat_data, config)
            elif method == 'slack':
                return await self.send_slack_notification(threat_data, config)
            elif method == 'teams':
                return await self.send_teams_notification(threat_data, config)
            elif method == 'discord':
                return await self.send_discord_notification(threat_data, config, notification.get('bot'))
            elif method == 'webhook':
                return await self.send_webhook_notification(threat_data, config)
            else:
                self.logger.warning(f"Unknown delivery method: {method}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error in {method} delivery: {e}")
            return False
    
    async def send_email_notification(self, threat_data: Dict, config: Dict) -> bool:
        """Send email notification"""
        if not config.get('username') or not config.get('to_addresses'):
            return False
        
        try:
            # Create email content
            subject = f"🚨 GhostSEC Alert: {threat_data.get('severity', 'Unknown').upper()} - {threat_data.get('title', 'Threat Detected')}"
            
            # HTML email body
            html_body = self.create_email_html(threat_data)
            
            # Text body
            text_body = self.create_email_text(threat_data)
            
            # Create message
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = config.get('from_address', config['username'])
            msg['To'] = ', '.join(config['to_addresses'])
            
            msg.attach(MIMEText(text_body, 'plain'))
            msg.attach(MIMEText(html_body, 'html'))
            
            # Send email
            with smtplib.SMTP(config['smtp_server'], config['smtp_port']) as server:
                server.starttls()
                server.login(config['username'], config['password'])
                server.send_message(msg)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Email sending failed: {e}")
            return False
    
    async def send_slack_notification(self, threat_data: Dict, config: Dict) -> bool:
        """Send Slack notification"""
        if not config.get('webhook_url'):
            return False
        
        try:
            payload = {
                "channel": config.get('channel', '#security-alerts'),
                "username": config.get('username', 'GhostSEC'),
                "icon_emoji": ":ghost:",
                "attachments": [{
                    "color": self.get_severity_color_hex(threat_data.get('severity', 'medium')),
                    "title": f"🚨 {threat_data.get('severity', 'Unknown').upper()} Threat Alert",
                    "title_link": threat_data.get('url', ''),
                    "text": threat_data.get('title', 'Threat Detected'),
                    "fields": [
                        {
                            "title": "Source",
                            "value": threat_data.get('source', 'Unknown'),
                            "short": True
                        },
                        {
                            "title": "Category",
                            "value": threat_data.get('category', 'General'),
                            "short": True
                        },
                        {
                            "title": "IOCs",
                            "value": str(len(threat_data.get('iocs', []))),
                            "short": True
                        },
                        {
                            "title": "Priority Score",
                            "value": str(threat_data.get('priority_analysis', {}).get('priority_score', 'N/A')),
                            "short": True
                        }
                    ],
                    "footer": "GhostSEC Threat Intelligence",
                    "ts": int(datetime.utcnow().timestamp())
                }]
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(config['webhook_url'], json=payload) as response:
                    return response.status == 200
                    
        except Exception as e:
            self.logger.error(f"Slack notification failed: {e}")
            return False
    
    async def send_teams_notification(self, threat_data: Dict, config: Dict) -> bool:
        """Send Microsoft Teams notification"""
        if not config.get('webhook_url'):
            return False
        
        try:
            severity = threat_data.get('severity', 'medium')
            color = self.get_severity_color_hex(severity)
            
            payload = {
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "themeColor": color.replace('#', ''),
                "summary": f"GhostSEC Threat Alert: {threat_data.get('title', 'Threat Detected')}",
                "sections": [{
                    "activityTitle": f"🚨 {severity.upper()} Threat Alert",
                    "activitySubtitle": threat_data.get('title', 'Threat Detected'),
                    "activityImage": "https://via.placeholder.com/64/FF6B35/FFFFFF?text=👻",
                    "facts": [
                        {"name": "Severity", "value": severity.upper()},
                        {"name": "Source", "value": threat_data.get('source', 'Unknown')},
                        {"name": "Category", "value": threat_data.get('category', 'General')},
                        {"name": "IOCs", "value": str(len(threat_data.get('iocs', [])))},
                        {"name": "Priority Score", "value": str(threat_data.get('priority_analysis', {}).get('priority_score', 'N/A'))}
                    ],
                    "markdown": True
                }],
                "potentialAction": []
            }
            
            if threat_data.get('url'):
                payload["potentialAction"].append({
                    "@type": "OpenUri",
                    "name": "View Details",
                    "targets": [{"os": "default", "uri": threat_data['url']}]
                })
            
            async with aiohttp.ClientSession() as session:
                async with session.post(config['webhook_url'], json=payload) as response:
                    return response.status == 200
                    
        except Exception as e:
            self.logger.error(f"Teams notification failed: {e}")
            return False
    
    async def send_discord_notification(self, threat_data: Dict, config: Dict, bot=None) -> bool:
        """Send Discord notification to specific channels"""
        if not bot:
            return False
        
        try:
            severity = threat_data.get('severity', 'medium')
            channel_mapping = config.get('channel_mapping', {})
            target_channel = channel_mapping.get(severity, 'threat-intel')
            
            # Find appropriate Discord channel
            for guild in bot.guilds:
                channel = None
                
                # Try to find the specific severity channel
                channel = discord.utils.get(guild.channels, name=target_channel)
                
                # Fallback to general threat intel channel
                if not channel:
                    channel = discord.utils.get(guild.channels, name='threat-intel')
                
                if channel:
                    from bot.embeds import create_threat_embed
                    embed = create_threat_embed(threat_data)
                    await channel.send(embed=embed)
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Discord notification failed: {e}")
            return False
    
    def create_email_html(self, threat_data: Dict) -> str:
        """Create HTML email content"""
        severity = threat_data.get('severity', 'medium')
        color = self.get_severity_color_hex(severity)
        
        iocs = threat_data.get('iocs', [])
        ioc_list = '<br>'.join([f"• {ioc}" for ioc in iocs[:10]])
        if len(iocs) > 10:
            ioc_list += f"<br>... and {len(iocs) - 10} more"
        
        html = f"""
        <html>
        <head>
            <style>
                .alert-container {{ border-left: 5px solid {color}; padding: 20px; font-family: Arial, sans-serif; }}
                .header {{ color: {color}; font-size: 24px; font-weight: bold; margin-bottom: 10px; }}
                .severity {{ background-color: {color}; color: white; padding: 5px 10px; border-radius: 3px; display: inline-block; }}
                .details {{ margin: 15px 0; }}
                .ioc-list {{ background-color: #f5f5f5; padding: 10px; border-radius: 3px; }}
            </style>
        </head>
        <body>
            <div class="alert-container">
                <div class="header">🚨 GhostSEC Threat Alert</div>
                <div class="severity">{severity.upper()}</div>
                
                <div class="details">
                    <h3>{threat_data.get('title', 'Threat Detected')}</h3>
                    <p><strong>Source:</strong> {threat_data.get('source', 'Unknown')}</p>
                    <p><strong>Category:</strong> {threat_data.get('category', 'General')}</p>
                    <p><strong>Priority Score:</strong> {threat_data.get('priority_analysis', {}).get('priority_score', 'N/A')}</p>
                    <p><strong>Description:</strong> {threat_data.get('description', 'No description available')[:500]}...</p>
                </div>
                
        """
        
        if iocs:
            html += f'<div class="ioc-list"><strong>Indicators of Compromise:</strong><br>{ioc_list}</div>'
        
        html += """
                <p><em>Detected by GhostSEC Threat Intelligence System</em></p>"""
        
        if threat_data.get('url'):
            html += f'<p><a href="{threat_data.get("url")}">View Original Source</a></p>'
        
        html += """
            </div>
        </body>
        </html>"""
        return html
    
    def create_email_text(self, threat_data: Dict) -> str:
        """Create plain text email content"""
        iocs = threat_data.get('iocs', [])
        ioc_text = '\n'.join([f"- {ioc}" for ioc in iocs[:10]])
        if len(iocs) > 10:
            ioc_text += f"\n... and {len(iocs) - 10} more"
        
        ioc_section = f'INDICATORS OF COMPROMISE:\n{ioc_text}' if iocs else ''
        url_section = f'Original Source: {threat_data.get("url")}' if threat_data.get('url') else ''
        
        text = f"""🚨 GhostSEC Threat Alert

SEVERITY: {threat_data.get('severity', 'Unknown').upper()}
TITLE: {threat_data.get('title', 'Threat Detected')}
SOURCE: {threat_data.get('source', 'Unknown')}
CATEGORY: {threat_data.get('category', 'General')}
PRIORITY SCORE: {threat_data.get('priority_analysis', {}).get('priority_score', 'N/A')}

DESCRIPTION:
{threat_data.get('description', 'No description available')[:500]}...

{ioc_section}

Detected by GhostSEC Threat Intelligence System
{url_section}"""
        return text.strip()
    
    def get_severity_color_hex(self, severity: str) -> str:
        """Get hex color for severity level"""
        colors = {
            'critical': '#FF0000',
            'high': '#FF8000',
            'medium': '#FFFF00',
            'low': '#00FF00'
        }
        return colors.get(severity.lower(), '#888888')
    
    async def start(self):
        """Start the notification system"""
        self.running = True
        asyncio.create_task(self.notification_worker())
        self.logger.info("Alert notification system started")
    
    async def stop(self):
        """Stop the notification system"""
        self.running = False
        self.logger.info("Alert notification system stopped")
    
    def get_statistics(self) -> Dict:
        """Get notification statistics"""
        return {
            **self.stats,
            'queue_size': self.notification_queue.qsize(),
            'enabled_methods': [method for method, config in self.delivery_methods.items() 
                              if config.get('enabled')],
            'active_rules': [rule for rule, config in self.notification_rules.items() 
                           if config.get('enabled')]
        }