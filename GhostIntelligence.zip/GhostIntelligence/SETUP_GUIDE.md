# 🎯 GhostSEC Advanced Threat Intelligence Platform - Complete Setup Guide

## Platform Overview

GhostSEC is a comprehensive threat intelligence platform featuring:

### Core Features
- **15+ Threat Intelligence Sources** (RSS, API, Open Sources)
- **Machine Learning Threat Analysis** (Random Forest, Isolation Forest)
- **Advanced Correlation Engine** (IOC patterns, temporal clustering, campaign detection)
- **Geographic Threat Visualization** (World heatmaps, IP geolocation)
- **Interactive Web Dashboard** (Real-time charts, IOC database, correlation graphs)
- **Multi-Format Export** (JSON, CSV, PDF, STIX 2.1, TAXII 2.0, MISP, YARA)
- **Honeypot Integration** (Cowrie, Dionaea, DShield, Generic sensors)
- **Enterprise Notifications** (Email, SMS, Slack, Teams, SIEM webhooks)

## Quick Start (5 minutes)

### 1. Discord Bot Setup
```bash
# Get your Discord bot token from https://discord.com/developers/applications
export DISCORD_TOKEN="your_discord_bot_token_here"

# Start the enhanced platform
python start_ghostsec.py
```

### 2. Access Web Dashboard
```
http://localhost:5000
```

### 3. Honeypot Webhook Endpoint
```
http://localhost:5001/webhook/generic
```

## Complete Feature Configuration

### 🌐 Dashboard Features

#### Live Threat Feed Visualization
- **Global Threat Heatmap**: Real-time geographic distribution of threats
- **IOC Correlation Networks**: Interactive relationship graphs
- **Campaign Detection**: Automated threat campaign identification
- **Trend Analysis**: Anomaly detection and pattern recognition

#### IOC Database
- **Searchable Database**: Filter by type, severity, source, timeline
- **IOC Details View**: Click any IOC to see correlation graph and related threats
- **Advanced Filtering**: IP, domain, hash, URL, email categories
- **Export Capabilities**: JSON, CSV, PDF reports

#### Analytics Dashboard
- **Alert Volume Charts**: Time-series analysis with severity breakdown
- **Threat Family Distribution**: Pie charts of malware categories
- **Geographic Clustering**: Country-based threat analysis
- **Anomaly Detection**: Statistical spike detection

### 🤖 Threat Campaign Detection

The platform automatically detects threat campaigns using:

#### C2 Domain Similarity
- Shared command & control infrastructure
- Domain pattern analysis
- Subdomain clustering

#### Infrastructure Overlap
- ASN-based grouping
- IP subnet analysis (/24 blocks)
- Hosting provider correlation

#### Temporal Clustering
- Time-based threat grouping (6h, 24h, 72h windows)
- Burst activity detection
- Campaign timeline generation

#### Malware Family Correlation
- Shared TTPs and tactics
- MITRE ATT&CK mapping
- Behavioral pattern matching

### 📊 Advanced Analytics

#### Threat Trends
```bash
# View trend analysis
curl http://localhost:5000/api/threat-trends?timeframe=7d
```

#### Campaign Detection
```bash
# Detect active campaigns
curl http://localhost:5000/api/campaigns
```

#### Geographic Intelligence
```bash
# Get global threat heatmap
curl http://localhost:5000/api/geo-heatmap
```

### 🔄 Real-time Data Sources

#### Free Open Sources (No API Key Required)
| Source | Data Type | Integration |
|--------|-----------|-------------|
| **Abuse.ch ThreatFox** | IOCs, Hashes, Domains | JSON API |
| **Abuse.ch URLhaus** | Malicious URLs | REST API |
| **Abuse.ch MalwareBazaar** | Malware Samples | JSON API |
| **SANS ISC** | Attacks, CVEs | JSON API |
| **CIRCL CVE** | Vulnerabilities | REST API |
| **DShield** | Scanning Activity | API |

#### Premium Sources (API Key Required)
| Source | Data Type | Setup |
|--------|-----------|-------|
| **AlienVault OTX** | Comprehensive IOCs | `export ALIENVAULT_API_KEY=key` |
| **VirusTotal** | File/URL Analysis | `export VIRUSTOTAL_API_KEY=key` |
| **Shodan** | Internet-wide Scanning | `export SHODAN_API_KEY=key` |
| **IBM X-Force** | Threat Reports | `export XFORCE_API_KEY=key` |

### 🕷️ Honeypot Integration

#### Supported Honeypots
- **Cowrie** (SSH/Telnet)
- **Dionaea** (Malware)
- **DShield** (Firewall logs)
- **Generic Sensors** (Custom format)

#### Webhook Configuration

##### Cowrie Setup
```bash
# In cowrie.cfg
[output_webhook]
enabled = true
url = http://your-ghostsec-server:5001/webhook/cowrie
```

##### Generic Sensor Format
```json
POST /webhook/generic
{
  "timestamp": "2025-06-21T14:30:00Z",
  "source_ip": "203.0.113.42",
  "target_port": "22",
  "event_type": "SSH Brute Force",
  "severity": "high",
  "details": "Multiple failed login attempts detected"
}
```

### 📤 Export & Integration Formats

#### STIX 2.1 Export
```bash
# Export as STIX bundle
curl http://localhost:5000/api/export?format=stix&type=threats > threats.json
```

#### TAXII 2.0 Collection
```bash
# Export TAXII-compatible collection
curl http://localhost:5000/api/export?format=taxii&type=threats > taxii_collection.json
```

#### MISP Events
```bash
# Export MISP event format
curl http://localhost:5000/api/export?format=misp&type=threats > misp_events.json
```

#### YARA Rules
```bash
# Generate YARA rules from IOCs
curl http://localhost:5000/api/export?format=yara&type=iocs > ghostsec_rules.yar
```

### 🌍 Geographic Intelligence

#### IP Geolocation Enrichment
- **Service**: ip-api.com (free tier)
- **Features**: Country, region, city, ISP, ASN
- **Caching**: 24-hour TTL for performance

#### Infrastructure Analysis
```python
# ASN clustering example
{
  "asn": "AS13335",
  "asn_name": "CLOUDFLARENET",
  "threats": ["threat_id_1", "threat_id_2"],
  "countries": ["US", "GB"],
  "significance_score": 8.5
}
```

### 📧 Enterprise Notifications

#### Email Alerts
```bash
export SMTP_SERVER="smtp.gmail.com"
export SMTP_USERNAME="alerts@company.com"
export SMTP_PASSWORD="app_password"
export ALERT_TO_EMAILS="soc@company.com,security@company.com"
```

#### Slack Integration
```bash
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
```

#### Microsoft Teams
```bash
export TEAMS_WEBHOOK_URL="https://your-teams-webhook-url"
```

#### SIEM Integration
```bash
# Splunk HEC
export SPLUNK_WEBHOOK="https://splunk.company.com:8088/services/collector"
export SPLUNK_WEBHOOK_SECRET="your_hec_token"

# Elasticsearch
export ELASTICSEARCH_WEBHOOK="https://elastic.company.com:9200/threats/_doc"

# IBM QRadar
export QRADAR_WEBHOOK="https://qradar.company.com/api/siem/offenses"
```

### 🔐 MISP Integration

#### Setup
```bash
export MISP_URL="https://your-misp-instance.com"
export MISP_API_KEY="your_misp_api_key"
```

#### Features
- Automatic IOC enrichment
- Event creation for high-priority threats
- Correlation with existing MISP events
- Multi-instance support

## Advanced Configuration

### Machine Learning Settings
```python
# Threat priority features
{
  "severity_weight": 0.3,
  "source_reliability": 0.25,
  "ioc_count": 0.2,
  "text_complexity": 0.15,
  "temporal_urgency": 0.1
}
```

### Correlation Rules
```python
# Campaign detection thresholds
{
  "min_shared_iocs": 2,
  "min_confidence_score": 5.0,
  "temporal_window_hours": 72,
  "infrastructure_overlap_weight": 2.0
}
```

### Dashboard Customization
```bash
# Environment variables
export GHOSTSEC_UPDATE_INTERVAL=15  # minutes
export GHOSTSEC_MAX_THREATS=1000
export GHOSTSEC_DEBUG=false
```

## API Endpoints Reference

### Core Data
- `GET /api/stats` - Dashboard statistics
- `GET /api/threats` - Recent threats with pagination
- `GET /api/search` - Threat search functionality

### IOC Database
- `GET /api/ioc-database` - Searchable IOC database
- `GET /api/ioc-details/<ioc>` - IOC correlation details

### Analytics
- `GET /api/geo-heatmap` - Geographic threat distribution
- `GET /api/campaigns` - Detected threat campaigns
- `GET /api/threat-trends` - Trend analysis with anomalies
- `GET /api/alert-volume` - Time-series alert data

### Export
- `GET /api/export?format=<format>&type=<type>` - Multi-format export

## Discord Commands

### Basic Commands
```
!ghost help        - Show all available commands
!ghost status      - Bot statistics and uptime
!ghost sources     - List configured threat sources
!ghost ping        - Check bot latency
```

### Threat Management
```
!ghost update      - Manual feed update
!ghost test high   - Send test threat alert
!ghost clear       - Clear duplicate cache
!ghost channels    - List alert channels
```

### Advanced Features
```
!ghost dashboard   - Web dashboard access information
!ghost correlate malware  - Search threat correlations
!ghost ml          - Machine learning status
!ghost webhooks    - Enterprise webhook delivery status
!ghost export json 100    - Export recent threats data
```

## Production Deployment

### Security Considerations
- Use HTTPS for all webhook endpoints
- Implement API key authentication
- Configure firewall rules for webhook ports
- Use environment variables for secrets

### Performance Optimization
- Enable Redis for caching (optional)
- Configure log rotation
- Set appropriate memory limits
- Use production WSGI server for dashboard

### Monitoring
- Health check endpoints available
- Comprehensive logging with rotation
- Performance metrics collection
- Error tracking and alerting

## Troubleshooting

### Common Issues

#### Dashboard Not Loading
```bash
# Check port availability
netstat -tlnp | grep 5000

# Check logs
tail -f logs/ghostsec_*.log
```

#### Bot Not Connecting
```bash
# Verify Discord token
echo $DISCORD_TOKEN

# Check network connectivity
curl -I https://discord.com/api/v10/gateway
```

#### Webhook Delivery Failed
```bash
# Test webhook endpoint
curl -X POST http://localhost:5001/health

# Check webhook logs
grep "webhook" logs/ghostsec_*.log
```

### Performance Tuning
- Adjust feed update intervals based on volume
- Configure concurrent processing limits
- Enable geographic data caching
- Optimize correlation algorithm thresholds

## Support and Extensions

### Custom Source Integration
1. Create new parser in `feeds/additional_sources.py`
2. Add source configuration to `config/sources.json`
3. Implement rate limiting and error handling
4. Test with sample data

### Campaign Detection Rules
1. Modify rules in `analysis/campaign_detector.py`
2. Adjust confidence thresholds
3. Add new correlation methods
4. Test with historical data

### Dashboard Customization
1. Edit templates in `dashboard/templates/`
2. Add new API endpoints in `dashboard/web_dashboard.py`
3. Implement custom visualizations
4. Configure color themes and layouts

---

## Summary

GhostSEC provides a complete threat intelligence platform with:

✅ **15+ Intelligence Sources** - RSS, API, and open sources  
✅ **Advanced ML Analysis** - Automated threat prioritization  
✅ **Campaign Detection** - Infrastructure and pattern correlation  
✅ **Interactive Dashboard** - Real-time visualization and analytics  
✅ **Multi-Format Export** - STIX, TAXII, MISP, YARA support  
✅ **Honeypot Integration** - Real-time sensor data ingestion  
✅ **Enterprise Notifications** - Email, Slack, Teams, SIEM alerts  
✅ **Geographic Intelligence** - Global threat distribution mapping  

**Ready for production deployment with comprehensive threat intelligence capabilities.**