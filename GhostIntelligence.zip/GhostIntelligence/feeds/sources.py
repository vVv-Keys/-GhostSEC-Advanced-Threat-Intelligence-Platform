"""
Threat Intelligence Sources
Configuration and management of CTI data sources
"""

import json
import os
from pathlib import Path

class ThreatSources:
    def __init__(self):
        self.sources_file = Path("config/sources.json")
        self.sources = self.load_sources()
    
    def load_sources(self):
        """Load threat intelligence sources from configuration"""
        try:
            if self.sources_file.exists():
                with open(self.sources_file, 'r') as f:
                    data = json.load(f)
                    # Handle nested structure where sources are under "sources" key
                    if isinstance(data, dict) and "sources" in data:
                        return data["sources"]
                    elif isinstance(data, list):
                        return data
                    else:
                        return self.get_default_sources()
            else:
                return self.get_default_sources()
        except Exception as e:
            print(f"Error loading sources: {e}")
            return self.get_default_sources()
    
    def get_default_sources(self):
        """Get default threat intelligence sources"""
        return [
            # Open Source Intelligence Feeds
            {
                "name": "US-CERT Alerts",
                "type": "rss",
                "url": "https://www.us-cert.gov/ncas/alerts.xml",
                "category": "vulnerability",
                "severity_default": "high",
                "active": True,
                "description": "US-CERT security alerts and advisories"
            },
            {
                "name": "SANS Internet Storm Center",
                "type": "rss", 
                "url": "https://isc.sans.edu/rssfeed.xml",
                "category": "general",
                "severity_default": "medium",
                "active": True,
                "description": "SANS ISC threat intelligence"
            },
            {
                "name": "National Vulnerability Database",
                "type": "rss",
                "url": "https://nvd.nist.gov/feeds/xml/cve/misc/nvd-rss.xml",
                "category": "vulnerability", 
                "severity_default": "medium",
                "active": True,
                "description": "NIST NVD vulnerability feed"
            },
            {
                "name": "Krebs on Security",
                "type": "rss",
                "url": "https://krebsonsecurity.com/feed/",
                "category": "breach",
                "severity_default": "medium",
                "active": True,
                "description": "Security news and breach reports"
            },
            {
                "name": "Malware Domain List",
                "type": "rss",
                "url": "http://www.malwaredomainlist.com/hostslist/mdl.xml",
                "category": "malware",
                "severity_default": "high",
                "active": True,
                "description": "Known malicious domains"
            },
            {
                "name": "ThreatConnect Public",
                "type": "rss",
                "url": "https://app.threatconnect.com/feeds/public",
                "category": "general",
                "severity_default": "medium", 
                "active": False,  # Requires auth
                "description": "ThreatConnect public indicators"
            },
            {
                "name": "AlienVault OTX",
                "type": "api",
                "url": "https://otx.alienvault.com/api/v1/indicators/export",
                "category": "general",
                "severity_default": "medium",
                "active": False,  # Requires API key
                "auth_token_env": "ALIENVAULT_API_KEY",
                "description": "AlienVault Open Threat Exchange"
            },
            {
                "name": "VirusTotal Intelligence",
                "type": "api", 
                "url": "https://www.virustotal.com/vtapi/v2/file/report",
                "category": "malware",
                "severity_default": "high",
                "active": False,  # Requires API key
                "auth_token_env": "VIRUSTOTAL_API_KEY", 
                "description": "VirusTotal threat intelligence"
            },
            {
                "name": "Shodan Stream",
                "type": "api",
                "url": "https://stream.shodan.io/",
                "category": "vulnerability",
                "severity_default": "medium",
                "active": False,  # Requires API key
                "auth_token_env": "SHODAN_API_KEY",
                "description": "Shodan internet scanning data"
            },
            {
                "name": "IBM X-Force Exchange",
                "type": "api",
                "url": "https://api.xforce.ibmcloud.com/",
                "category": "general", 
                "severity_default": "medium",
                "active": False,  # Requires API key
                "auth_token_env": "XFORCE_API_KEY",
                "description": "IBM X-Force threat intelligence"
            },
            {
                "name": "Cisco Talos Intelligence",
                "type": "rss",
                "url": "https://talosintelligence.com/rss",
                "category": "general",
                "severity_default": "medium",
                "active": True,
                "description": "Cisco Talos threat research"
            },
            {
                "name": "FireEye Threat Intelligence",
                "type": "rss",
                "url": "https://www.fireeye.com/blog/threat-research/_jcr_content.feed",
                "category": "apt",
                "severity_default": "high",
                "active": True,
                "description": "FireEye APT and threat research"
            }
        ]
    
    def get_all_sources(self):
        """Get all configured sources with API keys resolved"""
        resolved_sources = []
        
        for source in self.sources:
            if isinstance(source, dict):
                resolved_source = source.copy()
            else:
                continue
            
            # Resolve API keys from environment variables
            if source.get('auth_token_env'):
                api_key = os.getenv(source['auth_token_env'])
                if api_key:
                    resolved_source['auth_token'] = api_key
                    resolved_source['active'] = True
                else:
                    resolved_source['active'] = False
            
            resolved_sources.append(resolved_source)
        
        return resolved_sources
    
    def get_active_sources(self):
        """Get only active sources"""
        return [s for s in self.get_all_sources() if s.get('active', True)]
    
    def get_sources_by_category(self, category):
        """Get sources filtered by category"""
        return [s for s in self.get_all_sources() if s.get('category') == category]
    
    def get_sources_by_type(self, source_type):
        """Get sources filtered by type (rss/api)"""
        return [s for s in self.get_all_sources() if s.get('type') == source_type]
    
    def add_source(self, source_config):
        """Add a new threat intelligence source"""
        self.sources.append(source_config)
        self.save_sources()
    
    def remove_source(self, source_name):
        """Remove a source by name"""
        self.sources = [s for s in self.sources if s.get('name') != source_name]
        self.save_sources()
    
    def update_source(self, source_name, updates):
        """Update a source configuration"""
        for source in self.sources:
            if source.get('name') == source_name:
                source.update(updates)
                break
        self.save_sources()
    
    def save_sources(self):
        """Save sources configuration to file"""
        try:
            os.makedirs(os.path.dirname(self.sources_file), exist_ok=True)
            with open(self.sources_file, 'w') as f:
                json.dump(self.sources, f, indent=2)
        except Exception as e:
            print(f"Error saving sources: {e}")
