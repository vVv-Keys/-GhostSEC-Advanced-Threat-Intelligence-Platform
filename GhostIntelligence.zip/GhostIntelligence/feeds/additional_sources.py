"""
Additional Threat Intelligence Sources
Integration with free and open threat intelligence feeds
"""

import asyncio
import aiohttp
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import Dict, List
import logging
import hashlib

class AdditionalSources:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.sources = {
            'abuse_ch_threatfox': {
                'name': 'Abuse.ch ThreatFox',
                'url': 'https://threatfox-api.abuse.ch/api/v1/',
                'method': 'POST',
                'enabled': True,
                'rate_limit': 60  # requests per minute
            },
            'sans_isc': {
                'name': 'SANS ISC',
                'url': 'https://isc.sans.edu/api/dailydetection',
                'method': 'GET',
                'enabled': True,
                'rate_limit': 10
            },
            'circl_cve': {
                'name': 'CIRCL CVE Feed',
                'url': 'https://cve.circl.lu/api/last/100',
                'method': 'GET',
                'enabled': True,
                'rate_limit': 20
            },
            'urlhaus': {
                'name': 'URLhaus',
                'url': 'https://urlhaus-api.abuse.ch/v1/urls/recent/',
                'method': 'GET',
                'enabled': True,
                'rate_limit': 60
            },
            'malware_bazaar': {
                'name': 'MalwareBazaar',
                'url': 'https://mb-api.abuse.ch/api/v1/',
                'method': 'POST',
                'enabled': True,
                'rate_limit': 60
            }
        }
        
    async def fetch_all_sources(self) -> List[Dict]:
        """Fetch from all enabled sources"""
        all_threats = []
        
        tasks = []
        for source_id, config in self.sources.items():
            if config.get('enabled'):
                tasks.append(self.fetch_source(source_id, config))
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    source_id = list(self.sources.keys())[i]
                    self.logger.error(f"Error fetching {source_id}: {result}")
                elif result:
                    all_threats.extend(result)
        
        return all_threats
    
    async def fetch_source(self, source_id: str, config: Dict) -> List[Dict]:
        """Fetch threats from a specific source"""
        try:
            if source_id == 'abuse_ch_threatfox':
                return await self.fetch_threatfox()
            elif source_id == 'sans_isc':
                return await self.fetch_sans_isc()
            elif source_id == 'circl_cve':
                return await self.fetch_circl_cve()
            elif source_id == 'urlhaus':
                return await self.fetch_urlhaus()
            elif source_id == 'malware_bazaar':
                return await self.fetch_malware_bazaar()
            
        except Exception as e:
            self.logger.error(f"Error fetching {source_id}: {e}")
            
        return []
    
    async def fetch_threatfox(self) -> List[Dict]:
        """Fetch from Abuse.ch ThreatFox"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                # Get recent IOCs
                payload = {
                    "query": "get_iocs",
                    "days": 3
                }
                
                async with session.post(
                    'https://threatfox-api.abuse.ch/api/v1/',
                    json=payload,
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get('query_status') == 'ok':
                            for ioc_data in data.get('data', []):
                                threat = self.parse_threatfox_ioc(ioc_data)
                                if threat:
                                    threats.append(threat)
                                    
                        self.logger.info(f"Fetched {len(threats)} threats from ThreatFox")
                        
        except Exception as e:
            self.logger.error(f"Error fetching ThreatFox: {e}")
        
        return threats
    
    def parse_threatfox_ioc(self, ioc_data: Dict) -> Dict:
        """Parse ThreatFox IOC data"""
        try:
            ioc = ioc_data.get('ioc')
            ioc_type = ioc_data.get('ioc_type', '').lower()
            
            # Map IOC types
            type_mapping = {
                'domain': 'domain',
                'ip:port': 'ip',
                'url': 'url',
                'md5_hash': 'hash',
                'sha1_hash': 'hash',
                'sha256_hash': 'hash'
            }
            
            threat_id = hashlib.md5(f"threatfox_{ioc}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"ThreatFox IOC: {ioc}",
                'description': f"Malicious {ioc_type} reported to ThreatFox. Threat: {ioc_data.get('threat_type', 'Unknown')}. Family: {ioc_data.get('malware', 'Unknown')}",
                'severity': self.map_confidence_to_severity(ioc_data.get('confidence_level', 50)),
                'category': self.map_threat_type(ioc_data.get('threat_type', '')),
                'source': 'Abuse.ch ThreatFox',
                'url': f"https://threatfox.abuse.ch/ioc/{ioc_data.get('id', '')}",
                'timestamp': self.parse_timestamp(ioc_data.get('first_seen')),
                'iocs': [ioc] if ioc else [],
                'tags': [
                    ioc_data.get('malware', '').lower(),
                    ioc_data.get('threat_type', '').lower(),
                    'threatfox'
                ],
                'raw_data': ioc_data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing ThreatFox IOC: {e}")
            return None
    
    async def fetch_sans_isc(self) -> List[Dict]:
        """Fetch from SANS ISC"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://isc.sans.edu/api/dailydetection?json') as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        for detection in data.get('dailydetection', []):
                            threat = self.parse_sans_detection(detection)
                            if threat:
                                threats.append(threat)
                                
                        self.logger.info(f"Fetched {len(threats)} threats from SANS ISC")
                        
        except Exception as e:
            self.logger.error(f"Error fetching SANS ISC: {e}")
        
        return threats
    
    def parse_sans_detection(self, detection: Dict) -> Dict:
        """Parse SANS ISC detection data"""
        try:
            title = detection.get('title', 'SANS Detection')
            description = detection.get('description', '')
            
            threat_id = hashlib.md5(f"sans_{title}_{detection.get('date', '')}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"SANS ISC: {title}",
                'description': description,
                'severity': 'medium',
                'category': 'detection',
                'source': 'SANS ISC',
                'url': detection.get('link', 'https://isc.sans.edu'),
                'timestamp': self.parse_timestamp(detection.get('date')),
                'iocs': self.extract_iocs_from_text(description),
                'tags': ['sans', 'detection', 'honeypot'],
                'raw_data': detection
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing SANS detection: {e}")
            return None
    
    async def fetch_circl_cve(self) -> List[Dict]:
        """Fetch from CIRCL CVE feed"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://cve.circl.lu/api/last/50') as response:
                    if response.status == 200:
                        cves = await response.json()
                        
                        for cve in cves:
                            threat = self.parse_circl_cve(cve)
                            if threat:
                                threats.append(threat)
                                
                        self.logger.info(f"Fetched {len(threats)} CVEs from CIRCL")
                        
        except Exception as e:
            self.logger.error(f"Error fetching CIRCL CVE: {e}")
        
        return threats
    
    def parse_circl_cve(self, cve_data: Dict) -> Dict:
        """Parse CIRCL CVE data"""
        try:
            cve_id = cve_data.get('id', '')
            summary = cve_data.get('summary', '')
            
            # Map CVSS score to severity
            cvss = cve_data.get('cvss', 0)
            if cvss >= 9.0:
                severity = 'critical'
            elif cvss >= 7.0:
                severity = 'high'
            elif cvss >= 4.0:
                severity = 'medium'
            else:
                severity = 'low'
            
            threat_id = hashlib.md5(f"circl_{cve_id}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"CVE: {cve_id}",
                'description': summary[:500] + '...' if len(summary) > 500 else summary,
                'severity': severity,
                'category': 'vulnerability',
                'source': 'CIRCL CVE',
                'url': f"https://cve.circl.lu/cve/{cve_id}",
                'timestamp': self.parse_timestamp(cve_data.get('Modified')),
                'iocs': [],
                'tags': ['cve', 'vulnerability', cve_id.lower()],
                'raw_data': {
                    'cve_id': cve_id,
                    'cvss': cvss,
                    'access': cve_data.get('access', {}),
                    'impact': cve_data.get('impact', {})
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing CIRCL CVE: {e}")
            return None
    
    async def fetch_urlhaus(self) -> List[Dict]:
        """Fetch from URLhaus"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://urlhaus-api.abuse.ch/v1/urls/recent/') as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        for url_data in data.get('urls', []):
                            threat = self.parse_urlhaus_url(url_data)
                            if threat:
                                threats.append(threat)
                                
                        self.logger.info(f"Fetched {len(threats)} URLs from URLhaus")
                        
        except Exception as e:
            self.logger.error(f"Error fetching URLhaus: {e}")
        
        return threats
    
    def parse_urlhaus_url(self, url_data: Dict) -> Dict:
        """Parse URLhaus URL data"""
        try:
            url = url_data.get('url', '')
            threat_type = url_data.get('threat', '')
            
            threat_id = hashlib.md5(f"urlhaus_{url}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"Malicious URL: {url[:50]}...",
                'description': f"Malicious URL hosting {threat_type}. Reporter: {url_data.get('reporter', 'Unknown')}",
                'severity': 'high' if 'ransomware' in threat_type.lower() else 'medium',
                'category': 'malware',
                'source': 'URLhaus',
                'url': f"https://urlhaus.abuse.ch/url/{url_data.get('id', '')}",
                'timestamp': self.parse_timestamp(url_data.get('date_added')),
                'iocs': [url],
                'tags': [threat_type.lower(), 'urlhaus', 'malicious_url'],
                'raw_data': url_data
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing URLhaus URL: {e}")
            return None
    
    async def fetch_malware_bazaar(self) -> List[Dict]:
        """Fetch from MalwareBazaar"""
        threats = []
        
        try:
            async with aiohttp.ClientSession() as session:
                payload = {
                    "query": "get_recent",
                    "selector": "time"
                }
                
                async with session.post(
                    'https://mb-api.abuse.ch/api/v1/',
                    json=payload,
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get('query_status') == 'ok':
                            for sample in data.get('data', []):
                                threat = self.parse_malware_sample(sample)
                                if threat:
                                    threats.append(threat)
                                    
                        self.logger.info(f"Fetched {len(threats)} samples from MalwareBazaar")
                        
        except Exception as e:
            self.logger.error(f"Error fetching MalwareBazaar: {e}")
        
        return threats
    
    def parse_malware_sample(self, sample: Dict) -> Dict:
        """Parse MalwareBazaar sample data"""
        try:
            sha256 = sample.get('sha256_hash', '')
            family = sample.get('signature', 'Unknown')
            
            threat_id = hashlib.md5(f"malwarebazaar_{sha256}".encode()).hexdigest()
            
            return {
                'hash': threat_id,
                'title': f"Malware Sample: {family}",
                'description': f"Malware sample ({family}) detected. File type: {sample.get('file_type', 'Unknown')}. Size: {sample.get('file_size', 0)} bytes",
                'severity': 'high',
                'category': 'malware',
                'source': 'MalwareBazaar',
                'url': f"https://bazaar.abuse.ch/sample/{sha256}",
                'timestamp': self.parse_timestamp(sample.get('first_seen')),
                'iocs': [sha256, sample.get('md5_hash', ''), sample.get('sha1_hash', '')],
                'tags': [family.lower(), 'malware', 'sample'],
                'raw_data': sample
            }
            
        except Exception as e:
            self.logger.error(f"Error parsing malware sample: {e}")
            return None
    
    def map_confidence_to_severity(self, confidence: int) -> str:
        """Map confidence level to severity"""
        if confidence >= 90:
            return 'critical'
        elif confidence >= 70:
            return 'high'
        elif confidence >= 50:
            return 'medium'
        else:
            return 'low'
    
    def map_threat_type(self, threat_type: str) -> str:
        """Map threat type to category"""
        threat_type = threat_type.lower()
        
        if 'ransomware' in threat_type:
            return 'ransomware'
        elif 'apt' in threat_type:
            return 'apt'
        elif 'trojan' in threat_type or 'backdoor' in threat_type:
            return 'malware'
        elif 'phish' in threat_type:
            return 'phishing'
        else:
            return 'general'
    
    def parse_timestamp(self, timestamp_str: str) -> str:
        """Parse and normalize timestamp"""
        if not timestamp_str:
            return datetime.utcnow().isoformat()
        
        try:
            # Handle different timestamp formats
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%d',
                '%Y-%m-%dT%H:%M:%SZ'
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(timestamp_str, fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
                    
            # If no format matches, return current time
            return datetime.utcnow().isoformat()
            
        except Exception:
            return datetime.utcnow().isoformat()
    
    def extract_iocs_from_text(self, text: str) -> List[str]:
        """Extract IOCs from text description"""
        import re
        
        iocs = []
        
        # IP addresses
        ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
        iocs.extend(re.findall(ip_pattern, text))
        
        # Domain names
        domain_pattern = r'\b[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}\b'
        iocs.extend(re.findall(domain_pattern, text))
        
        # URLs
        url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
        iocs.extend(re.findall(url_pattern, text))
        
        # File hashes (MD5, SHA1, SHA256)
        hash_pattern = r'\b[a-fA-F0-9]{32,64}\b'
        iocs.extend(re.findall(hash_pattern, text))
        
        # Clean and deduplicate
        cleaned_iocs = []
        for ioc in iocs:
            if isinstance(ioc, tuple):
                ioc = ''.join(ioc)
            
            ioc = ioc.strip()
            if len(ioc) > 3 and ioc not in cleaned_iocs:
                cleaned_iocs.append(ioc)
        
        return cleaned_iocs[:10]  # Limit to 10 IOCs