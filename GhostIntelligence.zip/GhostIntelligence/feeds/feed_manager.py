"""
Feed Manager
Coordinates all threat intelligence feed operations
"""

import asyncio
import aiohttp
import logging
from datetime import datetime
import json

from feeds.sources import ThreatSources
from feeds.parsers import RSSParser, APIParser
from utils.duplicate_filter import DuplicateFilter
from bot.embeds import create_threat_embed
from ml.threat_analyzer import ThreatAnalyzer
from integrations.misp_connector import MISPConnector
from correlation.threat_correlator import ThreatCorrelator
from webhooks.enterprise_webhook import WebhookManager
from notifications.alert_system import AlertNotificationSystem

class FeedManager:
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        threat_sources = ThreatSources()
        self.sources = threat_sources.get_all_sources()
        self.duplicate_filter = DuplicateFilter()
        self.rss_parser = RSSParser()
        self.api_parser = APIParser()
        self.session = None
        
        # Enhanced enterprise components
        self.threat_analyzer = ThreatAnalyzer()
        self.misp_connector = MISPConnector()
        self.correlator = ThreatCorrelator()
        self.webhook_manager = WebhookManager()
        self.notification_system = AlertNotificationSystem()
        
        # Historical threats for training and correlation
        self.historical_threats = []
        
    async def get_session(self):
        """Get or create aiohttp session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={
                    'User-Agent': 'GhostSEC-Bot/1.0 (Threat Intelligence Aggregator)'
                }
            )
        return self.session
    
    async def close_session(self):
        """Close aiohttp session"""
        if self.session and not self.session.closed:
            await self.session.close()
    
    async def update_all_feeds(self):
        """Update all configured threat intelligence feeds"""
        self.logger.info("Starting feed update cycle")
        
        # Group sources by type for efficient processing
        rss_sources = [s for s in self.sources if s.get('type') == 'rss' and s.get('active', True)]
        api_sources = [s for s in self.sources if s.get('type') == 'api' and s.get('active', True)]
        
        # Process feeds concurrently
        tasks = []
        
        # Process RSS feeds
        for source in rss_sources:
            task = asyncio.create_task(self.process_rss_feed(source))
            tasks.append(task)
        
        # Process API feeds
        for source in api_sources:
            task = asyncio.create_task(self.process_api_feed(source))
            tasks.append(task)
        
        # Wait for all feeds to complete
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Count successful vs failed updates
        successful = sum(1 for r in results if not isinstance(r, Exception))
        failed = len(results) - successful
        
        self.logger.info(f"Feed update completed: {successful} successful, {failed} failed")
        
        return successful, failed
    
    async def process_rss_feed(self, source):
        """Process a single RSS feed source"""
        try:
            self.logger.debug(f"Processing RSS feed: {source['name']}")
            session = await self.get_session()
            
            async with session.get(source['url']) as response:
                if response.status == 200:
                    content = await response.text()
                    threats = await self.rss_parser.parse(content, source)
                    
                    for threat in threats:
                        await self.process_threat(threat)
                    
                    self.logger.debug(f"Processed {len(threats)} threats from {source['name']}")
                    return len(threats)
                else:
                    self.logger.warning(f"HTTP {response.status} for {source['name']}")
                    return 0
                    
        except Exception as e:
            self.logger.error(f"Error processing RSS feed {source['name']}: {e}")
            return 0
    
    async def process_api_feed(self, source):
        """Process a single API feed source"""
        try:
            self.logger.debug(f"Processing API feed: {source['name']}")
            session = await self.get_session()
            
            # Prepare headers and auth if needed
            headers = source.get('headers', {})
            if source.get('auth_token'):
                headers['Authorization'] = f"Bearer {source['auth_token']}"
            
            async with session.get(source['url'], headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    threats = await self.api_parser.parse(data, source)
                    
                    for threat in threats:
                        await self.process_threat(threat)
                    
                    self.logger.debug(f"Processed {len(threats)} threats from {source['name']}")
                    return len(threats)
                else:
                    self.logger.warning(f"HTTP {response.status} for {source['name']}")
                    return 0
                    
        except Exception as e:
            self.logger.error(f"Error processing API feed {source['name']}: {e}")
            return 0
    
    async def process_threat(self, threat_data):
        """Enhanced threat processing with ML analysis and correlation"""
        try:
            # Check for duplicates
            if self.duplicate_filter.is_duplicate(threat_data):
                self.logger.debug(f"Skipping duplicate threat: {threat_data.get('title', 'Unknown')}")
                return
            
            # Mark as seen
            self.duplicate_filter.mark_seen(threat_data)
            
            # MISP enrichment
            threat_data = self.misp_connector.enrich_threat_data(threat_data)
            
            # Threat correlation analysis
            correlation_report = self.correlator.add_threat(threat_data)
            threat_data['correlation_analysis'] = correlation_report
            
            # ML-based threat analysis and priority scoring
            priority_analysis = self.threat_analyzer.calculate_threat_priority(
                threat_data, correlation_report
            )
            threat_data['priority_analysis'] = priority_analysis
            
            # Generate comprehensive threat insights
            insights = self.threat_analyzer.get_threat_insights(
                threat_data, correlation_report
            )
            threat_data['insights'] = insights
            
            # Create MISP event if high priority
            if priority_analysis.get('priority_level') in ['critical', 'high']:
                misp_event_id = self.misp_connector.create_event(threat_data)
                if misp_event_id:
                    threat_data['misp_event_id'] = misp_event_id
            
            # Add to historical data for ML training
            self.historical_threats.append(threat_data)
            if len(self.historical_threats) > 1000:
                self.historical_threats = self.historical_threats[-1000:]
            
            # Create enhanced embed with ML insights
            embed = create_threat_embed(threat_data)
            
            # Send to Discord channels
            await self.send_to_channels(embed, threat_data)
            
            # Send to enterprise webhooks
            await self.webhook_manager.send_threat_webhook(threat_data)
            
            # Process custom alert notifications
            await self.notification_system.process_threat_alert(threat_data, self.bot)
            
            # Add to dashboard
            if hasattr(self.bot, 'dashboard'):
                self.bot.dashboard.add_threat(threat_data)
            
            # Increment alert counter
            await self.bot.increment_alerts_sent()
            
            self.logger.info(f"Enhanced threat processing complete: {threat_data.get('title', 'Unknown')} "
                           f"(Priority: {priority_analysis.get('priority_level', 'unknown')}, "
                           f"Correlations: {correlation_report.get('related_threats', 0)})")
            
        except Exception as e:
            self.logger.error(f"Error in enhanced threat processing: {e}")
    
    async def send_to_channels(self, embed, threat_data):
        """Send threat alert to appropriate Discord channels"""
        category = threat_data.get('category', 'general')
        severity = threat_data.get('severity', 'medium')
        
        for guild in self.bot.guilds:
            try:
                # Get appropriate channel based on category/severity
                channel = await self.bot.get_channel_by_category(guild, category)
                
                # For critical threats, also send to critical alerts channel
                if severity == 'critical':
                    critical_channel = await self.bot.get_channel_by_category(guild, 'critical')
                    if critical_channel and critical_channel != channel:
                        await critical_channel.send(embed=embed)
                
                # Send to main category channel
                if channel:
                    await channel.send(embed=embed)
                    self.logger.debug(f"Sent alert to {guild.name}#{channel.name}")
                
            except Exception as e:
                self.logger.error(f"Error sending to {guild.name}: {e}")
    
    async def get_feed_status(self):
        """Get status of all feeds"""
        status = {
            'total_sources': len(self.sources),
            'active_sources': sum(1 for s in self.sources if s.get('active', True)),
            'rss_sources': sum(1 for s in self.sources if s.get('type') == 'rss'),
            'api_sources': sum(1 for s in self.sources if s.get('type') == 'api'),
            'last_update': datetime.utcnow().isoformat()
        }
        return status
