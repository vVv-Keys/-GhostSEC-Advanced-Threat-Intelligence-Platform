"""
Feed Parsers
Parse different types of threat intelligence feeds
"""

import feedparser
import re
import json
from datetime import datetime
from bs4 import BeautifulSoup
import hashlib
import logging

class BaseParser:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def extract_iocs(self, text):
        """Extract Indicators of Compromise from text"""
        if not text:
            return []
        
        iocs = []
        
        # IP addresses (IPv4)
        ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
        iocs.extend(re.findall(ip_pattern, text))
        
        # Domain names
        domain_pattern = r'\b[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}\b'
        domains = re.findall(domain_pattern, text)
        # Filter out common false positives
        filtered_domains = [d for d in domains if not d.endswith(('.com', '.org', '.net', '.gov', '.edu')) or 'malware' in text.lower()]
        iocs.extend(filtered_domains)
        
        # File hashes (MD5, SHA1, SHA256)
        hash_pattern = r'\b[a-fA-F0-9]{32,64}\b'
        iocs.extend(re.findall(hash_pattern, text))
        
        # URLs
        url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+[^\s<>"{}|\\^`\[\].,;:)]'
        iocs.extend(re.findall(url_pattern, text))
        
        # Remove duplicates and return
        return list(set(iocs))
    
    def extract_tags(self, text, categories):
        """Extract relevant tags from text"""
        if not text:
            return []
        
        text_lower = text.lower()
        tags = []
        
        # Common threat keywords
        threat_keywords = [
            'malware', 'ransomware', 'trojan', 'backdoor', 'botnet',
            'phishing', 'scam', 'fraud', 'exploit', 'vulnerability',
            'apt', 'attack', 'breach', 'leak', 'compromise',
            'suspicious', 'malicious', 'threat', 'campaign'
        ]
        
        for keyword in threat_keywords:
            if keyword in text_lower:
                tags.append(keyword)
        
        # Add categories as tags
        if isinstance(categories, list):
            tags.extend(categories)
        elif categories:
            tags.append(categories)
        
        return list(set(tags))
    
    def determine_severity(self, text, default_severity='medium'):
        """Determine threat severity based on content"""
        if not text:
            return default_severity
        
        text_lower = text.lower()
        
        # Critical indicators
        critical_keywords = [
            'critical', 'emergency', 'urgent', 'zero-day', 'zero day',
            'ransomware', 'apt', 'nation-state', 'widespread', 'massive'
        ]
        
        # High severity indicators
        high_keywords = [
            'high', 'severe', 'serious', 'major', 'significant',
            'breach', 'compromise', 'exploit', 'vulnerability'
        ]
        
        # Low severity indicators
        low_keywords = [
            'low', 'minor', 'informational', 'advisory', 'notice'
        ]
        
        if any(keyword in text_lower for keyword in critical_keywords):
            return 'critical'
        elif any(keyword in text_lower for keyword in high_keywords):
            return 'high'
        elif any(keyword in text_lower for keyword in low_keywords):
            return 'low'
        
        return default_severity

class RSSParser(BaseParser):
    def __init__(self):
        super().__init__()
    
    async def parse(self, rss_content, source_config):
        """Parse RSS feed content and extract threat data"""
        threats = []
        
        try:
            feed = feedparser.parse(rss_content)
            
            for entry in feed.entries[:20]:  # Limit to 20 most recent entries
                threat_data = await self.parse_entry(entry, source_config)
                if threat_data:
                    threats.append(threat_data)
                    
        except Exception as e:
            self.logger.error(f"Error parsing RSS feed: {e}")
        
        return threats
    
    async def parse_entry(self, entry, source_config):
        """Parse individual RSS entry"""
        try:
            # Extract basic information
            title = getattr(entry, 'title', 'No title')
            description = getattr(entry, 'description', '') or getattr(entry, 'summary', '')
            link = getattr(entry, 'link', '')
            published = getattr(entry, 'published', '')
            
            # Clean HTML from description
            if description:
                soup = BeautifulSoup(description, 'html.parser')
                description = soup.get_text().strip()
            
            # Combine text for analysis
            full_text = f"{title} {description}"
            
            # Extract IOCs and tags
            iocs = self.extract_iocs(full_text)
            tags = self.extract_tags(full_text, source_config.get('category'))
            
            # Determine severity
            severity = self.determine_severity(full_text, source_config.get('severity_default', 'medium'))
            
            threat_data = {
                'title': title,
                'description': description[:1000] + '...' if len(description) > 1000 else description,
                'url': link,
                'source': source_config.get('name', 'Unknown'),
                'category': source_config.get('category', 'general'),
                'severity': severity,
                'iocs': iocs[:10],  # Limit IOCs
                'tags': tags[:15],   # Limit tags
                'published': published,
                'timestamp': datetime.utcnow().isoformat(),
                'hash': hashlib.md5(f"{title}{link}".encode()).hexdigest()
            }
            
            return threat_data
            
        except Exception as e:
            self.logger.error(f"Error parsing RSS entry: {e}")
            return None

class APIParser(BaseParser):
    def __init__(self):
        super().__init__()
    
    async def parse(self, api_data, source_config):
        """Parse API response data and extract threat data"""
        threats = []
        
        try:
            # Handle different API response formats
            source_name = source_config.get('name', '').lower()
            
            if 'otx' in source_name or 'alienvault' in source_name:
                threats = await self.parse_otx_data(api_data, source_config)
            elif 'virustotal' in source_name:
                threats = await self.parse_virustotal_data(api_data, source_config)
            elif 'shodan' in source_name:
                threats = await self.parse_shodan_data(api_data, source_config)
            elif 'xforce' in source_name:
                threats = await self.parse_xforce_data(api_data, source_config)
            else:
                threats = await self.parse_generic_api_data(api_data, source_config)
                
        except Exception as e:
            self.logger.error(f"Error parsing API data: {e}")
        
        return threats
    
    async def parse_otx_data(self, data, source_config):
        """Parse AlienVault OTX API data"""
        threats = []
        
        try:
            results = data.get('results', [])
            
            for item in results[:20]:
                indicators = item.get('indicators', [])
                iocs = [ind.get('indicator', '') for ind in indicators]
                
                threat_data = {
                    'title': item.get('name', 'OTX Threat Indicator'),
                    'description': item.get('description', 'Threat intelligence from AlienVault OTX'),
                    'url': f"https://otx.alienvault.com/pulse/{item.get('id', '')}",
                    'source': source_config.get('name'),
                    'category': source_config.get('category', 'general'),
                    'severity': self.determine_severity(item.get('description', ''), source_config.get('severity_default')),
                    'iocs': iocs[:10],
                    'tags': item.get('tags', [])[:15],
                    'timestamp': datetime.utcnow().isoformat(),
                    'hash': hashlib.md5(f"{item.get('name', '')}{item.get('id', '')}".encode()).hexdigest()
                }
                
                threats.append(threat_data)
                
        except Exception as e:
            self.logger.error(f"Error parsing OTX data: {e}")
        
        return threats
    
    async def parse_virustotal_data(self, data, source_config):
        """Parse VirusTotal API data"""
        threats = []
        
        try:
            if data.get('response_code') == 1:
                positives = data.get('positives', 0)
                total = data.get('total', 0)
                
                if positives > 0:
                    threat_data = {
                        'title': f"Malicious file detected: {data.get('resource', 'Unknown')}",
                        'description': f"File flagged by {positives}/{total} antivirus engines",
                        'url': data.get('permalink', ''),
                        'source': source_config.get('name'),
                        'category': 'malware',
                        'severity': 'high' if positives > total * 0.5 else 'medium',
                        'iocs': [data.get('resource', '')],
                        'tags': ['malware', 'virustotal'],
                        'timestamp': datetime.utcnow().isoformat(),
                        'hash': hashlib.md5(data.get('resource', '').encode()).hexdigest()
                    }
                    
                    threats.append(threat_data)
                    
        except Exception as e:
            self.logger.error(f"Error parsing VirusTotal data: {e}")
        
        return threats
    
    async def parse_shodan_data(self, data, source_config):
        """Parse Shodan API data"""
        threats = []
        
        try:
            matches = data.get('matches', [])
            
            for match in matches[:10]:
                ip = match.get('ip_str', '')
                port = match.get('port', '')
                product = match.get('product', '')
                
                threat_data = {
                    'title': f"Exposed service: {product} on {ip}:{port}",
                    'description': f"Internet-exposed service detected via Shodan scanning",
                    'url': f"https://www.shodan.io/host/{ip}",
                    'source': source_config.get('name'),
                    'category': 'vulnerability',
                    'severity': source_config.get('severity_default', 'medium'),
                    'iocs': [ip],
                    'tags': ['shodan', 'exposed-service', product.lower() if product else 'unknown'],
                    'timestamp': datetime.utcnow().isoformat(),
                    'hash': hashlib.md5(f"{ip}{port}{product}".encode()).hexdigest()
                }
                
                threats.append(threat_data)
                
        except Exception as e:
            self.logger.error(f"Error parsing Shodan data: {e}")
        
        return threats
    
    async def parse_xforce_data(self, data, source_config):
        """Parse IBM X-Force API data"""
        threats = []
        
        try:
            # X-Force API structure varies by endpoint
            if isinstance(data, list):
                for item in data[:20]:
                    threat_data = {
                        'title': item.get('title', 'X-Force Threat Intelligence'),
                        'description': item.get('description', 'Threat intelligence from IBM X-Force'),
                        'url': item.get('url', ''),
                        'source': source_config.get('name'),
                        'category': source_config.get('category', 'general'),
                        'severity': self.determine_severity(item.get('description', ''), source_config.get('severity_default')),
                        'iocs': self.extract_iocs(item.get('description', '')),
                        'tags': ['xforce'] + self.extract_tags(item.get('description', ''), source_config.get('category')),
                        'timestamp': datetime.utcnow().isoformat(),
                        'hash': hashlib.md5(f"{item.get('title', '')}{item.get('url', '')}".encode()).hexdigest()
                    }
                    
                    threats.append(threat_data)
                    
        except Exception as e:
            self.logger.error(f"Error parsing X-Force data: {e}")
        
        return threats
    
    async def parse_generic_api_data(self, data, source_config):
        """Parse generic API data format"""
        threats = []
        
        try:
            # Try to handle common JSON structures
            items = []
            
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                # Common keys for threat data arrays
                for key in ['data', 'results', 'items', 'threats', 'indicators']:
                    if key in data and isinstance(data[key], list):
                        items = data[key]
                        break
            
            for item in items[:20]:
                if isinstance(item, dict):
                    title = item.get('title') or item.get('name') or item.get('indicator') or 'Generic Threat'
                    description = item.get('description') or item.get('summary') or 'Threat intelligence data'
                    
                    threat_data = {
                        'title': title,
                        'description': description,
                        'url': item.get('url') or item.get('link') or '',
                        'source': source_config.get('name'),
                        'category': source_config.get('category', 'general'),
                        'severity': self.determine_severity(description, source_config.get('severity_default')),
                        'iocs': self.extract_iocs(f"{title} {description}"),
                        'tags': self.extract_tags(f"{title} {description}", source_config.get('category')),
                        'timestamp': datetime.utcnow().isoformat(),
                        'hash': hashlib.md5(f"{title}{description}".encode()).hexdigest()
                    }
                    
                    threats.append(threat_data)
                    
        except Exception as e:
            self.logger.error(f"Error parsing generic API data: {e}")
        
        return threats
