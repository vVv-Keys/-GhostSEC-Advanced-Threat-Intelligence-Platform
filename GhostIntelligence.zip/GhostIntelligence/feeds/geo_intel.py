"""
Geographic Intelligence Module
Real-time threat geolocation and visualization
"""

import asyncio
import aiohttp
import json
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import logging

class GeoIntelligence:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.geo_cache = {}
        self.cache_ttl = timedelta(hours=24)
        
    async def enrich_ioc_geo(self, ioc: str, ioc_type: str) -> Dict:
        """Enrich IOC with geographic information"""
        try:
            if ioc_type == 'ip':
                return await self.get_ip_geolocation(ioc)
            elif ioc_type == 'domain':
                # Resolve domain to IP first, then geolocate
                ip = await self.resolve_domain_to_ip(ioc)
                if ip:
                    geo_data = await self.get_ip_geolocation(ip)
                    geo_data['resolved_ip'] = ip
                    return geo_data
            
            return {}
        except Exception as e:
            self.logger.error(f"Error enriching IOC geo data: {e}")
            return {}
    
    async def get_ip_geolocation(self, ip: str) -> Dict:
        """Get geolocation data for IP address"""
        # Check cache first
        cache_key = f"geo_{ip}"
        if cache_key in self.geo_cache:
            cached_data, timestamp = self.geo_cache[cache_key]
            if datetime.utcnow() - timestamp < self.cache_ttl:
                return cached_data
        
        try:
            async with aiohttp.ClientSession() as session:
                # Use ip-api.com free service
                url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,lat,lon,timezone,isp,org,as,asname"
                
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        
                        if data.get('status') == 'success':
                            geo_data = {
                                'ip': ip,
                                'country': data.get('country'),
                                'country_code': data.get('countryCode'),
                                'region': data.get('regionName'),
                                'city': data.get('city'),
                                'latitude': data.get('lat'),
                                'longitude': data.get('lon'),
                                'isp': data.get('isp'),
                                'organization': data.get('org'),
                                'asn': data.get('as'),
                                'asn_name': data.get('asname'),
                                'timezone': data.get('timezone'),
                                'enriched_at': datetime.utcnow().isoformat()
                            }
                            
                            # Cache the result
                            self.geo_cache[cache_key] = (geo_data, datetime.utcnow())
                            return geo_data
                        else:
                            self.logger.warning(f"Geolocation failed for {ip}: {data.get('message')}")
                            
        except Exception as e:
            self.logger.error(f"Error getting geolocation for {ip}: {e}")
        
        return {}
    
    async def resolve_domain_to_ip(self, domain: str) -> Optional[str]:
        """Resolve domain to IP address"""
        try:
            import socket
            ip = socket.gethostbyname(domain)
            return ip
        except Exception as e:
            self.logger.error(f"Error resolving domain {domain}: {e}")
            return None
    
    def build_threat_heatmap_data(self, threats: List[Dict]) -> Dict:
        """Build data for threat heatmap visualization"""
        country_data = {}
        ip_locations = []
        
        for threat in threats:
            for ioc in threat.get('iocs', []):
                geo_data = threat.get('geo_enrichment', {}).get(ioc, {})
                
                if geo_data:
                    country = geo_data.get('country')
                    country_code = geo_data.get('country_code')
                    lat = geo_data.get('latitude')
                    lon = geo_data.get('longitude')
                    
                    if country and country_code:
                        if country_code not in country_data:
                            country_data[country_code] = {
                                'country': country,
                                'threat_count': 0,
                                'severities': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
                                'categories': {}
                            }
                        
                        country_data[country_code]['threat_count'] += 1
                        severity = threat.get('severity', 'medium').lower()
                        country_data[country_code]['severities'][severity] += 1
                        
                        category = threat.get('category', 'general')
                        country_data[country_code]['categories'][category] = \
                            country_data[country_code]['categories'].get(category, 0) + 1
                    
                    if lat and lon:
                        ip_locations.append({
                            'lat': lat,
                            'lon': lon,
                            'ioc': ioc,
                            'threat_title': threat.get('title', ''),
                            'severity': threat.get('severity', ''),
                            'category': threat.get('category', ''),
                            'country': country,
                            'isp': geo_data.get('isp', ''),
                            'asn': geo_data.get('asn', '')
                        })
        
        return {
            'countries': country_data,
            'locations': ip_locations
        }
    
    def analyze_infrastructure_clusters(self, threats: List[Dict]) -> List[Dict]:
        """Analyze infrastructure clusters for campaign detection"""
        asn_clusters = {}
        ip_blocks = {}
        
        for threat in threats:
            threat_id = threat.get('hash', '')
            
            for ioc in threat.get('iocs', []):
                geo_data = threat.get('geo_enrichment', {}).get(ioc, {})
                
                if geo_data:
                    asn = geo_data.get('asn')
                    ip = geo_data.get('ip')
                    
                    # ASN clustering
                    if asn:
                        if asn not in asn_clusters:
                            asn_clusters[asn] = {
                                'asn': asn,
                                'asn_name': geo_data.get('asn_name', ''),
                                'threats': set(),
                                'iocs': set(),
                                'countries': set(),
                                'first_seen': threat.get('timestamp', ''),
                                'last_seen': threat.get('timestamp', '')
                            }
                        
                        cluster = asn_clusters[asn]
                        cluster['threats'].add(threat_id)
                        cluster['iocs'].add(ioc)
                        cluster['countries'].add(geo_data.get('country', ''))
                        
                        # Update timestamps
                        threat_time = threat.get('timestamp', '')
                        if threat_time < cluster['first_seen']:
                            cluster['first_seen'] = threat_time
                        if threat_time > cluster['last_seen']:
                            cluster['last_seen'] = threat_time
                    
                    # IP block clustering (Class C)
                    if ip and '.' in ip:
                        ip_parts = ip.split('.')
                        if len(ip_parts) == 4:
                            ip_block = f"{ip_parts[0]}.{ip_parts[1]}.{ip_parts[2]}.0/24"
                            
                            if ip_block not in ip_blocks:
                                ip_blocks[ip_block] = {
                                    'ip_block': ip_block,
                                    'threats': set(),
                                    'iocs': set(),
                                    'asn': asn,
                                    'country': geo_data.get('country', ''),
                                    'first_seen': threat.get('timestamp', ''),
                                    'last_seen': threat.get('timestamp', '')
                                }
                            
                            block = ip_blocks[ip_block]
                            block['threats'].add(threat_id)
                            block['iocs'].add(ioc)
        
        # Convert sets to lists and filter significant clusters
        clusters = []
        
        for asn, data in asn_clusters.items():
            if len(data['threats']) >= 2:  # At least 2 threats in same ASN
                data['threats'] = list(data['threats'])
                data['iocs'] = list(data['iocs'])
                data['countries'] = list(data['countries'])
                data['cluster_type'] = 'asn'
                data['significance_score'] = len(data['threats']) * 2 + len(data['iocs'])
                clusters.append(data)
        
        for ip_block, data in ip_blocks.items():
            if len(data['threats']) >= 2:  # At least 2 threats in same IP block
                data['threats'] = list(data['threats'])
                data['iocs'] = list(data['iocs'])
                data['cluster_type'] = 'ip_block'
                data['significance_score'] = len(data['threats']) * 3 + len(data['iocs'])
                clusters.append(data)
        
        # Sort by significance
        clusters.sort(key=lambda x: x['significance_score'], reverse=True)
        return clusters[:20]  # Top 20 clusters