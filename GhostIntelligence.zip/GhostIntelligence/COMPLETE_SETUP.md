# GhostSEC Complete Setup & Configuration Guide

## Current Platform Status
✅ **Dashboard Running**: http://localhost:5000  
✅ **Honeypot Webhooks**: http://localhost:5001  
✅ **Discord Token**: Configured  
✅ **Threat Intelligence Sources**: 15+ sources active  

## Discord Server Setup (Required)

### Step 1: Create Discord Channels
Create these channels in your Discord server for optimal threat routing:

**Essential Channels:**
```
#ghost-alerts         - Main threat feed (all alerts)
#ghost-commands       - Bot commands and responses  
#critical-threats     - Critical severity only
#high-threats         - High priority threats
#malware-alerts       - Malware and trojans
#apt-alerts           - Advanced persistent threats
```

**Optional Channels:**
```
#vulnerability-alerts - CVE and security advisories
#phishing-alerts      - Phishing and social engineering
#ransomware-alerts    - Ransomware activity
#honeypot-alerts      - Honeypot sensor data
```

### Step 2: Bot Permissions
Ensure the GhostSEC bot has these permissions in ALL channels:
- Send Messages
- Embed Links  
- Attach Files
- Use External Emojis
- Add Reactions

### Step 3: Test Discord Integration
```
!ghost ping           - Test bot connectivity
!ghost channels       - List detected channels
!ghost test high      - Send test threat alert
!ghost sources        - Verify threat intelligence sources
```

## Intelligence Sources Configuration

### Currently Active (No API Key Required)
- **Abuse.ch ThreatFox** - Real-time IOC feed
- **URLhaus** - Malicious URL database
- **SANS ISC** - Daily attack summaries  
- **CIRCL CVE** - Latest vulnerabilities
- **DShield** - Scanning activity

### Premium Sources (Optional API Keys)
Add these environment variables for enhanced feeds:

```bash
# AlienVault OTX (Comprehensive IOCs)
export ALIENVAULT_API_KEY="your_otx_api_key"

# VirusTotal (File/URL Analysis) 
export VIRUSTOTAL_API_KEY="your_vt_api_key"

# Shodan (Internet-wide Scanning)
export SHODAN_API_KEY="your_shodan_key"

# IBM X-Force (Threat Reports)
export XFORCE_API_KEY="your_xforce_key"
```

### MISP Integration (Enterprise)
```bash
export MISP_URL="https://your-misp-instance.com"
export MISP_API_KEY="your_misp_api_key"
```

## Notification Enhancements

### Email Alerts
```bash
export SMTP_SERVER="smtp.gmail.com"
export SMTP_USERNAME="alerts@yourdomain.com"  
export SMTP_PASSWORD="your_app_password"
export ALERT_TO_EMAILS="soc@company.com,security@company.com"
```

### Slack Integration
```bash
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
```

### Microsoft Teams
```bash
export TEAMS_WEBHOOK_URL="https://your-teams-webhook-url"
```

### Enterprise SIEM Integration
```bash
# Splunk HEC
export SPLUNK_WEBHOOK="https://splunk.company.com:8088/services/collector"
export SPLUNK_WEBHOOK_SECRET="your_hec_token"

# Elasticsearch
export ELASTICSEARCH_WEBHOOK="https://elastic.company.com:9200/threats/_doc"
```

## Honeypot Integration Setup

### Webhook Endpoints Available
- **Generic Sensor**: `POST http://localhost:5001/webhook/generic`
- **Cowrie SSH**: `POST http://localhost:5001/webhook/cowrie`
- **Dionaea Malware**: `POST http://localhost:5001/webhook/dionaea`
- **DShield Logs**: `POST http://localhost:5001/webhook/dshield`

### Generic Sensor Format
```json
{
  "timestamp": "2025-06-21T14:30:00Z",
  "source_ip": "203.0.113.42",
  "target_port": "22", 
  "event_type": "SSH Brute Force",
  "severity": "high",
  "details": "Multiple failed login attempts detected"
}
```

## Platform Features Overview

### Web Dashboard (http://localhost:5000)
- **Overview Tab**: Real-time statistics and recent threats
- **IOC Database Tab**: Searchable IOC database with correlation graphs
- **Analytics Tab**: Geographic heatmaps, campaign detection, trends
- **Export Tab**: Multi-format exports (JSON, CSV, PDF, STIX, TAXII, MISP, YARA)

### Advanced Analytics
- **Global Threat Heatmap**: Geographic distribution of threats
- **Campaign Detection**: Automated linking of related threats
- **Trend Analysis**: Statistical anomaly detection
- **IOC Correlation**: Network graphs showing threat relationships

### Export Capabilities
- **STIX 2.1**: Industry standard threat intelligence format
- **TAXII 2.0**: Threat intelligence sharing protocol
- **MISP Events**: Compatible with MISP threat sharing platforms
- **YARA Rules**: Automated rule generation from IOCs

## Troubleshooting Common Issues

### Discord Bot Not Responding
1. Verify bot is online in Discord member list
2. Check bot permissions in channels
3. Test basic connectivity: `!ghost ping`
4. Review logs: `tail -f logs/ghostsec_*.log`

### No Threat Alerts Appearing
1. Verify channels exist with correct names
2. Check bot has send message permissions
3. Test with: `!ghost test medium`
4. Review feed status: `!ghost sources`

### Dashboard Not Loading
1. Ensure port 5000 is accessible
2. Check dashboard logs for errors
3. Verify no firewall blocking access
4. Restart dashboard: `python start_dashboard.py`

### Missing Threat Intelligence
1. Check internet connectivity for external feeds
2. Verify API keys if using premium sources
3. Review feed update logs
4. Manual update: `!ghost update`

## Advanced Configuration

### Custom Alert Routing
Edit `config/notifications.json`:
```json
{
  "notification_rules": {
    "critical_malware": {
      "conditions": {
        "min_severity": "critical",
        "categories": ["malware", "ransomware"]
      },
      "delivery_methods": ["discord", "email", "slack"],
      "priority": 1
    }
  }
}
```

### Webhook Configuration
Edit `config/webhooks.json`:
```json
{
  "webhooks": [
    {
      "name": "SOC SIEM",
      "url": "https://siem.company.com/webhook",
      "enabled": true,
      "filters": {
        "min_severity": "medium"
      }
    }
  ]
}
```

## Security Recommendations

### Production Deployment
1. Use HTTPS for all webhook endpoints
2. Implement API key authentication
3. Configure firewall rules (ports 5000, 5001)
4. Use environment variables for all secrets
5. Enable log rotation and monitoring

### Data Privacy
1. Configure threat data retention limits
2. Sanitize logs of sensitive information
3. Implement access controls for dashboard
4. Regular security updates and patches

## API Testing Commands

### Test Threat Intelligence Sources
```bash
# Test ThreatFox API
curl -X POST "https://threatfox-api.abuse.ch/api/v1/" \
  -H "Content-Type: application/json" \
  -d '{"query":"get_iocs","days":1}'

# Test SANS ISC API  
curl "https://isc.sans.edu/api/dailydetection?json"

# Test URLhaus API
curl "https://urlhaus-api.abuse.ch/v1/urls/recent/"
```

### Test Dashboard APIs
```bash
# Get dashboard statistics
curl http://localhost:5000/api/stats

# Get recent threats
curl http://localhost:5000/api/threats

# Get IOC database
curl http://localhost:5000/api/ioc-database

# Get geographic heatmap
curl http://localhost:5000/api/geo-heatmap
```

### Test Honeypot Webhooks
```bash
# Test generic webhook
curl -X POST http://localhost:5001/webhook/generic \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2025-06-21T14:30:00Z",
    "source_ip": "203.0.113.42",
    "event_type": "Test Alert",
    "severity": "medium"
  }'

# Check webhook health
curl http://localhost:5001/health
```

## Performance Optimization

### System Requirements
- **RAM**: 2GB minimum, 4GB recommended
- **CPU**: 2 cores minimum
- **Storage**: 10GB for logs and data
- **Network**: Stable internet for feed updates

### Configuration Tuning
```bash
# Update frequency (minutes)
export GHOSTSEC_UPDATE_INTERVAL=15

# Maximum threat cache
export GHOSTSEC_MAX_THREATS=1000

# Geographic data cache (hours)
export GHOSTSEC_GEO_CACHE_TTL=24

# Debug mode (disable in production)
export GHOSTSEC_DEBUG=false
```

## Next Steps

1. **Create Discord channels** using the naming guide above
2. **Test bot connectivity** with `!ghost ping`
3. **Configure optional API keys** for enhanced intelligence
4. **Set up notifications** (email/Slack/Teams) as needed
5. **Access the dashboard** at http://localhost:5000
6. **Test honeypot integration** if using sensors

Your GhostSEC platform is now fully operational with comprehensive threat intelligence capabilities!