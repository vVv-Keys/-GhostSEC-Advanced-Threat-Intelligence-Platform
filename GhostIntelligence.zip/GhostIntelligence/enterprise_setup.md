# GhostSEC Enterprise Setup Guide

## Complete Enterprise Threat Intelligence Platform

This guide covers the advanced enterprise features including machine learning, MISP integration, correlation analysis, and the interactive dashboard.

## Quick Start

1. **Basic Setup**
   ```bash
   # Set Discord token
   export DISCORD_TOKEN="your_discord_bot_token"
   
   # Run the enhanced bot
   python start_ghostsec.py
   ```

2. **Access Dashboard**
   - Open browser to `http://localhost:5000`
   - View real-time threat intelligence
   - Explore IOC correlation maps
   - Export threat data

## Enterprise Integration

### MISP (Malware Information Sharing Platform)
```bash
export MISP_URL="https://your-misp-instance.com"
export MISP_API_KEY="your_misp_api_key"
```

**Features:**
- Automatic IOC enrichment
- Event creation for high-priority threats
- Correlation with existing MISP data
- Support for multiple instances

### Splunk Integration
```bash
export SPLUNK_WEBHOOK="https://your-splunk.com:8088/services/collector"
export SPLUNK_WEBHOOK_SECRET="your_hec_token"
```

**Data Format:** Splunk HEC JSON with threat intelligence metadata

### Elasticsearch Integration
```bash
export ELASTICSEARCH_WEBHOOK="https://your-elasticsearch.com:9200/threats/_doc"
```

**Index Structure:** Optimized for threat hunting and analytics

### IBM QRadar / Microsoft Sentinel
```bash
export QRADAR_WEBHOOK="https://your-qradar.com/api/siem/offenses"
export SENTINEL_WEBHOOK="https://your-sentinel-workspace.com/webhook"
```

**Format:** CEF (Common Event Format) for SIEM ingestion

## Machine Learning Features

### Threat Priority Scoring
- **Algorithm:** Random Forest with 7 feature categories
- **Features:** Severity, source reliability, IOC count, text complexity, temporal urgency
- **Training:** Automatic retraining every 6 hours with new data
- **Accuracy:** Continuously improving with threat history

### Anomaly Detection
- **Method:** Isolation Forest for outlier detection
- **Purpose:** Identify unusual threat patterns
- **Threshold:** Configurable contamination level

### Text Analysis
- **Vectorization:** TF-IDF with 1000 features
- **Similarity:** Cosine similarity for threat correlation
- **Language:** English stop words removal

## Advanced Correlation Engine

### IOC Correlation
- **Jaccard Similarity:** Shared IOCs between threats
- **High-Value IOCs:** File hashes and specific IPs weighted higher
- **Index:** Real-time IOC lookup for fast correlation

### Temporal Clustering
- **Time Windows:** 30min, 2hr, 6hr, 24hr analysis
- **Campaign Detection:** Groups of related threats in time
- **Burst Analysis:** Identifies coordinated attack activity

### Tactical Correlation
- **MITRE ATT&CK:** Technique and tactic mapping
- **Pattern Recognition:** Known attack sequences
- **TTP Analysis:** Behavior-based threat grouping

## Alert Notification System

### Email Notifications
```bash
export SMTP_SERVER="smtp.gmail.com"
export SMTP_PORT="587"
export SMTP_USERNAME="your_email@company.com"
export SMTP_PASSWORD="your_app_password"
export ALERT_TO_EMAILS="soc@company.com,security@company.com"
```

**Features:**
- Rich HTML formatting
- Severity-based color coding
- IOC extraction and display
- Mobile-friendly design

### Slack Integration
```bash
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
export SLACK_ALERT_CHANNEL="#security-alerts"
```

**Message Format:**
- Color-coded attachments
- Threat metadata fields
- Interactive buttons for actions

### Microsoft Teams
```bash
export TEAMS_WEBHOOK_URL="https://your-teams-webhook-url"
```

**Card Format:**
- MessageCard schema
- Actionable buttons
- Rich threat visualization

### SMS Alerts (Twilio)
```bash
export TWILIO_ACCOUNT_SID="your_account_sid"
export TWILIO_AUTH_TOKEN="your_auth_token"
export TWILIO_PHONE_NUMBER="+1234567890"
export ALERT_PHONE_NUMBERS="+1987654321,+1555123456"
```

## Dashboard Features

### Real-Time Visualization
- **Threat Timeline:** 24-hour activity charts
- **Severity Distribution:** Pie charts with color coding
- **Source Activity:** Bar charts of feed productivity
- **IOC Network:** Interactive correlation graphs

### Advanced Search
- **Full-Text Search:** Title, description, IOCs, tags
- **Filter Options:** Severity, category, source, time range
- **Export Capabilities:** JSON, CSV formats
- **Pagination:** Efficient handling of large datasets

### Network Visualization
- **Graph Library:** NetworkX with spring layout
- **Node Properties:** Threat metadata and severity
- **Edge Weights:** Correlation strength visualization
- **Interactive:** Hover details and zoom capabilities

## Configuration Files

### Webhook Configuration (`config/webhooks.json`)
```json
{
  "webhooks": [
    {
      "name": "SOC SIEM",
      "url": "https://siem.company.com/webhook",
      "secret": "webhook_secret",
      "enabled": true,
      "filters": {
        "min_severity": "medium",
        "categories": ["malware", "apt", "breach"]
      }
    }
  ]
}
```

### Notification Rules (`config/notifications.json`)
```json
{
  "notification_rules": [
    {
      "name": "critical_alerts",
      "conditions": {
        "min_severity": "critical",
        "categories": ["ransomware", "apt"]
      },
      "delivery_methods": ["email", "sms", "slack"]
    }
  ]
}
```

## Performance Optimization

### Concurrent Processing
- **Async Operations:** Non-blocking threat processing
- **Queue Management:** Background webhook delivery
- **Connection Pooling:** Efficient HTTP request handling

### Caching Strategy
- **Duplicate Filter:** Hash-based with configurable TTL
- **IOC Index:** Fast lookup for correlation analysis
- **ML Models:** Persistent storage with pickle serialization

### Memory Management
- **Historical Data:** Automatic cleanup of old threats
- **Model Training:** Incremental learning with batch processing
- **Dashboard Data:** Efficient storage with pagination

## Monitoring and Analytics

### Bot Statistics
- **Threat Processing:** Count, timing, success rates
- **ML Performance:** Model accuracy, training metrics
- **Webhook Delivery:** Success rates, retry statistics
- **Correlation Analysis:** Pattern detection, campaign identification

### Health Checks
- **Service Status:** MISP, webhook endpoints, dashboard
- **Data Flow:** Feed processing, correlation pipeline
- **Performance Metrics:** Response times, queue sizes

## Security Considerations

### API Key Management
- **Environment Variables:** Secure storage of credentials
- **Webhook Signatures:** HMAC validation for authenticity
- **HTTPS Only:** Encrypted communication channels

### Data Privacy
- **No Data Retention:** Configurable threat history limits
- **Sanitized Logs:** No sensitive data in debug output
- **Access Control:** Permission-based command restrictions

## Troubleshooting

### Common Issues
1. **Dashboard Not Loading:** Check port 5000 availability
2. **MISP Connection Failed:** Verify URL and API key
3. **Webhook Delivery Failed:** Check endpoint status and authentication
4. **ML Training Errors:** Ensure sufficient historical data (50+ samples)

### Debug Commands
```bash
# Check ML status
!ghost ml

# View webhook statistics
!ghost webhooks

# Test correlation engine
!ghost correlate malware

# Export data for analysis
!ghost export json 500
```

### Log Analysis
```bash
# View detailed logs
tail -f logs/ghostsec_*.log

# Filter for specific components
grep "ML\|correlation\|webhook" logs/ghostsec_*.log
```

## Advanced Use Cases

### Threat Hunting
1. Use correlation commands to find related threats
2. Export data for external analysis tools
3. Leverage MISP integration for intelligence sharing

### Incident Response
1. Configure critical alert notifications
2. Set up webhook integration with ticketing systems
3. Use dashboard for real-time threat monitoring

### Security Analytics
1. Export threat data for data science analysis
2. Train custom ML models with historical data
3. Integrate with existing security orchestration platforms

This enterprise setup provides a comprehensive threat intelligence platform with advanced analytics, machine learning, and extensive integration capabilities.