# Discord Bot Setup Guide

## Generate Your Bot Invite Link

### Step 1: Get Your Bot Client ID
1. Go to: https://discord.com/developers/applications
2. Select your GhostSEC application 
3. Navigate to "General Information"
4. Copy the "Application ID" (this is your Client ID)

### Step 2: Create Invite URL
Replace `YOUR_BOT_CLIENT_ID` with your actual Client ID:

```
https://discord.com/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=2147862592&scope=bot%20applications.commands
```

## Required Discord Channels

Create these channels in your Discord server for optimal threat routing:

### Essential Channels
- `#ghost-alerts` - Main threat intelligence feed
- `#ghost-commands` - Bot commands and responses
- `#critical-threats` - Critical severity alerts only
- `#high-threats` - High priority threats
- `#malware-alerts` - Malware and trojan activity
- `#apt-alerts` - Advanced persistent threats

### Optional Channels
- `#vulnerability-alerts` - CVE and security advisories
- `#phishing-alerts` - Phishing campaigns
- `#ransomware-alerts` - Ransomware activity
- `#honeypot-alerts` - Honeypot sensor data

## Bot Permissions Required

The bot needs these permissions in ALL channels:
- Send Messages
- Embed Links
- Attach Files
- Read Message History
- Use External Emojis
- Add Reactions

## Test Commands

After inviting the bot, test with:
```
!ghost ping          - Test connectivity
!ghost status        - Show bot statistics
!ghost channels      - List available channels
!ghost test high     - Send test threat alert
!ghost sources       - List threat intelligence sources
```

## Current API Status

Premium intelligence sources now active:
- AlienVault OTX: Connected
- VirusTotal: API validated
- Shodan: Operational (OSS plan)

Platform services running:
- Dashboard: http://localhost:5000
- Honeypot webhooks: http://localhost:5001