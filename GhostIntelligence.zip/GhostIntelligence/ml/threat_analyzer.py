"""
Machine Learning Threat Analysis Engine
Advanced threat correlation and priority scoring using ML algorithms
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
import pickle
import logging
from datetime import datetime, timedelta
from pathlib import Path
import hashlib
import json

class ThreatAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.model_path = Path("ml/models")
        self.model_path.mkdir(exist_ok=True)
        
        # Initialize ML models
        self.priority_classifier = None
        self.anomaly_detector = None
        self.text_vectorizer = None
        self.scaler = None
        
        # Feature weights for threat scoring
        self.feature_weights = {
            'severity_score': 0.25,
            'source_reliability': 0.20,
            'ioc_count': 0.15,
            'text_complexity': 0.15,
            'temporal_urgency': 0.10,
            'correlation_factor': 0.10,
            'historical_impact': 0.05
        }
        
        # Load or initialize models
        self.load_models()
        
    def load_models(self):
        """Load pre-trained models or initialize new ones"""
        try:
            # Load priority classifier
            priority_model_file = self.model_path / "priority_classifier.pkl"
            if priority_model_file.exists():
                with open(priority_model_file, 'rb') as f:
                    self.priority_classifier = pickle.load(f)
                    
            # Load anomaly detector
            anomaly_model_file = self.model_path / "anomaly_detector.pkl"
            if anomaly_model_file.exists():
                with open(anomaly_model_file, 'rb') as f:
                    self.anomaly_detector = pickle.load(f)
                    
            # Load text vectorizer
            vectorizer_file = self.model_path / "text_vectorizer.pkl"
            if vectorizer_file.exists():
                with open(vectorizer_file, 'rb') as f:
                    self.text_vectorizer = pickle.load(f)
                    
            self.logger.info("ML models loaded successfully")
            
        except Exception as e:
            self.logger.warning(f"Could not load ML models: {e}")
            self.initialize_models()
    
    def initialize_models(self):
        """Initialize new ML models with default parameters"""
        self.priority_classifier = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        
        self.anomaly_detector = IsolationForest(
            contamination=0.1,
            random_state=42
        )
        
        self.text_vectorizer = TfidfVectorizer(
            max_features=1000,
            stop_words='english',
            ngram_range=(1, 2)
        )
        
        self.scaler = StandardScaler()
        
        self.logger.info("New ML models initialized")
    
    def extract_threat_features(self, threat_data):
        """Extract comprehensive features from threat data for ML analysis"""
        features = {}
        
        # Basic threat information
        title = threat_data.get('title', '')
        description = threat_data.get('description', '')
        severity = threat_data.get('severity', 'medium')
        source = threat_data.get('source', '')
        category = threat_data.get('category', 'general')
        iocs = threat_data.get('iocs', [])
        tags = threat_data.get('tags', [])
        
        # Severity scoring
        severity_map = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}
        features['severity_score'] = severity_map.get(severity.lower(), 2)
        
        # Source reliability scoring
        source_reliability = {
            'us-cert': 0.95, 'nist': 0.95, 'sans': 0.90,
            'cisco': 0.85, 'fireeye': 0.90, 'virustotal': 0.80,
            'shodan': 0.75, 'alienvault': 0.70
        }
        
        source_key = next((k for k in source_reliability.keys() 
                          if k in source.lower()), 'unknown')
        features['source_reliability'] = source_reliability.get(source_key, 0.5)
        
        # IOC analysis
        features['ioc_count'] = len(iocs)
        features['has_ip'] = any('.' in ioc and ioc.replace('.', '').isdigit() 
                               for ioc in iocs)
        features['has_domain'] = any('.' in ioc and not ioc.replace('.', '').isdigit() 
                                   for ioc in iocs)
        features['has_hash'] = any(len(ioc) in [32, 40, 64] and 
                                 all(c in '0123456789abcdefABCDEF' for c in ioc) 
                                 for ioc in iocs)
        
        # Text complexity analysis
        full_text = f"{title} {description}".lower()
        features['text_length'] = len(full_text)
        features['word_count'] = len(full_text.split())
        features['sentence_count'] = full_text.count('.') + full_text.count('!') + full_text.count('?')
        
        # Threat keywords presence
        critical_keywords = [
            'zero-day', 'zero day', 'rce', 'remote code execution',
            'critical', 'emergency', 'ransomware', 'apt', 'nation-state',
            'breach', 'compromise', 'exploit', 'vulnerability'
        ]
        
        features['critical_keyword_count'] = sum(1 for keyword in critical_keywords 
                                                if keyword in full_text)
        
        # Category scoring
        category_priority = {
            'apt': 4, 'ransomware': 4, 'breach': 3, 'malware': 3,
            'vulnerability': 2, 'phishing': 2, 'general': 1
        }
        features['category_priority'] = category_priority.get(category.lower(), 1)
        
        # Temporal urgency (recent threats are more urgent)
        try:
            timestamp = datetime.fromisoformat(threat_data.get('timestamp', 
                                             datetime.utcnow().isoformat()))
            hours_ago = (datetime.utcnow() - timestamp).total_seconds() / 3600
            features['temporal_urgency'] = max(0, 1 - (hours_ago / 24))  # Decay over 24 hours
        except:
            features['temporal_urgency'] = 0.5
        
        return features
    
    def calculate_threat_priority(self, threat_data, correlation_data=None):
        """Calculate ML-based threat priority score"""
        try:
            features = self.extract_threat_features(threat_data)
            
            # Add correlation factor if available
            if correlation_data:
                features['correlation_factor'] = correlation_data.get('correlation_score', 0)
                features['related_threats'] = correlation_data.get('related_count', 0)
            else:
                features['correlation_factor'] = 0
                features['related_threats'] = 0
            
            # Calculate weighted priority score
            priority_score = 0
            for feature, weight in self.feature_weights.items():
                if feature in features:
                    normalized_value = min(features[feature], 1.0)  # Normalize to 0-1
                    priority_score += normalized_value * weight
            
            # Apply ML classifier if trained
            if self.priority_classifier and hasattr(self.priority_classifier, 'predict_proba'):
                try:
                    feature_vector = self.prepare_feature_vector(features)
                    ml_proba = self.priority_classifier.predict_proba([feature_vector])[0]
                    ml_score = np.max(ml_proba)
                    priority_score = 0.7 * priority_score + 0.3 * ml_score
                except:
                    pass  # Fall back to manual scoring
            
            # Normalize to 0-100 scale
            priority_score = min(100, max(0, priority_score * 100))
            
            # Determine priority level
            if priority_score >= 80:
                priority_level = 'critical'
            elif priority_score >= 60:
                priority_level = 'high'
            elif priority_score >= 40:
                priority_level = 'medium'
            else:
                priority_level = 'low'
            
            return {
                'priority_score': round(priority_score, 2),
                'priority_level': priority_level,
                'confidence': min(95, 60 + (priority_score * 0.35)),
                'features_analyzed': len(features),
                'ml_enhanced': self.priority_classifier is not None
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating threat priority: {e}")
            return {
                'priority_score': 50.0,
                'priority_level': 'medium',
                'confidence': 50.0,
                'features_analyzed': 0,
                'ml_enhanced': False
            }
    
    def prepare_feature_vector(self, features):
        """Prepare feature vector for ML models"""
        # Define expected feature order
        feature_order = [
            'severity_score', 'source_reliability', 'ioc_count', 'text_length',
            'word_count', 'critical_keyword_count', 'category_priority',
            'temporal_urgency', 'correlation_factor', 'has_ip', 'has_domain', 'has_hash'
        ]
        
        vector = []
        for feature in feature_order:
            value = features.get(feature, 0)
            if isinstance(value, bool):
                value = 1 if value else 0
            vector.append(float(value))
        
        return np.array(vector)
    
    def detect_anomalies(self, threat_data_list):
        """Detect anomalous threats using isolation forest"""
        if not threat_data_list or len(threat_data_list) < 5:
            return []
        
        try:
            # Extract features for all threats
            feature_vectors = []
            for threat in threat_data_list:
                features = self.extract_threat_features(threat)
                vector = self.prepare_feature_vector(features)
                feature_vectors.append(vector)
            
            feature_matrix = np.array(feature_vectors)
            
            # Detect anomalies
            if self.anomaly_detector is None:
                self.anomaly_detector = IsolationForest(contamination=0.1, random_state=42)
            
            anomaly_scores = self.anomaly_detector.fit_predict(feature_matrix)
            
            # Return indices of anomalous threats
            anomalous_indices = [i for i, score in enumerate(anomaly_scores) if score == -1]
            
            self.logger.info(f"Detected {len(anomalous_indices)} anomalous threats out of {len(threat_data_list)}")
            
            return anomalous_indices
            
        except Exception as e:
            self.logger.error(f"Error detecting anomalies: {e}")
            return []
    
    def correlate_threats(self, threat_data, historical_threats):
        """Find correlations between current threat and historical data"""
        try:
            current_iocs = set(threat_data.get('iocs', []))
            current_tags = set(threat_data.get('tags', []))
            current_source = threat_data.get('source', '')
            
            correlations = []
            
            for historical in historical_threats[-100:]:  # Check last 100 threats
                try:
                    hist_iocs = set(historical.get('iocs', []))
                    hist_tags = set(historical.get('tags', []))
                    hist_source = historical.get('source', '')
                    
                    # Calculate correlation score
                    ioc_overlap = len(current_iocs & hist_iocs)
                    tag_overlap = len(current_tags & hist_tags)
                    source_match = 1 if current_source == hist_source else 0
                    
                    correlation_score = (ioc_overlap * 0.5 + tag_overlap * 0.3 + source_match * 0.2)
                    
                    if correlation_score > 0.5:
                        correlations.append({
                            'threat_id': historical.get('hash', ''),
                            'correlation_score': correlation_score,
                            'shared_iocs': list(current_iocs & hist_iocs),
                            'shared_tags': list(current_tags & hist_tags),
                            'timestamp': historical.get('timestamp', '')
                        })
                        
                except:
                    continue
            
            # Sort by correlation score
            correlations.sort(key=lambda x: x['correlation_score'], reverse=True)
            
            return {
                'correlation_score': max([c['correlation_score'] for c in correlations], default=0),
                'related_count': len(correlations),
                'correlations': correlations[:5]  # Top 5 correlations
            }
            
        except Exception as e:
            self.logger.error(f"Error correlating threats: {e}")
            return {'correlation_score': 0, 'related_count': 0, 'correlations': []}
    
    def train_models(self, training_data):
        """Train ML models with historical threat data"""
        if len(training_data) < 50:
            self.logger.warning("Insufficient training data for ML models")
            return False
        
        try:
            # Prepare training data
            features_list = []
            labels = []
            
            for threat in training_data:
                features = self.extract_threat_features(threat)
                vector = self.prepare_feature_vector(features)
                features_list.append(vector)
                
                # Create label based on severity and priority
                severity = threat.get('severity', 'medium')
                label_map = {'low': 0, 'medium': 1, 'high': 2, 'critical': 3}
                labels.append(label_map.get(severity.lower(), 1))
            
            feature_matrix = np.array(features_list)
            labels = np.array(labels)
            
            # Train priority classifier
            self.priority_classifier.fit(feature_matrix, labels)
            
            # Train anomaly detector
            self.anomaly_detector.fit(feature_matrix)
            
            # Save trained models
            self.save_models()
            
            self.logger.info(f"ML models trained successfully with {len(training_data)} samples")
            return True
            
        except Exception as e:
            self.logger.error(f"Error training ML models: {e}")
            return False
    
    def save_models(self):
        """Save trained ML models to disk"""
        try:
            if self.priority_classifier:
                with open(self.model_path / "priority_classifier.pkl", 'wb') as f:
                    pickle.dump(self.priority_classifier, f)
            
            if self.anomaly_detector:
                with open(self.model_path / "anomaly_detector.pkl", 'wb') as f:
                    pickle.dump(self.anomaly_detector, f)
            
            if self.text_vectorizer:
                with open(self.model_path / "text_vectorizer.pkl", 'wb') as f:
                    pickle.dump(self.text_vectorizer, f)
            
            self.logger.info("ML models saved successfully")
            
        except Exception as e:
            self.logger.error(f"Error saving ML models: {e}")
    
    def get_threat_insights(self, threat_data, correlation_data=None):
        """Generate comprehensive threat insights"""
        features = self.extract_threat_features(threat_data)
        priority = self.calculate_threat_priority(threat_data, correlation_data)
        
        insights = {
            'priority_analysis': priority,
            'risk_factors': [],
            'recommendations': [],
            'technical_details': features
        }
        
        # Generate risk factors
        if features['severity_score'] >= 3:
            insights['risk_factors'].append("High severity threat requiring immediate attention")
        
        if features['critical_keyword_count'] > 2:
            insights['risk_factors'].append("Contains multiple critical security keywords")
        
        if features['ioc_count'] > 5:
            insights['risk_factors'].append("High number of indicators suggests active campaign")
        
        if correlation_data and correlation_data['related_count'] > 3:
            insights['risk_factors'].append("Strong correlation with recent threat activity")
        
        # Generate recommendations
        if priority['priority_level'] in ['critical', 'high']:
            insights['recommendations'].append("Implement immediate protective measures")
            insights['recommendations'].append("Monitor network for related IOCs")
        
        if features['has_hash']:
            insights['recommendations'].append("Update antivirus signatures and scan systems")
        
        if features['has_ip'] or features['has_domain']:
            insights['recommendations'].append("Block suspicious network indicators")
        
        return insights