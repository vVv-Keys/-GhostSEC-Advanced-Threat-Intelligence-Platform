#!/usr/bin/env python3
"""
GhostSEC Bot Launcher
Production launcher with enhanced error handling and status reporting
"""

import asyncio
import os
import sys
import signal
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent))

from bot.bot import GhostSECBot
from utils.logger import setup_logger
from config.settings import Settings

def signal_handler(signum, frame):
    print("\nReceived shutdown signal. Gracefully stopping bot...")
    sys.exit(0)

async def main():
    """Enhanced main launcher with comprehensive status reporting"""
    
    # Setup signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Setup logging
    logger = setup_logger()
    logger.info("=" * 60)
    logger.info("🚀 Starting GhostSEC Threat Intelligence Bot")
    logger.info("=" * 60)
    
    # Load settings
    settings = Settings()
    logger.info(f"Configuration loaded: {settings.BOT_NAME}")
    
    # Check Discord token
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        logger.error("❌ DISCORD_TOKEN environment variable not set")
        logger.error("Please set your Discord bot token and restart")
        sys.exit(1)
    
    logger.info("✅ Discord token found")
    
    # Initialize and start bot
    try:
        logger.info("🔧 Initializing bot components...")
        bot = GhostSECBot(settings)
        
        logger.info(f"📡 Loaded {len(bot.feed_manager.sources)} threat intelligence sources")
        logger.info(f"🟢 Active sources: {len([s for s in bot.feed_manager.sources if s.get('active', True)])}")
        logger.info(f"⚙️ Update interval: {settings.UPDATE_INTERVAL_MINUTES} minutes")
        
        logger.info("🌐 Connecting to Discord...")
        await bot.start(token)
        
    except Exception as e:
        error_msg = str(e)
        if "privileged intents" in error_msg.lower():
            logger.error("❌ Discord Privileged Intents Error")
            logger.error("🔧 Please enable 'Message Content Intent' in Discord Developer Portal:")
            logger.error("   1. Visit https://discord.com/developers/applications")
            logger.error("   2. Select your application")
            logger.error("   3. Go to Bot section")
            logger.error("   4. Enable 'Message Content Intent' under Privileged Gateway Intents")
            logger.error("   5. Save changes and restart the bot")
        elif "login" in error_msg.lower() or "token" in error_msg.lower():
            logger.error("❌ Discord Authentication Error")
            logger.error("🔧 Please check your Discord bot token:")
            logger.error("   1. Verify the token is correct")
            logger.error("   2. Ensure the bot hasn't been regenerated")
            logger.error("   3. Check token permissions")
        else:
            logger.error(f"❌ Unexpected error: {error_msg}")
            
    except KeyboardInterrupt:
        logger.info("🛑 Bot shutdown requested by user")
    finally:
        if 'bot' in locals():
            logger.info("🧹 Cleaning up bot resources...")
            await bot.close()
            if hasattr(bot.feed_manager, 'session'):
                await bot.feed_manager.close_session()
        logger.info("✅ GhostSEC Bot stopped gracefully")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    except Exception as e:
        print(f"❌ Failed to start bot: {e}")