"""
GhostSEC Web Dashboard
Interactive threat intelligence dashboard with real-time visualization
"""

import flask
from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_cors import CORS
import json
import logging
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
import plotly.graph_objs as go
import plotly.utils
import networkx as nx
import pandas as pd
from collections import defaultdict, Counter
from typing import Dict, List
import asyncio

class ThreatDashboard:
    def __init__(self, bot=None, port=5000):
        self.bot = bot
        self.port = port
        self.app = Flask(__name__, 
                        template_folder='dashboard/templates',
                        static_folder='dashboard/static')
        CORS(self.app)
        self.logger = logging.getLogger(__name__)
        
        # Dashboard data storage
        self.dashboard_data = {
            'threats': [],
            'statistics': {},
            'correlations': [],
            'real_time_feed': [],
            'ioc_network': {},
            'severity_trends': [],
            'source_activity': {}
        }
        
        # Setup routes
        self.setup_routes()
        
        # Start background data collector
        self.data_collector_thread = None
        self.running = False
    
    def setup_routes(self):
        """Setup Flask routes for dashboard"""
        
        @self.app.route('/')
        def dashboard_home():
            return render_template('dashboard.html')
        
        @self.app.route('/api/stats')
        def get_dashboard_stats():
            """Get overall dashboard statistics"""
            return jsonify(self.get_statistics())
        
        @self.app.route('/api/threats')
        def get_threats():
            """Get recent threats with pagination"""
            page = int(request.args.get('page', 1))
            per_page = int(request.args.get('per_page', 20))
            severity = request.args.get('severity', 'all')
            
            threats = self.dashboard_data['threats']
            
            # Filter by severity if specified
            if severity != 'all':
                threats = [t for t in threats if t.get('severity', '').lower() == severity.lower()]
            
            # Pagination
            start = (page - 1) * per_page
            end = start + per_page
            
            return jsonify({
                'threats': threats[start:end],
                'total': len(threats),
                'page': page,
                'per_page': per_page,
                'has_next': end < len(threats)
            })
        
        @self.app.route('/api/severity-chart')
        def get_severity_chart():
            """Get severity distribution chart data"""
            threats = self.dashboard_data['threats']
            severity_counts = Counter(t.get('severity', 'unknown').lower() for t in threats)
            
            colors = {
                'critical': '#ff0000',
                'high': '#ff8000', 
                'medium': '#ffff00',
                'low': '#00ff00',
                'unknown': '#888888'
            }
            
            data = {
                'labels': list(severity_counts.keys()),
                'values': list(severity_counts.values()),
                'colors': [colors.get(sev, '#888888') for sev in severity_counts.keys()]
            }
            
            return jsonify(data)
        
        @self.app.route('/api/timeline-chart')
        def get_timeline_chart():
            """Get threat timeline chart data"""
            threats = self.dashboard_data['threats']
            
            # Group threats by hour for last 24 hours
            now = datetime.utcnow()
            hourly_counts = defaultdict(int)
            
            for threat in threats:
                try:
                    threat_time = datetime.fromisoformat(threat.get('timestamp', now.isoformat()))
                    if (now - threat_time).total_seconds() <= 86400:  # Last 24 hours
                        hour_key = threat_time.strftime('%H:00')
                        hourly_counts[hour_key] += 1
                except:
                    continue
            
            # Generate 24-hour timeline
            timeline_data = []
            for i in range(24):
                hour_key = f"{i:02d}:00"
                timeline_data.append({
                    'time': hour_key,
                    'count': hourly_counts.get(hour_key, 0)
                })
            
            return jsonify(timeline_data)
        
        @self.app.route('/api/sources-chart')
        def get_sources_chart():
            """Get threat sources distribution"""
            threats = self.dashboard_data['threats']
            source_counts = Counter(t.get('source', 'Unknown') for t in threats)
            
            return jsonify({
                'labels': list(source_counts.keys()),
                'values': list(source_counts.values())
            })
        
        @self.app.route('/api/ioc-network')
        def get_ioc_network():
            """Get IOC correlation network data"""
            return jsonify(self.build_ioc_network())
        
        @self.app.route('/api/threat/<threat_id>')
        def get_threat_details(threat_id):
            """Get detailed information about a specific threat"""
            threat = next((t for t in self.dashboard_data['threats'] 
                          if t.get('hash') == threat_id), None)
            
            if threat:
                # Add correlation data if available
                correlations = self.find_threat_correlations(threat)
                threat['correlations'] = correlations
                return jsonify(threat)
            else:
                return jsonify({'error': 'Threat not found'}), 404
        
        @self.app.route('/api/search')
        def search_threats():
            """Search threats by IOC, keyword, or source"""
            query = request.args.get('q', '').lower()
            if not query:
                return jsonify([])
            
            results = []
            for threat in self.dashboard_data['threats']:
                # Search in title, description, IOCs, tags, source
                searchable_text = ' '.join([
                    threat.get('title', ''),
                    threat.get('description', ''),
                    ' '.join(threat.get('iocs', [])),
                    ' '.join(threat.get('tags', [])),
                    threat.get('source', '')
                ]).lower()
                
                if query in searchable_text:
                    results.append(threat)
            
            return jsonify(results[:50])  # Limit results
        

        
        @self.app.route('/api/top-sources')
        def get_top_sources():
            """Get top threat intelligence sources by volume"""
            source_stats = {}
            
            for threat in self.dashboard_data['threats']:
                source = threat.get('source', 'Unknown')
                if source not in source_stats:
                    source_stats[source] = {
                        'count': 0,
                        'critical': 0,
                        'high': 0,
                        'medium': 0,
                        'low': 0
                    }
                
                source_stats[source]['count'] += 1
                severity = threat.get('severity', 'medium').lower()
                if severity in source_stats[source]:
                    source_stats[source][severity] += 1
            
            # Sort by count and get top 10
            top_sources = sorted(source_stats.items(), key=lambda x: x[1]['count'], reverse=True)[:10]
            
            return jsonify({
                'sources': [{'name': name, **stats} for name, stats in top_sources]
            })
        
        @self.app.route('/api/asn-analysis')
        def get_asn_analysis():
            """Get ASN-based infrastructure analysis"""
            try:
                from feeds.geo_intel import GeoIntelligence
                geo_intel = GeoIntelligence()
                
                clusters = geo_intel.analyze_infrastructure_clusters(self.dashboard_data['threats'])
                
                # Group by ASN for visualization
                asn_data = []
                for cluster in clusters[:15]:  # Top 15
                    if cluster.get('cluster_type') == 'asn':
                        asn_data.append({
                            'asn': cluster['asn'],
                            'name': cluster['asn_name'],
                            'threat_count': len(cluster['threats']),
                            'ioc_count': len(cluster['iocs']),
                            'countries': cluster['countries'],
                            'significance': cluster['significance_score']
                        })
                
                return jsonify({'asn_clusters': asn_data})
            except Exception as e:
                self.logger.error(f"ASN analysis error: {e}")
                return jsonify({'asn_clusters': []})
        
        @self.app.route('/api/ioc-types')
        def get_ioc_types():
            """Get IOC type distribution"""
            ioc_types = {}
            
            for threat in self.dashboard_data['threats']:
                for ioc in threat.get('iocs', []):
                    ioc_type = self.detect_ioc_type(ioc)
                    ioc_types[ioc_type] = ioc_types.get(ioc_type, 0) + 1
            
            return jsonify({
                'types': [{'type': k, 'count': v} for k, v in ioc_types.items()]
            })
        
        @self.app.route('/api/correlation-matrix')
        def get_correlation_matrix():
            """Get threat correlation matrix data"""
            try:
                from analysis.campaign_detector import CampaignDetector
                detector = CampaignDetector()
                
                # Build correlation matrix
                sources = list(set(threat.get('source', 'Unknown') for threat in self.dashboard_data['threats']))[:10]
                categories = list(set(threat.get('category', 'general') for threat in self.dashboard_data['threats']))[:10]
                
                matrix_data = []
                for i, source in enumerate(sources):
                    row = []
                    for j, category in enumerate(categories):
                        # Count threats matching source and category
                        count = len([
                            t for t in self.dashboard_data['threats'] 
                            if t.get('source') == source and t.get('category') == category
                        ])
                        row.append(count)
                    matrix_data.append(row)
                
                return jsonify({
                    'sources': sources,
                    'categories': categories,
                    'matrix': matrix_data
                })
            except Exception as e:
                self.logger.error(f"Correlation matrix error: {e}")
                return jsonify({'sources': [], 'categories': [], 'matrix': []})
        
        @self.app.route('/api/ioc-database')
        def get_ioc_database():
            """Get comprehensive IOC database with search and filtering"""
            search = request.args.get('search', '').lower()
            ioc_type = request.args.get('type', 'all')
            severity = request.args.get('severity', 'all')
            page = int(request.args.get('page', 1))
            per_page = int(request.args.get('per_page', 50))
            
            # Build comprehensive IOC database
            ioc_database = []
            for threat in self.dashboard_data['threats']:
                for ioc in threat.get('iocs', []):
                    # Determine IOC type
                    detected_type = self.detect_ioc_type(ioc)
                    
                    # Apply filters
                    if ioc_type != 'all' and detected_type != ioc_type:
                        continue
                    if severity != 'all' and threat.get('severity', '').lower() != severity.lower():
                        continue
                    if search and search not in ioc.lower():
                        continue
                    
                    ioc_entry = {
                        'ioc': ioc,
                        'type': detected_type,
                        'first_seen': threat.get('timestamp', ''),
                        'threat_title': threat.get('title', ''),
                        'severity': threat.get('severity', ''),
                        'category': threat.get('category', ''),
                        'source': threat.get('source', ''),
                        'threat_id': threat.get('hash', ''),
                        'tags': threat.get('tags', []),
                        'priority_score': threat.get('priority_analysis', {}).get('priority_score', 0)
                    }
                    ioc_database.append(ioc_entry)
            
            # Remove duplicates and sort
            unique_iocs = {}
            for entry in ioc_database:
                ioc = entry['ioc']
                if ioc not in unique_iocs or entry['priority_score'] > unique_iocs[ioc]['priority_score']:
                    unique_iocs[ioc] = entry
            
            sorted_iocs = sorted(unique_iocs.values(), key=lambda x: x['priority_score'], reverse=True)
            
            # Pagination
            start = (page - 1) * per_page
            end = start + per_page
            
            return jsonify({
                'iocs': sorted_iocs[start:end],
                'total': len(sorted_iocs),
                'page': page,
                'per_page': per_page,
                'has_next': end < len(sorted_iocs),
                'types': list(set(entry['type'] for entry in sorted_iocs))
            })
        
        @self.app.route('/api/ioc-details/<ioc>')
        def get_ioc_details(ioc):
            """Get detailed information about specific IOC"""
            related_threats = []
            correlation_graph = {'nodes': [], 'edges': []}
            
            for threat in self.dashboard_data['threats']:
                if ioc in threat.get('iocs', []):
                    related_threats.append({
                        'id': threat.get('hash', ''),
                        'title': threat.get('title', ''),
                        'severity': threat.get('severity', ''),
                        'timestamp': threat.get('timestamp', ''),
                        'source': threat.get('source', ''),
                        'category': threat.get('category', ''),
                        'all_iocs': threat.get('iocs', [])
                    })
            
            # Build correlation graph for this IOC
            if related_threats:
                # Add IOC as central node
                correlation_graph['nodes'].append({
                    'id': ioc,
                    'type': 'ioc',
                    'label': ioc,
                    'size': 20,
                    'color': '#ff6b35'
                })
                
                # Add threat nodes and connections
                for threat in related_threats:
                    threat_id = threat['id']
                    correlation_graph['nodes'].append({
                        'id': threat_id,
                        'type': 'threat',
                        'label': threat['title'][:30],
                        'size': 15,
                        'color': self.get_severity_color(threat['severity'])
                    })
                    
                    # Connect IOC to threat
                    correlation_graph['edges'].append({
                        'source': ioc,
                        'target': threat_id,
                        'weight': 1
                    })
                
                # Add related IOCs
                related_iocs = set()
                for threat in related_threats:
                    for other_ioc in threat['all_iocs']:
                        if other_ioc != ioc:
                            related_iocs.add(other_ioc)
                
                for related_ioc in list(related_iocs)[:10]:  # Limit for visualization
                    correlation_graph['nodes'].append({
                        'id': related_ioc,
                        'type': 'related_ioc',
                        'label': related_ioc,
                        'size': 10,
                        'color': '#888888'
                    })
                    
                    # Find common threats
                    for threat in related_threats:
                        if related_ioc in threat['all_iocs']:
                            correlation_graph['edges'].append({
                                'source': related_ioc,
                                'target': threat['id'],
                                'weight': 0.5
                            })
            
            return jsonify({
                'ioc': ioc,
                'type': self.detect_ioc_type(ioc),
                'related_threats': related_threats,
                'correlation_graph': correlation_graph,
                'threat_count': len(related_threats),
                'first_seen': min([t['timestamp'] for t in related_threats], default=''),
                'last_seen': max([t['timestamp'] for t in related_threats], default='')
            })
        
        @self.app.route('/api/alert-volume')
        def get_alert_volume():
            """Get alert volume statistics over time"""
            timeframe = request.args.get('timeframe', '24h')  # 24h, 7d, 30d
            
            # Calculate time buckets
            now = datetime.utcnow()
            if timeframe == '24h':
                bucket_size = timedelta(hours=1)
                time_range = timedelta(hours=24)
                format_str = '%H:00'
            elif timeframe == '7d':
                bucket_size = timedelta(hours=6)
                time_range = timedelta(days=7)
                format_str = '%m-%d %H:00'
            else:  # 30d
                bucket_size = timedelta(days=1)
                time_range = timedelta(days=30)
                format_str = '%m-%d'
            
            # Initialize buckets
            buckets = []
            current_time = now - time_range
            while current_time <= now:
                buckets.append({
                    'time': current_time.strftime(format_str),
                    'timestamp': current_time.isoformat(),
                    'total': 0,
                    'critical': 0,
                    'high': 0,
                    'medium': 0,
                    'low': 0,
                    'families': {}
                })
                current_time += bucket_size
            
            # Fill buckets with threat data
            for threat in self.dashboard_data['threats']:
                try:
                    threat_time = datetime.fromisoformat(threat.get('timestamp', ''))
                    if (now - threat_time) <= time_range:
                        # Find appropriate bucket
                        bucket_index = int((threat_time - (now - time_range)).total_seconds() / bucket_size.total_seconds())
                        if 0 <= bucket_index < len(buckets):
                            bucket = buckets[bucket_index]
                            bucket['total'] += 1
                            
                            severity = threat.get('severity', 'medium').lower()
                            if severity in bucket:
                                bucket[severity] += 1
                            
                            # Track threat families/categories
                            category = threat.get('category', 'general')
                            bucket['families'][category] = bucket['families'].get(category, 0) + 1
                except:
                    continue
            
            return jsonify({
                'timeframe': timeframe,
                'buckets': buckets,
                'summary': {
                    'total_alerts': sum(b['total'] for b in buckets),
                    'avg_per_bucket': sum(b['total'] for b in buckets) / len(buckets) if buckets else 0,
                    'peak_bucket': max(buckets, key=lambda x: x['total']) if buckets else None
                }
            })
        
        @self.app.route('/api/geo-heatmap')
        def get_geo_heatmap():
            """Get geographic heatmap data"""
            try:
                from feeds.geo_intel import GeoIntelligence
                geo_intel = GeoIntelligence()
                
                heatmap_data = geo_intel.build_threat_heatmap_data(self.dashboard_data['threats'])
                return jsonify(heatmap_data)
            except Exception as e:
                self.logger.error(f"Error building geo heatmap: {e}")
                return jsonify({'countries': {}, 'locations': []})
        
        @self.app.route('/api/campaigns')
        def get_campaigns():
            """Get detected threat campaigns"""
            try:
                from analysis.campaign_detector import CampaignDetector
                detector = CampaignDetector()
                
                campaigns = detector.detect_campaigns(self.dashboard_data['threats'])
                return jsonify({
                    'campaigns': campaigns,
                    'total_campaigns': len(campaigns)
                })
            except Exception as e:
                self.logger.error(f"Error detecting campaigns: {e}")
                return jsonify({'campaigns': [], 'total_campaigns': 0})
        
        @self.app.route('/api/campaign-timeline/<campaign_id>')
        def get_campaign_timeline(campaign_id):
            """Get timeline for specific campaign"""
            try:
                from analysis.campaign_detector import CampaignDetector
                detector = CampaignDetector()
                
                campaigns = detector.detect_campaigns(self.dashboard_data['threats'])
                campaign = next((c for c in campaigns if c['id'] == campaign_id), None)
                
                if campaign:
                    timeline = detector.get_campaign_timeline(campaign, self.dashboard_data['threats'])
                    return jsonify({'timeline': timeline})
                else:
                    return jsonify({'error': 'Campaign not found'}), 404
                    
            except Exception as e:
                self.logger.error(f"Error getting campaign timeline: {e}")
                return jsonify({'timeline': []})
        
        @self.app.route('/api/threat-trends')
        def get_threat_trends():
            """Get threat trends and anomaly detection"""
            timeframe = request.args.get('timeframe', '7d')
            
            try:
                trends_data = self.analyze_threat_trends(timeframe)
                return jsonify(trends_data)
            except Exception as e:
                self.logger.error(f"Error analyzing threat trends: {e}")
                return jsonify({'trends': [], 'anomalies': []})
        
        @self.app.route('/api/export')
        def export_threats():
            """Export threats data in multiple formats including PDF, STIX, TAXII"""
            export_format = request.args.get('format', 'json')
            export_type = request.args.get('type', 'threats')  # threats, iocs, summary
            threats = self.dashboard_data['threats']
            
            if export_format == 'json':
                if export_type == 'iocs':
                    # Export IOC database
                    ioc_data = self.build_ioc_export()
                    response_data = ioc_data
                    filename = 'ghostsec_iocs.json'
                else:
                    response_data = threats
                    filename = 'ghostsec_threats.json'
                
                response = flask.Response(
                    json.dumps(response_data, indent=2, default=str),
                    mimetype='application/json'
                )
                response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                return response
                
            elif export_format == 'csv':
                import csv
                import io
                
                output = io.StringIO()
                writer = csv.writer(output)
                
                if export_type == 'iocs':
                    # IOC CSV export
                    writer.writerow(['IOC', 'Type', 'Severity', 'Category', 'Source', 'First_Seen', 'Threat_Title'])
                    for threat in threats:
                        for ioc in threat.get('iocs', []):
                            writer.writerow([
                                ioc,
                                self.detect_ioc_type(ioc),
                                threat.get('severity', ''),
                                threat.get('category', ''),
                                threat.get('source', ''),
                                threat.get('timestamp', ''),
                                threat.get('title', '')
                            ])
                    filename = 'ghostsec_iocs.csv'
                else:
                    # Threat CSV export
                    writer.writerow(['Timestamp', 'Title', 'Severity', 'Category', 'Source', 'IOC_Count', 'Priority_Score', 'URL'])
                    for threat in threats:
                        writer.writerow([
                            threat.get('timestamp', ''),
                            threat.get('title', ''),
                            threat.get('severity', ''),
                            threat.get('category', ''),
                            threat.get('source', ''),
                            len(threat.get('iocs', [])),
                            threat.get('priority_analysis', {}).get('priority_score', ''),
                            threat.get('url', '')
                        ])
                    filename = 'ghostsec_threats.csv'
                
                response = flask.Response(
                    output.getvalue(),
                    mimetype='text/csv'
                )
                response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                return response
            
            elif export_format == 'pdf':
                # Generate PDF report
                pdf_content = self.generate_pdf_report(threats, export_type)
                filename = f'ghostsec_{export_type}_report.pdf'
                
                response = flask.Response(
                    pdf_content,
                    mimetype='application/pdf'
                )
                response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                return response
            
            elif export_format == 'stix':
                # Generate STIX 2.1 bundle
                try:
                    from integrations.stix_taxii import STIXExporter
                    exporter = STIXExporter()
                    
                    stix_bundle = exporter.export_threats_to_stix(threats)
                    filename = f'ghostsec_stix_{export_type}.json'
                    
                    response = flask.Response(
                        json.dumps(stix_bundle, indent=2),
                        mimetype='application/json'
                    )
                    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                    return response
                except Exception as e:
                    self.logger.error(f"STIX export error: {e}")
                    return jsonify({'error': 'STIX export failed'}), 500
            
            elif export_format == 'taxii':
                # Generate TAXII collection
                try:
                    from integrations.stix_taxii import TAXIIExporter
                    exporter = TAXIIExporter()
                    
                    taxii_collection = exporter.format_for_taxii_server(threats)
                    filename = f'ghostsec_taxii_{export_type}.json'
                    
                    response = flask.Response(
                        json.dumps(taxii_collection, indent=2),
                        mimetype='application/json'
                    )
                    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                    return response
                except Exception as e:
                    self.logger.error(f"TAXII export error: {e}")
                    return jsonify({'error': 'TAXII export failed'}), 500
            
            elif export_format == 'yara':
                # Generate YARA rules from IOCs
                try:
                    yara_rules = self.generate_yara_rules(threats)
                    filename = f'ghostsec_rules.yar'
                    
                    response = flask.Response(
                        yara_rules,
                        mimetype='text/plain'
                    )
                    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                    return response
                except Exception as e:
                    self.logger.error(f"YARA export error: {e}")
                    return jsonify({'error': 'YARA export failed'}), 500
            
            elif export_format == 'misp':
                # Generate MISP event format
                try:
                    misp_events = self.generate_misp_events(threats)
                    filename = f'ghostsec_misp_{export_type}.json'
                    
                    response = flask.Response(
                        json.dumps(misp_events, indent=2),
                        mimetype='application/json'
                    )
                    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                    return response
                except Exception as e:
                    self.logger.error(f"MISP export error: {e}")
                    return jsonify({'error': 'MISP export failed'}), 500
            
            return jsonify({'error': 'Unsupported format'}), 400
        
        @self.app.route('/api/realtime-feed')
        def get_realtime_feed():
            """Get real-time threat feed for live updates"""
            since = request.args.get('since', '')
            feed_items = []
            
            try:
                since_time = datetime.fromisoformat(since) if since else datetime.utcnow() - timedelta(minutes=5)
            except:
                since_time = datetime.utcnow() - timedelta(minutes=5)
            
            for threat in self.dashboard_data['threats']:
                try:
                    threat_time = datetime.fromisoformat(threat.get('timestamp', ''))
                    if threat_time > since_time:
                        feed_items.append({
                            'id': threat.get('hash'),
                            'title': threat.get('title'),
                            'severity': threat.get('severity'),
                            'timestamp': threat.get('timestamp'),
                            'source': threat.get('source')
                        })
                except:
                    continue
            
            return jsonify(feed_items)
    
    def add_threat(self, threat_data):
        """Add new threat to dashboard data"""
        try:
            # Add timestamp if not present
            if 'timestamp' not in threat_data:
                threat_data['timestamp'] = datetime.utcnow().isoformat()
            
            # Add to threats list (keep last 1000)
            self.dashboard_data['threats'].insert(0, threat_data)
            if len(self.dashboard_data['threats']) > 1000:
                self.dashboard_data['threats'] = self.dashboard_data['threats'][:1000]
            
            # Update real-time feed
            feed_item = {
                'id': threat_data.get('hash'),
                'title': threat_data.get('title'),
                'severity': threat_data.get('severity'),
                'timestamp': threat_data.get('timestamp'),
                'source': threat_data.get('source'),
                'type': 'new_threat'
            }
            
            self.dashboard_data['real_time_feed'].insert(0, feed_item)
            if len(self.dashboard_data['real_time_feed']) > 100:
                self.dashboard_data['real_time_feed'] = self.dashboard_data['real_time_feed'][:100]
            
            self.logger.debug(f"Added threat to dashboard: {threat_data.get('title', 'Unknown')}")
            
        except Exception as e:
            self.logger.error(f"Error adding threat to dashboard: {e}")
    
    def get_statistics(self):
        """Calculate dashboard statistics"""
        threats = self.dashboard_data['threats']
        now = datetime.utcnow()
        
        # Time-based counts
        last_24h = sum(1 for t in threats 
                      if self.is_within_timeframe(t.get('timestamp'), hours=24))
        last_7d = sum(1 for t in threats 
                     if self.is_within_timeframe(t.get('timestamp'), days=7))
        
        # Severity distribution
        severity_counts = Counter(t.get('severity', 'unknown').lower() for t in threats)
        
        # Source activity
        source_counts = Counter(t.get('source', 'Unknown') for t in threats)
        top_sources = dict(source_counts.most_common(5))
        
        # Category distribution
        category_counts = Counter(t.get('category', 'general') for t in threats)
        
        # IOC statistics
        total_iocs = sum(len(t.get('iocs', [])) for t in threats)
        unique_iocs = len(set(ioc for t in threats for ioc in t.get('iocs', [])))
        
        return {
            'total_threats': len(threats),
            'threats_24h': last_24h,
            'threats_7d': last_7d,
            'severity_distribution': dict(severity_counts),
            'source_activity': top_sources,
            'category_distribution': dict(category_counts),
            'total_iocs': total_iocs,
            'unique_iocs': unique_iocs,
            'last_updated': now.isoformat()
        }
    
    def is_within_timeframe(self, timestamp_str, hours=0, days=0):
        """Check if timestamp is within specified timeframe"""
        try:
            timestamp = datetime.fromisoformat(timestamp_str)
            now = datetime.utcnow()
            delta = timedelta(hours=hours, days=days)
            return (now - timestamp) <= delta
        except:
            return False
    
    def build_ioc_network(self):
        """Build network graph of IOC correlations"""
        threats = self.dashboard_data['threats']
        
        # Create network graph
        G = nx.Graph()
        
        # Add nodes and edges based on shared IOCs
        for i, threat1 in enumerate(threats[:100]):  # Limit for performance
            threat1_iocs = set(threat1.get('iocs', []))
            
            for j, threat2 in enumerate(threats[i+1:101], i+1):
                threat2_iocs = set(threat2.get('iocs', []))
                shared_iocs = threat1_iocs & threat2_iocs
                
                if shared_iocs:
                    # Add nodes
                    node1_id = threat1.get('hash', f"threat_{i}")
                    node2_id = threat2.get('hash', f"threat_{j}")
                    
                    G.add_node(node1_id, 
                              title=threat1.get('title', '')[:30],
                              severity=threat1.get('severity', 'medium'))
                    G.add_node(node2_id,
                              title=threat2.get('title', '')[:30], 
                              severity=threat2.get('severity', 'medium'))
                    
                    # Add edge with weight based on shared IOCs
                    G.add_edge(node1_id, node2_id, weight=len(shared_iocs))
        
        # Convert to format suitable for visualization
        if G.number_of_nodes() > 0:
            pos = nx.spring_layout(G, k=1, iterations=50)
            
            nodes = []
            edges = []
            
            for node_id, data in G.nodes(data=True):
                x, y = pos[node_id]
                nodes.append({
                    'id': node_id,
                    'title': data.get('title', ''),
                    'severity': data.get('severity', 'medium'),
                    'x': float(x),
                    'y': float(y)
                })
            
            for edge in G.edges(data=True):
                edges.append({
                    'source': edge[0],
                    'target': edge[1],
                    'weight': edge[2].get('weight', 1)
                })
            
            return {'nodes': nodes, 'edges': edges}
        else:
            return {'nodes': [], 'edges': []}
    
    def detect_ioc_type(self, ioc):
        """Detect the type of IOC"""
        import re
        
        # IP address
        if re.match(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ioc):
            return 'ip'
        
        # Domain
        if re.match(r'^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$', ioc):
            return 'domain'
        
        # Hash (MD5, SHA1, SHA256)
        if re.match(r'^[a-fA-F0-9]{32}$', ioc):
            return 'md5'
        elif re.match(r'^[a-fA-F0-9]{40}$', ioc):
            return 'sha1'
        elif re.match(r'^[a-fA-F0-9]{64}$', ioc):
            return 'sha256'
        
        # URL
        if ioc.startswith(('http://', 'https://')):
            return 'url'
        
        # Email
        if '@' in ioc and '.' in ioc.split('@')[1]:
            return 'email'
        
        # File path
        if '\\' in ioc or '/' in ioc:
            return 'filepath'
        
        return 'other'
    
    def get_severity_color(self, severity):
        """Get color for severity level"""
        colors = {
            'critical': '#ff0000',
            'high': '#ff8000',
            'medium': '#ffff00',
            'low': '#00ff00'
        }
        return colors.get(severity.lower(), '#888888')
    
    def build_ioc_export(self):
        """Build comprehensive IOC export data"""
        ioc_data = {}
        
        for threat in self.dashboard_data['threats']:
            for ioc in threat.get('iocs', []):
                if ioc not in ioc_data:
                    ioc_data[ioc] = {
                        'ioc': ioc,
                        'type': self.detect_ioc_type(ioc),
                        'first_seen': threat.get('timestamp', ''),
                        'last_seen': threat.get('timestamp', ''),
                        'threat_count': 0,
                        'max_severity': 'low',
                        'sources': set(),
                        'categories': set(),
                        'associated_threats': []
                    }
                
                entry = ioc_data[ioc]
                entry['threat_count'] += 1
                entry['sources'].add(threat.get('source', ''))
                entry['categories'].add(threat.get('category', ''))
                entry['associated_threats'].append(threat.get('title', ''))
                
                # Update severity
                severity_levels = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}
                current_level = severity_levels.get(entry['max_severity'], 1)
                threat_level = severity_levels.get(threat.get('severity', 'low'), 1)
                if threat_level > current_level:
                    entry['max_severity'] = threat.get('severity', 'low')
                
                # Update timestamps
                threat_time = threat.get('timestamp', '')
                if threat_time < entry['first_seen']:
                    entry['first_seen'] = threat_time
                if threat_time > entry['last_seen']:
                    entry['last_seen'] = threat_time
        
        # Convert sets to lists for JSON serialization
        for ioc, data in ioc_data.items():
            data['sources'] = list(data['sources'])
            data['categories'] = list(data['categories'])
        
        return list(ioc_data.values())
    
    def generate_pdf_report(self, threats, report_type):
        """Generate PDF report using HTML to PDF conversion"""
        try:
            # Simple HTML-based PDF generation
            html_content = self.create_report_html(threats, report_type)
            
            # For now, return HTML content as bytes
            # In production, you'd use a library like weasyprint or reportlab
            return html_content.encode('utf-8')
            
        except Exception as e:
            self.logger.error(f"PDF generation error: {e}")
            return b"PDF generation failed"
    
    def create_report_html(self, threats, report_type):
        """Create HTML report content"""
        if report_type == 'iocs':
            return self.create_ioc_report_html(threats)
        else:
            return self.create_threat_report_html(threats)
    
    def create_ioc_report_html(self, threats):
        """Create IOC-focused HTML report"""
        ioc_data = self.build_ioc_export()
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>GhostSEC IOC Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; color: #ff6b35; margin-bottom: 30px; }}
                .summary {{ background: #f5f5f5; padding: 15px; margin-bottom: 20px; }}
                .ioc-table {{ width: 100%; border-collapse: collapse; }}
                .ioc-table th, .ioc-table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                .ioc-table th {{ background-color: #ff6b35; color: white; }}
                .critical {{ background-color: #ffebee; }}
                .high {{ background-color: #fff3e0; }}
                .medium {{ background-color: #f3e5f5; }}
                .low {{ background-color: #e8f5e8; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🔍 GhostSEC IOC Intelligence Report</h1>
                <p>Generated on {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC</p>
            </div>
            
            <div class="summary">
                <h2>Summary</h2>
                <p><strong>Total IOCs:</strong> {len(ioc_data)}</p>
                <p><strong>Unique Sources:</strong> {len(set(ioc['sources'][0] if ioc['sources'] else 'Unknown' for ioc in ioc_data))}</p>
                <p><strong>Critical IOCs:</strong> {len([ioc for ioc in ioc_data if ioc['max_severity'] == 'critical'])}</p>
                <p><strong>High Priority IOCs:</strong> {len([ioc for ioc in ioc_data if ioc['max_severity'] == 'high'])}</p>
            </div>
            
            <table class="ioc-table">
                <tr>
                    <th>IOC</th>
                    <th>Type</th>
                    <th>Max Severity</th>
                    <th>Threat Count</th>
                    <th>First Seen</th>
                    <th>Categories</th>
                </tr>
        """
        
        for ioc in sorted(ioc_data, key=lambda x: x['threat_count'], reverse=True)[:100]:
            severity_class = ioc['max_severity']
            html += f"""
                <tr class="{severity_class}">
                    <td>{ioc['ioc']}</td>
                    <td>{ioc['type'].upper()}</td>
                    <td>{ioc['max_severity'].upper()}</td>
                    <td>{ioc['threat_count']}</td>
                    <td>{ioc['first_seen'][:10]}</td>
                    <td>{', '.join(ioc['categories'][:3])}</td>
                </tr>
            """
        
        html += """
            </table>
        </body>
        </html>
        """
        
        return html
    
    def create_threat_report_html(self, threats):
        """Create threat-focused HTML report"""
        stats = self.get_statistics()
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>GhostSEC Threat Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ text-align: center; color: #ff6b35; margin-bottom: 30px; }}
                .summary {{ background: #f5f5f5; padding: 15px; margin-bottom: 20px; }}
                .threat {{ border-left: 4px solid #ff6b35; padding: 15px; margin: 10px 0; background: #fafafa; }}
                .critical {{ border-left-color: #ff0000; }}
                .high {{ border-left-color: #ff8000; }}
                .medium {{ border-left-color: #ffff00; }}
                .low {{ border-left-color: #00ff00; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🚨 GhostSEC Threat Intelligence Report</h1>
                <p>Generated on {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC</p>
            </div>
            
            <div class="summary">
                <h2>Executive Summary</h2>
                <p><strong>Total Threats:</strong> {stats['total_threats']}</p>
                <p><strong>Critical Threats:</strong> {stats['severity_distribution'].get('critical', 0)}</p>
                <p><strong>High Priority Threats:</strong> {stats['severity_distribution'].get('high', 0)}</p>
                <p><strong>Active Sources:</strong> {len(stats['source_activity'])}</p>
                <p><strong>Total IOCs:</strong> {stats['total_iocs']}</p>
            </div>
            
            <h2>Recent Critical and High Priority Threats</h2>
        """
        
        # Add top threats
        high_priority_threats = [t for t in threats if t.get('severity', '').lower() in ['critical', 'high']]
        for threat in high_priority_threats[:20]:
            severity = threat.get('severity', 'medium').lower()
            html += f"""
            <div class="threat {severity}">
                <h3>{threat.get('title', 'Unknown Threat')}</h3>
                <p><strong>Severity:</strong> {threat.get('severity', 'Unknown').upper()}</p>
                <p><strong>Source:</strong> {threat.get('source', 'Unknown')}</p>
                <p><strong>Category:</strong> {threat.get('category', 'General')}</p>
                <p><strong>IOCs:</strong> {len(threat.get('iocs', []))}</p>
                <p><strong>Description:</strong> {threat.get('description', 'No description')[:200]}...</p>
            </div>
            """
        
        html += """
        </body>
        </html>
        """
        
        return html
    
    def analyze_threat_trends(self, timeframe: str) -> Dict:
        """Analyze threat trends and detect anomalies"""
        from datetime import datetime, timedelta
        
        now = datetime.utcnow()
        if timeframe == '24h':
            time_range = timedelta(hours=24)
            bucket_size = timedelta(hours=2)
        elif timeframe == '7d':
            time_range = timedelta(days=7)
            bucket_size = timedelta(hours=12)
        else:  # 30d
            time_range = timedelta(days=30)
            bucket_size = timedelta(days=1)
        
        # Analyze trends by family and severity
        family_trends = {}
        severity_trends = {}
        anomalies = []
        
        for threat in self.dashboard_data['threats']:
            try:
                threat_time = datetime.fromisoformat(threat.get('timestamp', ''))
                if (now - threat_time) <= time_range:
                    category = threat.get('category', 'general')
                    severity = threat.get('severity', 'medium')
                    
                    # Track family trends
                    time_bucket = int((threat_time - (now - time_range)).total_seconds() / bucket_size.total_seconds())
                    
                    if category not in family_trends:
                        family_trends[category] = {}
                    family_trends[category][time_bucket] = family_trends[category].get(time_bucket, 0) + 1
                    
                    # Track severity trends
                    if severity not in severity_trends:
                        severity_trends[severity] = {}
                    severity_trends[severity][time_bucket] = severity_trends[severity].get(time_bucket, 0) + 1
            except:
                continue
        
        # Detect anomalies (simple threshold-based)
        for family, buckets in family_trends.items():
            if len(buckets) >= 3:
                values = list(buckets.values())
                avg = sum(values) / len(values)
                
                for bucket, count in buckets.items():
                    if count > avg * 2:  # Spike detection
                        anomalies.append({
                            'type': 'spike',
                            'family': family,
                            'bucket': bucket,
                            'count': count,
                            'average': avg,
                            'severity': 'high'
                        })
        
        return {
            'family_trends': family_trends,
            'severity_trends': severity_trends,
            'anomalies': anomalies,
            'timeframe': timeframe
        }
    
    def generate_yara_rules(self, threats: List[Dict]) -> str:
        """Generate YARA rules from threat IOCs"""
        rules = []
        rule_counter = 1
        
        for threat in threats:
            hashes = []
            domains = []
            ips = []
            
            for ioc in threat.get('iocs', []):
                ioc_type = self.detect_ioc_type(ioc)
                if ioc_type in ['md5', 'sha1', 'sha256']:
                    hashes.append((ioc_type, ioc))
                elif ioc_type == 'domain':
                    domains.append(ioc)
                elif ioc_type == 'ip':
                    ips.append(ioc)
            
            if hashes or domains or ips:
                rule_name = f"GhostSEC_Rule_{rule_counter:03d}"
                rule_desc = threat.get('title', 'Unknown threat')[:50]
                
                rule = f"""
rule {rule_name} {{
    meta:
        description = "{rule_desc}"
        author = "GhostSEC"
        date = "{datetime.utcnow().strftime('%Y-%m-%d')}"
        source = "{threat.get('source', 'Unknown')}"
        severity = "{threat.get('severity', 'medium')}"
        
    condition:"""
                
                conditions = []
                
                # Add hash conditions
                if hashes:
                    hash_conditions = []
                    for hash_type, hash_value in hashes:
                        hash_conditions.append(f"hash.{hash_type}(0, filesize) == \"{hash_value}\"")
                    conditions.append("(" + " or ".join(hash_conditions) + ")")
                
                # Add network conditions (simplified)
                if domains or ips:
                    network_conditions = []
                    for domain in domains:
                        network_conditions.append(f"\"{domain}\"")
                    for ip in ips:
                        network_conditions.append(f"\"{ip}\"")
                    
                    if network_conditions:
                        conditions.append("any of (" + ", ".join(network_conditions) + ")")
                
                rule += "\n        " + " or ".join(conditions)
                rule += "\n}\n"
                
                rules.append(rule)
                rule_counter += 1
        
        header = f"""/*
    GhostSEC YARA Rules
    Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
    Total Rules: {len(rules)}
    
    Description: Automated YARA rules generated from GhostSEC threat intelligence
*/

"""
        
        return header + "\n".join(rules)
    
    def generate_misp_events(self, threats: List[Dict]) -> Dict:
        """Generate MISP event format"""
        events = []
        
        for threat in threats:
            event = {
                "Event": {
                    "id": str(len(events) + 1),
                    "orgc_id": "1",
                    "org_id": "1",
                    "date": threat.get('timestamp', datetime.utcnow().isoformat())[:10],
                    "threat_level_id": self.severity_to_misp_threat_level(threat.get('severity', 'medium')),
                    "info": threat.get('title', 'Unknown threat'),
                    "published": True,
                    "uuid": str(uuid.uuid4()),
                    "attribute_count": str(len(threat.get('iocs', []))),
                    "analysis": "2",  # Completed
                    "timestamp": str(int(datetime.utcnow().timestamp())),
                    "distribution": "1",  # This community only
                    "proposal_email_lock": False,
                    "locked": False,
                    "publish_timestamp": str(int(datetime.utcnow().timestamp())),
                    "sharing_group_id": "0",
                    "disable_correlation": False,
                    "extends_uuid": "",
                    "Attribute": []
                }
            }
            
            # Add IOC attributes
            for i, ioc in enumerate(threat.get('iocs', [])):
                ioc_type = self.detect_ioc_type(ioc)
                
                # Map IOC types to MISP categories
                misp_type_mapping = {
                    'ip': 'ip-dst',
                    'domain': 'domain',
                    'url': 'url',
                    'md5': 'md5',
                    'sha1': 'sha1',
                    'sha256': 'sha256',
                    'email': 'email-dst'
                }
                
                misp_type = misp_type_mapping.get(ioc_type, 'other')
                
                attribute = {
                    "id": str(i + 1),
                    "type": misp_type,
                    "category": "Network activity" if ioc_type in ['ip', 'domain', 'url'] else "Payload delivery",
                    "to_ids": True,
                    "uuid": str(uuid.uuid4()),
                    "event_id": event["Event"]["id"],
                    "distribution": "5",
                    "timestamp": str(int(datetime.utcnow().timestamp())),
                    "comment": f"IOC from {threat.get('source', 'GhostSEC')}",
                    "sharing_group_id": "0",
                    "deleted": False,
                    "disable_correlation": False,
                    "object_id": "0",
                    "object_relation": None,
                    "value": ioc
                }
                
                event["Event"]["Attribute"].append(attribute)
            
            events.append(event)
        
        return {"response": events}
    
    def severity_to_misp_threat_level(self, severity: str) -> str:
        """Convert severity to MISP threat level"""
        mapping = {
            'critical': '1',  # High
            'high': '2',     # Medium
            'medium': '3',   # Low
            'low': '4'       # Undefined
        }
        return mapping.get(severity.lower(), '3')
    
    def find_threat_correlations(self, threat):
        """Find correlations for a specific threat"""
        threat_iocs = set(threat.get('iocs', []))
        threat_tags = set(threat.get('tags', []))
        correlations = []
        
        for other_threat in self.dashboard_data['threats']:
            if other_threat.get('hash') == threat.get('hash'):
                continue
            
            other_iocs = set(other_threat.get('iocs', []))
            other_tags = set(other_threat.get('tags', []))
            
            shared_iocs = threat_iocs & other_iocs
            shared_tags = threat_tags & other_tags
            
            if shared_iocs or len(shared_tags) >= 2:
                correlation_score = len(shared_iocs) * 0.7 + len(shared_tags) * 0.3
                
                correlations.append({
                    'threat_id': other_threat.get('hash'),
                    'title': other_threat.get('title'),
                    'score': correlation_score,
                    'shared_iocs': list(shared_iocs),
                    'shared_tags': list(shared_tags),
                    'timestamp': other_threat.get('timestamp')
                })
        
        # Sort by correlation score
        correlations.sort(key=lambda x: x['score'], reverse=True)
        return correlations[:10]  # Top 10 correlations
    
    def start_dashboard(self):
        """Start the web dashboard"""
        self.running = True
        
        # Start data collector in background
        self.data_collector_thread = threading.Thread(target=self.data_collector)
        self.data_collector_thread.daemon = True
        self.data_collector_thread.start()
        
        self.logger.info(f"Starting threat dashboard on port {self.port}")
        
        # Run Flask app
        self.app.run(
            host='0.0.0.0',
            port=self.port,
            debug=False,
            threaded=True
        )
    
    def data_collector(self):
        """Background data collection and processing"""
        while self.running:
            try:
                # Update statistics periodically
                self.dashboard_data['statistics'] = self.get_statistics()
                
                # Clean old data
                cutoff_time = datetime.utcnow() - timedelta(days=30)
                self.dashboard_data['threats'] = [
                    t for t in self.dashboard_data['threats']
                    if self.is_within_timeframe(t.get('timestamp'), days=30)
                ]
                
                time.sleep(60)  # Update every minute
                
            except Exception as e:
                self.logger.error(f"Error in dashboard data collector: {e}")
                time.sleep(60)
    
    def stop_dashboard(self):
        """Stop the dashboard"""
        self.running = False
        if self.data_collector_thread:
            self.data_collector_thread.join(timeout=5)


# Create HTML template
def create_dashboard_template():
    """Create the dashboard HTML template"""
    template_dir = Path("dashboard/templates")
    template_dir.mkdir(parents=True, exist_ok=True)
    
    html_content = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GhostSEC Threat Intelligence Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0a0a0a; color: #fff; }
        .header { background: linear-gradient(135deg, #1a1a1a, #2a2a2a); padding: 20px; text-align: center; border-bottom: 2px solid #ff6b35; }
        .header h1 { color: #ff6b35; font-size: 2.5em; margin-bottom: 10px; }
        .header p { color: #ccc; font-size: 1.1em; }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(135deg, #1e1e1e, #2e2e2e); padding: 20px; border-radius: 10px; border: 1px solid #444; text-align: center; }
        .stat-number { font-size: 2.5em; font-weight: bold; color: #ff6b35; margin-bottom: 10px; }
        .stat-label { color: #ccc; font-size: 1.1em; }
        .charts-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .chart-container { background: #1e1e1e; padding: 20px; border-radius: 10px; border: 1px solid #444; }
        .chart-title { color: #ff6b35; font-size: 1.3em; margin-bottom: 15px; text-align: center; }
        .threats-section { background: #1e1e1e; padding: 20px; border-radius: 10px; border: 1px solid #444; }
        .threat-item { background: #2a2a2a; margin: 10px 0; padding: 15px; border-radius: 8px; border-left: 4px solid #ff6b35; }
        .threat-title { color: #fff; font-weight: bold; margin-bottom: 5px; }
        .threat-meta { color: #ccc; font-size: 0.9em; }
        .severity-critical { border-left-color: #ff0000 !important; }
        .severity-high { border-left-color: #ff8000 !important; }
        .severity-medium { border-left-color: #ffff00 !important; }
        .severity-low { border-left-color: #00ff00 !important; }
        .nav-tabs { display: flex; margin-bottom: 20px; border-bottom: 2px solid #444; }
        .tab-btn { background: none; border: none; color: #ccc; padding: 15px 25px; cursor: pointer; border-bottom: 3px solid transparent; }
        .tab-btn.active { color: #ff6b35; border-bottom-color: #ff6b35; }
        .tab-btn:hover { color: #fff; }
        .view-container { display: none; }
        .view-container.active { display: block; }
        .refresh-btn { background: #ff6b35; color: #fff; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; margin-bottom: 20px; }
        .refresh-btn:hover { background: #e55a2b; }
        .search-box { width: 100%; padding: 10px; margin-bottom: 20px; background: #2a2a2a; border: 1px solid #444; color: #fff; border-radius: 5px; }
        .loading { text-align: center; color: #ccc; padding: 40px; }
        .ioc-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .ioc-table th, .ioc-table td { border: 1px solid #444; padding: 12px; text-align: left; }
        .ioc-table th { background: #ff6b35; color: white; }
        .ioc-table tr:nth-child(even) { background: #2a2a2a; }
        .ioc-table tr:hover { background: #3a3a3a; cursor: pointer; }
        .ioc-type { padding: 4px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }
        .type-ip { background: #2196F3; color: white; }
        .type-domain { background: #4CAF50; color: white; }
        .type-hash { background: #FF9800; color: white; }
        .type-url { background: #9C27B0; color: white; }
        .export-section { background: #1e1e1e; padding: 20px; border-radius: 10px; margin-top: 20px; }
        .export-btn { background: #28a745; color: white; border: none; padding: 10px 20px; margin: 5px; border-radius: 5px; cursor: pointer; }
        .export-btn:hover { background: #218838; }
        .filter-controls { display: flex; gap: 15px; margin-bottom: 20px; align-items: center; }
        .filter-select { background: #2a2a2a; color: #fff; border: 1px solid #444; padding: 8px; border-radius: 4px; }
        .pagination { display: flex; justify-content: center; margin-top: 20px; gap: 10px; }
        .page-btn { background: #444; color: #fff; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; }
        .page-btn.active { background: #ff6b35; }
        .page-btn:hover { background: #555; }
        .ioc-details-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: none; z-index: 1000; }
        .modal-content { background: #1e1e1e; margin: 50px auto; padding: 20px; width: 80%; max-width: 800px; border-radius: 10px; color: #fff; }
        .close { color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer; }
        .close:hover { color: #fff; }
        .correlation-graph { height: 400px; border: 1px solid #444; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>👻 GhostSEC</h1>
        <p>Threat Intelligence Dashboard</p>
    </div>
    
    <div class="container">
        <div class="nav-tabs">
            <button class="tab-btn active" onclick="switchView('overview')">Overview</button>
            <button class="tab-btn" onclick="switchView('iocs')">IOC Database</button>
            <button class="tab-btn" onclick="switchView('analytics')">Analytics</button>
            <button class="tab-btn" onclick="switchView('export')">Export</button>
        </div>
        
        <div class="view-container" id="overviewView">
            <button class="refresh-btn" onclick="refreshDashboard()">🔄 Refresh Data</button>
            
            <div class="stats-grid" id="statsGrid">
                <div class="loading">Loading statistics...</div>
            </div>
        
        <div class="charts-grid">
            <div class="chart-container">
                <div class="chart-title">Severity Distribution</div>
                <div id="severityChart"></div>
            </div>
            
            <div class="chart-container">
                <div class="chart-title">24-Hour Timeline</div>
                <div id="timelineChart"></div>
            </div>
            
            <div class="chart-container">
                <div class="chart-title">Top Sources</div>
                <div id="sourcesChart"></div>
            </div>
            
            <div class="chart-container">
                <div class="chart-title">IOC Network</div>
                <div id="networkChart"></div>
            </div>
        </div>
        
        <div class="threats-section">
            <h2 style="color: #ff6b35; margin-bottom: 20px;">Recent Threats</h2>
            <input type="text" class="search-box" placeholder="Search threats, IOCs, sources..." onkeyup="searchThreats(this.value)">
            <div id="threatsContainer">
                <div class="loading">Loading threats...</div>
            </div>
        </div>
        </div>
        
        <div class="view-container" id="iocsView">
            <h2 style="color: #ff6b35; margin-bottom: 20px;">🔍 IOC Database</h2>
            
            <div class="filter-controls">
                <input type="text" id="iocSearch" class="search-box" placeholder="Search IOCs..." onkeyup="searchIOCs()">
                <select id="iocTypeFilter" class="filter-select" onchange="filterIOCs()">
                    <option value="all">All Types</option>
                    <option value="ip">IP Addresses</option>
                    <option value="domain">Domains</option>
                    <option value="md5">MD5 Hashes</option>
                    <option value="sha1">SHA1 Hashes</option>
                    <option value="sha256">SHA256 Hashes</option>
                    <option value="url">URLs</option>
                    <option value="email">Email Addresses</option>
                </select>
                <select id="severityFilter" class="filter-select" onchange="filterIOCs()">
                    <option value="all">All Severities</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                </select>
            </div>
            
            <div id="iocTableContainer">
                <div class="loading">Loading IOC database...</div>
            </div>
            
            <div class="pagination" id="iocPagination"></div>
        </div>
        
        <div class="view-container" id="analyticsView">
            <h2 style="color: #ff6b35; margin-bottom: 20px;">📈 Advanced Analytics</h2>
            
            <div class="filter-controls">
                <label style="color: #ccc;">Time Range:</label>
                <select id="timeframeSelect" class="filter-select" onchange="updateAnalytics()">
                    <option value="24h">Last 24 Hours</option>
                    <option value="7d">Last 7 Days</option>
                    <option value="30d">Last 30 Days</option>
                </select>
                <button class="refresh-btn" onclick="loadCampaigns()">🔍 Detect Campaigns</button>
            </div>
            
            <div class="charts-grid">
                <div class="chart-container full-width">
                    <div class="chart-title">🌍 Global Threat Heatmap</div>
                    <div id="geoHeatmapChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">📈 Alert Volume Over Time</div>
                    <div id="alertVolumeChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">🔥 Top Threat Sources</div>
                    <div id="topSourcesChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">🏢 ASN Infrastructure Analysis</div>
                    <div id="asnAnalysisChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">⚡ Real-time Threat Feed</div>
                    <div id="realTimeFeed" class="threat-feed"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">🎯 IOC Type Distribution</div>
                    <div id="iocTypeChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">📊 Severity Trends</div>
                    <div id="severityTrendsChart"></div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">🔗 Threat Correlation Matrix</div>
                    <div id="correlationMatrix"></div>
                </div>
            </div>
            
            <div class="campaigns-section" style="margin-top: 30px;">
                <h3 style="color: #ff6b35;">🧬 Detected Threat Campaigns</h3>
                <div id="campaignsContainer">
                    <div class="loading">Click "Detect Campaigns" to analyze threat patterns...</div>
                </div>
            </div>
        </div>
        
        <div class="view-container" id="exportView">
            <h2 style="color: #ff6b35; margin-bottom: 20px;">📤 Data Export</h2>
            
            <div class="export-section">
                <h3>Threat Intelligence Export</h3>
                <p>Export comprehensive threat data for analysis or integration with other tools.</p>
                
                <div style="margin: 20px 0;">
                    <h4>Export Format:</h4>
                    <button class="export-btn" onclick="exportData('json', 'threats')">JSON Format</button>
                    <button class="export-btn" onclick="exportData('csv', 'threats')">CSV Format</button>
                    <button class="export-btn" onclick="exportData('pdf', 'threats')">PDF Report</button>
                </div>
                
                <div style="margin: 20px 0;">
                    <h4>IOC Database Export:</h4>
                    <button class="export-btn" onclick="exportData('json', 'iocs')">IOC JSON</button>
                    <button class="export-btn" onclick="exportData('csv', 'iocs')">IOC CSV</button>
                    <button class="export-btn" onclick="exportData('pdf', 'iocs')">IOC Report</button>
                </div>
                
                <div style="margin: 20px 0;">
                    <h4>Integration Formats:</h4>
                    <button class="export-btn" onclick="exportData('misp', 'threats')">MISP Events</button>
                    <button class="export-btn" onclick="exportData('stix', 'threats')">STIX 2.1 Bundle</button>
                    <button class="export-btn" onclick="exportData('taxii', 'threats')">TAXII Collection</button>
                    <button class="export-btn" onclick="exportData('yara', 'iocs')">YARA Rules</button>
                </div>
                
                <div style="margin: 20px 0;">
                    <h4>Campaign Analysis:</h4>
                    <button class="export-btn" onclick="exportCampaigns('json')">Campaign Data</button>
                    <button class="export-btn" onclick="exportData('json', 'campaigns')">Campaign Timeline</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- IOC Details Modal -->
    <div id="iocModal" class="ioc-details-modal">
        <div class="modal-content">
            <span class="close" onclick="closeIOCModal()">&times;</span>
            <div id="iocModalContent">
                <div class="loading">Loading IOC details...</div>
            </div>
        </div>
    </div>

    <script>
        let dashboardData = {};
        let currentView = 'overview';
        
        async function loadDashboardData() {
            try {
                const [stats, threats, severityData, timelineData, sourcesData] = await Promise.all([
                    fetch('/api/stats').then(r => r.json()),
                    fetch('/api/threats?per_page=50').then(r => r.json()),
                    fetch('/api/severity-chart').then(r => r.json()),
                    fetch('/api/timeline-chart').then(r => r.json()),
                    fetch('/api/sources-chart').then(r => r.json())
                ]);
                
                dashboardData = { stats, threats, severityData, timelineData, sourcesData };
                updateDashboard();
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            }
        }
        
        async function loadIOCDatabase(search = '', type = 'all', page = 1) {
            try {
                const response = await fetch(`/api/ioc-database?search=${encodeURIComponent(search)}&type=${type}&page=${page}&per_page=20`);
                const data = await response.json();
                displayIOCDatabase(data);
            } catch (error) {
                console.error('Error loading IOC database:', error);
            }
        }
        
        async function loadAlertVolume(timeframe = '24h') {
            try {
                const response = await fetch(`/api/alert-volume?timeframe=${timeframe}`);
                const data = await response.json();
                displayAlertVolume(data);
            } catch (error) {
                console.error('Error loading alert volume:', error);
            }
        }
        
        async function loadIOCDetails(ioc) {
            try {
                const response = await fetch(`/api/ioc-details/${encodeURIComponent(ioc)}`);
                const data = await response.json();
                displayIOCDetails(data);
            } catch (error) {
                console.error('Error loading IOC details:', error);
            }
        }
        
        function updateDashboard() {
            updateStats();
            updateCharts();
            updateThreats();
        }
        
        function updateStats() {
            const stats = dashboardData.stats;
            const statsHtml = `
                <div class="stat-card">
                    <div class="stat-number">${stats.total_threats}</div>
                    <div class="stat-label">Total Threats</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${stats.threats_24h}</div>
                    <div class="stat-label">Last 24 Hours</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${stats.unique_iocs}</div>
                    <div class="stat-label">Unique IOCs</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">${Object.keys(stats.source_activity).length}</div>
                    <div class="stat-label">Active Sources</div>
                </div>
            `;
            document.getElementById('statsGrid').innerHTML = statsHtml;
        }
        
        function updateCharts() {
            // Severity pie chart
            const severityData = dashboardData.severityData;
            Plotly.newPlot('severityChart', [{
                values: severityData.values,
                labels: severityData.labels,
                type: 'pie',
                marker: { colors: severityData.colors }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' }
            });
            
            // Timeline chart
            const timelineData = dashboardData.timelineData;
            Plotly.newPlot('timelineChart', [{
                x: timelineData.map(d => d.time),
                y: timelineData.map(d => d.count),
                type: 'scatter',
                mode: 'lines+markers',
                line: { color: '#ff6b35' }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { color: '#fff' },
                yaxis: { color: '#fff' }
            });
            
            // Sources bar chart
            const sourcesData = dashboardData.sourcesData;
            Plotly.newPlot('sourcesChart', [{
                x: sourcesData.labels,
                y: sourcesData.values,
                type: 'bar',
                marker: { color: '#ff6b35' }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { color: '#fff' },
                yaxis: { color: '#fff' }
            });
        }
        
        function updateThreats() {
            const threats = dashboardData.threats.threats || [];
            const threatsHtml = threats.map(threat => `
                <div class="threat-item severity-${threat.severity}">
                    <div class="threat-title">${threat.title}</div>
                    <div class="threat-meta">
                        ${threat.severity.toUpperCase()} | ${threat.source} | ${threat.category} | ${new Date(threat.timestamp).toLocaleString()}
                    </div>
                    ${threat.iocs && threat.iocs.length ? `<div class="threat-meta">IOCs: ${threat.iocs.slice(0, 3).join(', ')}${threat.iocs.length > 3 ? '...' : ''}</div>` : ''}
                </div>
            `).join('');
            
            document.getElementById('threatsContainer').innerHTML = threatsHtml || '<div class="loading">No threats found</div>';
        }
        
        async function searchThreats(query) {
            if (query.length < 2) {
                updateThreats();
                return;
            }
            
            try {
                const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
                const results = await response.json();
                
                const threatsHtml = results.map(threat => `
                    <div class="threat-item severity-${threat.severity}">
                        <div class="threat-title">${threat.title}</div>
                        <div class="threat-meta">
                            ${threat.severity.toUpperCase()} | ${threat.source} | ${threat.category} | ${new Date(threat.timestamp).toLocaleString()}
                        </div>
                        ${threat.iocs && threat.iocs.length ? `<div class="threat-meta">IOCs: ${threat.iocs.slice(0, 3).join(', ')}${threat.iocs.length > 3 ? '...' : ''}</div>` : ''}
                    </div>
                `).join('');
                
                document.getElementById('threatsContainer').innerHTML = threatsHtml || '<div class="loading">No matching threats found</div>';
            } catch (error) {
                console.error('Search error:', error);
            }
        }
        
        function refreshDashboard() {
            document.getElementById('statsGrid').innerHTML = '<div class="loading">Loading statistics...</div>';
            document.getElementById('threatsContainer').innerHTML = '<div class="loading">Loading threats...</div>';
            loadDashboardData();
        }
        
        function switchView(viewName) {
            // Hide all views
            document.querySelectorAll('.view-container').forEach(view => {
                view.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected view
            document.getElementById(viewName + 'View').classList.add('active');
            event.target.classList.add('active');
            
            currentView = viewName;
            
            // Load data based on view
            if (viewName === 'iocs') {
                loadIOCDatabase();
            } else if (viewName === 'analytics') {
                loadAdvancedAnalytics();
            }
        }
        
        function displayIOCDatabase(data) {
            const container = document.getElementById('iocTableContainer');
            
            if (data.iocs.length === 0) {
                container.innerHTML = '<div class="loading">No IOCs found</div>';
                return;
            }
            
            let html = `
                <table class="ioc-table">
                    <tr>
                        <th>IOC</th>
                        <th>Type</th>
                        <th>Severity</th>
                        <th>Category</th>
                        <th>Source</th>
                        <th>First Seen</th>
                        <th>Priority Score</th>
                    </tr>
            `;
            
            data.iocs.forEach(ioc => {
                html += `
                    <tr onclick="showIOCDetails('${ioc.ioc}')">
                        <td style="font-family: monospace;">${ioc.ioc}</td>
                        <td><span class="ioc-type type-${ioc.type}">${ioc.type.toUpperCase()}</span></td>
                        <td class="severity-${ioc.severity}">${ioc.severity.toUpperCase()}</td>
                        <td>${ioc.category}</td>
                        <td>${ioc.source}</td>
                        <td>${new Date(ioc.first_seen).toLocaleDateString()}</td>
                        <td>${ioc.priority_score}</td>
                    </tr>
                `;
            });
            
            html += '</table>';
            container.innerHTML = html;
            
            // Update pagination
            updateIOCPagination(data);
        }
        
        function displayAlertVolume(data) {
            // Alert volume chart
            const timeLabels = data.buckets.map(b => b.time);
            const totalData = data.buckets.map(b => b.total);
            const criticalData = data.buckets.map(b => b.critical);
            const highData = data.buckets.map(b => b.high);
            
            Plotly.newPlot('alertVolumeChart', [
                {
                    x: timeLabels,
                    y: totalData,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Total Alerts',
                    line: { color: '#ff6b35' }
                },
                {
                    x: timeLabels,
                    y: criticalData,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'Critical',
                    line: { color: '#ff0000' }
                },
                {
                    x: timeLabels,
                    y: highData,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: 'High',
                    line: { color: '#ff8000' }
                }
            ], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { color: '#fff' },
                yaxis: { color: '#fff' },
                title: { text: `Alert Volume (${data.timeframe})`, font: { color: '#fff' } }
            });
            
            // Threat family chart
            const familyData = {};
            data.buckets.forEach(bucket => {
                Object.entries(bucket.families).forEach(([family, count]) => {
                    familyData[family] = (familyData[family] || 0) + count;
                });
            });
            
            Plotly.newPlot('threatFamilyChart', [{
                values: Object.values(familyData),
                labels: Object.keys(familyData),
                type: 'pie',
                marker: {
                    colors: ['#ff6b35', '#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#607D8B']
                }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' }
            });
        }
        
        function showIOCDetails(ioc) {
            document.getElementById('iocModal').style.display = 'block';
            loadIOCDetails(ioc);
        }
        
        function displayIOCDetails(data) {
            const content = document.getElementById('iocModalContent');
            
            let html = `
                <h2>IOC Details: ${data.ioc}</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0;">
                    <div>
                        <h3>Basic Information</h3>
                        <p><strong>Type:</strong> ${data.type.toUpperCase()}</p>
                        <p><strong>Threat Count:</strong> ${data.threat_count}</p>
                        <p><strong>First Seen:</strong> ${new Date(data.first_seen).toLocaleString()}</p>
                        <p><strong>Last Seen:</strong> ${new Date(data.last_seen).toLocaleString()}</p>
                    </div>
                    <div>
                        <h3>Related Threats</h3>
                        <div style="max-height: 200px; overflow-y: auto;">
            `;
            
            data.related_threats.forEach(threat => {
                html += `
                    <div style="margin: 10px 0; padding: 10px; background: #2a2a2a; border-radius: 5px;">
                        <strong>${threat.title}</strong><br>
                        <small>${threat.severity.toUpperCase()} | ${threat.source}</small>
                    </div>
                `;
            });
            
            html += `
                        </div>
                    </div>
                </div>
                <div class="correlation-graph" id="correlationGraph"></div>
            `;
            
            content.innerHTML = html;
            
            // Display correlation graph
            if (data.correlation_graph.nodes.length > 0) {
                displayCorrelationGraph(data.correlation_graph);
            }
        }
        
        function displayCorrelationGraph(graphData) {
            // Simple network visualization using Plotly
            const nodes = graphData.nodes;
            const edges = graphData.edges;
            
            const nodeX = nodes.map((n, i) => Math.cos(i * 2 * Math.PI / nodes.length));
            const nodeY = nodes.map((n, i) => Math.sin(i * 2 * Math.PI / nodes.length));
            
            // Create edge traces
            const edgeTraces = [];
            edges.forEach(edge => {
                const sourceIndex = nodes.findIndex(n => n.id === edge.source);
                const targetIndex = nodes.findIndex(n => n.id === edge.target);
                
                if (sourceIndex !== -1 && targetIndex !== -1) {
                    edgeTraces.push({
                        x: [nodeX[sourceIndex], nodeX[targetIndex], null],
                        y: [nodeY[sourceIndex], nodeY[targetIndex], null],
                        mode: 'lines',
                        line: { color: '#666', width: 1 },
                        showlegend: false,
                        hoverinfo: 'none'
                    });
                }
            });
            
            // Create node trace
            const nodeTrace = {
                x: nodeX,
                y: nodeY,
                mode: 'markers+text',
                marker: {
                    size: nodes.map(n => n.size || 10),
                    color: nodes.map(n => n.color || '#ff6b35')
                },
                text: nodes.map(n => n.label),
                textposition: 'middle center',
                showlegend: false
            };
            
            Plotly.newPlot('correlationGraph', [...edgeTraces, nodeTrace], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { visible: false },
                yaxis: { visible: false },
                title: { text: 'IOC Correlation Network', font: { color: '#fff' } }
            });
        }
        
        function closeIOCModal() {
            document.getElementById('iocModal').style.display = 'none';
        }
        
        function searchIOCs() {
            const search = document.getElementById('iocSearch').value;
            const type = document.getElementById('iocTypeFilter').value;
            const severity = document.getElementById('severityFilter').value;
            loadIOCDatabase(search, type, 1);
        }
        
        function filterIOCs() {
            searchIOCs();
        }
        
        async function loadGeoHeatmap() {
            try {
                const response = await fetch('/api/geo-heatmap');
                const data = await response.json();
                displayGeoHeatmap(data);
            } catch (error) {
                console.error('Error loading geo heatmap:', error);
            }
        }
        
        async function loadCampaigns() {
            try {
                const response = await fetch('/api/campaigns');
                const data = await response.json();
                displayCampaigns(data);
            } catch (error) {
                console.error('Error loading campaigns:', error);
            }
        }
        
        async function loadThreatTrends(timeframe = '7d') {
            try {
                const response = await fetch(`/api/threat-trends?timeframe=${timeframe}`);
                const data = await response.json();
                displayThreatTrends(data);
            } catch (error) {
                console.error('Error loading threat trends:', error);
            }
        }
        
        function displayGeoHeatmap(data) {
            // World map visualization
            const countries = data.countries;
            const locations = data.locations;
            
            // Prepare data for choropleth map
            const countryValues = [];
            const countryTexts = [];
            
            for (const [code, info] of Object.entries(countries)) {
                countryValues.push(info.threat_count);
                countryTexts.push(`${info.country}: ${info.threat_count} threats`);
            }
            
            // Create choropleth map
            Plotly.newPlot('geoHeatmapChart', [{
                type: 'choropleth',
                locations: Object.keys(countries),
                z: countryValues,
                text: countryTexts,
                colorscale: [
                    [0, '#2c3e50'],
                    [0.2, '#f39c12'],
                    [0.5, '#e74c3c'],
                    [1, '#c0392b']
                ],
                colorbar: {
                    title: 'Threat Count',
                    titlefont: { color: '#fff' },
                    tickfont: { color: '#fff' }
                }
            }], {
                geo: {
                    projection: { type: 'natural earth' },
                    bgcolor: 'rgba(0,0,0,0)',
                    showframe: false,
                    showcoastlines: true,
                    coastlinecolor: '#444'
                },
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                title: { text: 'Global Threat Distribution', font: { color: '#fff' } }
            });
        }
        
        function displayCampaigns(data) {
            const container = document.getElementById('campaignsContainer');
            
            if (data.campaigns.length === 0) {
                container.innerHTML = '<div class="loading">No threat campaigns detected</div>';
                return;
            }
            
            let html = `<div style="margin-bottom: 20px; color: #ccc;">Detected ${data.total_campaigns} threat campaigns:</div>`;
            
            data.campaigns.forEach(campaign => {
                const confidenceClass = campaign.confidence_score >= 70 ? 'high' : campaign.confidence_score >= 50 ? 'medium' : 'low';
                
                html += `
                    <div class="campaign-card" style="background: #2a2a2a; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #ff6b35;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <h4 style="color: #ff6b35; margin: 0;">${campaign.name}</h4>
                            <span class="confidence-${confidenceClass}" style="padding: 4px 8px; border-radius: 4px; font-size: 0.8em; background: #444; color: #fff;">
                                ${campaign.confidence_score.toFixed(1)}% confidence
                            </span>
                        </div>
                        <p style="margin: 10px 0; color: #ccc;">
                            <strong>Threats:</strong> ${campaign.threat_count} | 
                            <strong>Countries:</strong> ${campaign.countries.join(', ') || 'Unknown'} |
                            <strong>Duration:</strong> ${campaign.first_seen.substring(0, 10)} to ${campaign.last_seen.substring(0, 10)}
                        </p>
                        <div style="margin: 10px 0;">
                            <strong style="color: #fff;">Infrastructure:</strong> ${campaign.c2_infrastructure.slice(0, 3).join(', ')}
                            ${campaign.c2_infrastructure.length > 3 ? '...' : ''}
                        </div>
                        <div style="margin: 10px 0;">
                            <strong style="color: #fff;">Attack Patterns:</strong> ${campaign.attack_patterns.join(', ')}
                        </div>
                        <button class="export-btn" style="margin-top: 10px;" onclick="viewCampaignTimeline('${campaign.id}')">
                            View Timeline
                        </button>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }
        
        function displayThreatTrends(data) {
            // Prepare data for trends chart
            const families = Object.keys(data.family_trends);
            const traces = [];
            
            families.forEach((family, index) => {
                const buckets = data.family_trends[family];
                const xData = Object.keys(buckets).map(b => parseInt(b));
                const yData = Object.values(buckets);
                
                traces.push({
                    x: xData,
                    y: yData,
                    type: 'scatter',
                    mode: 'lines+markers',
                    name: family,
                    line: { 
                        color: ['#ff6b35', '#2196F3', '#4CAF50', '#FF9800', '#9C27B0'][index % 5]
                    }
                });
            });
            
            // Add anomaly markers
            data.anomalies.forEach(anomaly => {
                traces.push({
                    x: [anomaly.bucket],
                    y: [anomaly.count],
                    type: 'scatter',
                    mode: 'markers',
                    name: `Anomaly: ${anomaly.family}`,
                    marker: {
                        color: '#ff0000',
                        size: 12,
                        symbol: 'diamond'
                    }
                });
            });
            
            Plotly.newPlot('threatTrendsChart', traces, {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { 
                    title: 'Time Buckets',
                    color: '#fff'
                },
                yaxis: { 
                    title: 'Threat Count',
                    color: '#fff'
                },
                title: { 
                    text: `Threat Trends (${data.timeframe})`,
                    font: { color: '#fff' }
                },
                legend: { font: { color: '#fff' } }
            });
        }
        
        async function viewCampaignTimeline(campaignId) {
            try {
                const response = await fetch(`/api/campaign-timeline/${campaignId}`);
                const data = await response.json();
                
                if (data.timeline) {
                    // Display timeline in modal or separate view
                    alert(`Campaign Timeline:\n${data.timeline.map(t => `${t.timestamp}: ${t.title}`).join('\n')}`);
                }
            } catch (error) {
                console.error('Error loading campaign timeline:', error);
            }
        }
        
        function exportCampaigns(format) {
            window.open(`/api/campaigns?export=${format}`, '_blank');
        }
        
        function loadAdvancedAnalytics() {
            loadAlertVolume();
            loadGeoHeatmap();
            loadThreatTrends();
            loadTopSources();
            loadASNAnalysis();
            loadIOCTypes();
            loadCorrelationMatrix();
            startRealTimeFeed();
        }
        
        async function loadTopSources() {
            try {
                const response = await fetch('/api/top-sources');
                const data = await response.json();
                displayTopSources(data);
            } catch (error) {
                console.error('Error loading top sources:', error);
            }
        }
        
        async function loadASNAnalysis() {
            try {
                const response = await fetch('/api/asn-analysis');
                const data = await response.json();
                displayASNAnalysis(data);
            } catch (error) {
                console.error('Error loading ASN analysis:', error);
            }
        }
        
        async function loadIOCTypes() {
            try {
                const response = await fetch('/api/ioc-types');
                const data = await response.json();
                displayIOCTypes(data);
            } catch (error) {
                console.error('Error loading IOC types:', error);
            }
        }
        
        async function loadCorrelationMatrix() {
            try {
                const response = await fetch('/api/correlation-matrix');
                const data = await response.json();
                displayCorrelationMatrix(data);
            } catch (error) {
                console.error('Error loading correlation matrix:', error);
            }
        }
        
        function displayTopSources(data) {
            const sources = data.sources.slice(0, 8);
            const names = sources.map(s => s.name);
            const counts = sources.map(s => s.count);
            const criticalCounts = sources.map(s => s.critical);
            
            Plotly.newPlot('topSourcesChart', [{
                x: names,
                y: counts,
                type: 'bar',
                name: 'Total Threats',
                marker: { color: '#ff6b35' }
            }, {
                x: names,
                y: criticalCounts,
                type: 'bar',
                name: 'Critical Threats',
                marker: { color: '#ff0000' }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { color: '#fff', tickangle: -45 },
                yaxis: { color: '#fff' },
                legend: { font: { color: '#fff' } },
                barmode: 'group'
            });
        }
        
        function displayASNAnalysis(data) {
            const clusters = data.asn_clusters.slice(0, 10);
            const asnNames = clusters.map(c => c.name || c.asn);
            const threatCounts = clusters.map(c => c.threat_count);
            const iocCounts = clusters.map(c => c.ioc_count);
            
            Plotly.newPlot('asnAnalysisChart', [{
                labels: asnNames,
                values: threatCounts,
                type: 'pie',
                hole: 0.4,
                marker: {
                    colors: ['#ff6b35', '#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#607D8B', '#795548', '#F44336', '#FFEB3B', '#00BCD4']
                }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' }
            });
        }
        
        function displayIOCTypes(data) {
            const types = data.types;
            const labels = types.map(t => t.type.toUpperCase());
            const values = types.map(t => t.count);
            
            Plotly.newPlot('iocTypeChart', [{
                labels: labels,
                values: values,
                type: 'pie',
                marker: {
                    colors: ['#ff6b35', '#2196F3', '#4CAF50', '#FF9800', '#9C27B0', '#607D8B']
                }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' }
            });
        }
        
        function displayCorrelationMatrix(data) {
            if (data.matrix.length === 0) return;
            
            Plotly.newPlot('correlationMatrix', [{
                z: data.matrix,
                x: data.categories,
                y: data.sources,
                type: 'heatmap',
                colorscale: [
                    [0, '#1a1a1a'],
                    [0.2, '#ff6b35'],
                    [0.5, '#ff8000'],
                    [1, '#ff0000']
                ],
                colorbar: {
                    title: 'Threat Count',
                    titlefont: { color: '#fff' },
                    tickfont: { color: '#fff' }
                }
            }], {
                paper_bgcolor: 'rgba(0,0,0,0)',
                plot_bgcolor: 'rgba(0,0,0,0)',
                font: { color: '#fff' },
                xaxis: { color: '#fff', tickangle: -45 },
                yaxis: { color: '#fff' }
            });
        }
        
        function startRealTimeFeed() {
            loadRealTimeFeed();
            setInterval(loadRealTimeFeed, 10000); // Update every 10 seconds
        }
        
        async function loadRealTimeFeed() {
            try {
                const response = await fetch('/api/realtime-feed?limit=5');
                const data = await response.json();
                displayRealTimeFeed(data);
            } catch (error) {
                console.error('Error loading real-time feed:', error);
            }
        }
        
        function displayRealTimeFeed(data) {
            const container = document.getElementById('realTimeFeed');
            
            let html = '';
            data.threats.forEach(threat => {
                const severity = threat.severity || 'medium';
                const timeAgo = getTimeAgo(threat.timestamp);
                
                html += `
                    <div class="threat-item ${severity}">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <strong>${threat.title || 'Unknown Threat'}</strong>
                            <small style="color: #999;">${timeAgo}</small>
                        </div>
                        <div style="margin-top: 5px; color: #ccc; font-size: 0.9em;">
                            ${threat.source || 'Unknown'} • ${threat.category || 'General'} • ${threat.iocs ? threat.iocs.length : 0} IOCs
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML = html || '<div style="text-align: center; color: #666;">No recent threats</div>';
        }
        
        function getTimeAgo(timestamp) {
            if (!timestamp) return 'Unknown';
            
            const now = new Date();
            const time = new Date(timestamp);
            const diffMs = now - time;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);
            
            if (diffMins < 1) return 'Just now';
            if (diffMins < 60) return `${diffMins}m ago`;
            if (diffHours < 24) return `${diffHours}h ago`;
            return `${diffDays}d ago`;
        }
        
        function updateAnalytics() {
            const timeframe = document.getElementById('timeframeSelect').value;
            loadAlertVolume(timeframe);
            loadThreatTrends(timeframe);
            loadGeoHeatmap();
        }
        
        function updateIOCPagination(data) {
            const container = document.getElementById('iocPagination');
            const totalPages = Math.ceil(data.total / data.per_page);
            
            let html = '';
            
            if (data.page > 1) {
                html += `<button class="page-btn" onclick="loadIOCDatabase('', 'all', ${data.page - 1})">Previous</button>`;
            }
            
            for (let i = Math.max(1, data.page - 2); i <= Math.min(totalPages, data.page + 2); i++) {
                const activeClass = i === data.page ? 'active' : '';
                html += `<button class="page-btn ${activeClass}" onclick="loadIOCDatabase('', 'all', ${i})">${i}</button>`;
            }
            
            if (data.has_next) {
                html += `<button class="page-btn" onclick="loadIOCDatabase('', 'all', ${data.page + 1})">Next</button>`;
            }
            
            container.innerHTML = html;
        }
        
        function exportData(format, type) {
            const url = `/api/export?format=${format}&type=${type}`;
            window.open(url, '_blank');
        }
        
        // Initialize with overview tab active
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('overviewView').classList.add('active');
        });
        
        // Auto-refresh every 30 seconds
        setInterval(loadDashboardData, 30000);
        
        // Initial load
        loadDashboardData();
    </script>
</body>
</html>'''
    
    with open(template_dir / "dashboard.html", "w") as f:
        f.write(html_content)