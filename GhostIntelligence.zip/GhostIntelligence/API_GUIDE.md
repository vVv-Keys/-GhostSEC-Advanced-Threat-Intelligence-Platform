# GhostSEC API Keys Setup Guide

## Discord Bot Invite Link

**Get your bot Client ID from Discord Developer Portal:**
1. Go to: https://discord.com/developers/applications
2. Select your GhostSEC application 
3. Copy the "Application ID" from General Information
4. Replace `YOUR_BOT_CLIENT_ID` in this URL:

```
https://discord.com/oauth2/authorize?client_id=YOUR_BOT_CLIENT_ID&permissions=2147862592&scope=bot%20applications.commands
```

## Premium API Keys (Optional but Recommended)

### 1. AlienVault OTX (Free)
- **Website**: https://otx.alienvault.com/
- **Sign up**: Create free account
- **API Key**: Profile → Settings → API Key
- **Setup**: `export ALIENVAULT_API_KEY="your_api_key"`

### 2. VirusTotal (Free Tier)
- **Website**: https://www.virustotal.com/
- **Sign up**: Create free account  
- **API Key**: Profile → API Key
- **Setup**: `export VIRUSTOTAL_API_KEY="your_api_key"`

### 3. Shodan (Free Tier)
- **Website**: https://www.shodan.io/
- **Sign up**: Create free account
- **API Key**: Account → API Key
- **Setup**: `export SHODAN_API_KEY="your_api_key"`

## Notification Setup

### Email Alerts
For Gmail (recommended):
1. Enable 2-factor authentication
2. Generate app password: https://myaccount.google.com/apppasswords
3. Setup:
```bash
export SMTP_USERNAME="your_email@gmail.com"
export SMTP_PASSWORD="your_app_password"
```

### Slack Integration
1. Create Slack webhook: https://api.slack.com/messaging/webhooks
2. Setup: `export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/..."`

### Microsoft Teams
1. Create Teams webhook in your channel
2. Setup: `export TEAMS_WEBHOOK_URL="https://your-teams-webhook"`

## Current Platform Status

✅ **Dashboard**: http://localhost:5000
- Overview with real-time statistics
- IOC Database with correlation graphs
- Advanced Analytics with 8 visualization types
- Multi-format export capabilities

✅ **Honeypot Integration**: http://localhost:5001
- Generic webhook endpoint
- Cowrie SSH honeypot support
- Dionaea malware trap integration
- DShield log processing

✅ **Discord Bot**: Ready for invite
- 15+ threat management commands
- Automated channel routing
- Real-time threat alerts

## Enhanced Dashboard Features

The platform now includes these advanced visualizations:

1. **Global Threat Heatmap** - World map with country-based threat distribution
2. **Alert Volume Over Time** - Time-series analysis with severity breakdown
3. **Top Threat Sources** - Bar chart of most active intelligence sources
4. **ASN Infrastructure Analysis** - Pie chart of threat clusters by hosting provider
5. **Real-time Threat Feed** - Live updating threat stream with severity indicators
6. **IOC Type Distribution** - Breakdown of indicator types (IP, domain, hash, etc.)
7. **Severity Trends** - Historical severity pattern analysis
8. **Threat Correlation Matrix** - Heatmap showing source vs category correlations

## Testing Your Setup

### Basic Dashboard Test
```bash
curl http://localhost:5000/api/stats
```

### Honeypot Webhook Test
```bash
curl -X POST http://localhost:5001/webhook/generic \
  -H "Content-Type: application/json" \
  -d '{
    "timestamp": "2025-06-21T14:30:00Z",
    "source_ip": "203.0.113.42",
    "event_type": "Test Alert",
    "severity": "medium"
  }'
```

### Discord Bot Test
After inviting bot to your server:
```
!ghost ping
!ghost status
!ghost test high
```

Once you provide the API keys, the platform will have:
- Enhanced threat intelligence coverage
- Automated email/Slack notifications
- Premium IOC analysis capabilities
- Enterprise-grade monitoring and alerting

Ready to receive your API keys to activate all premium features!