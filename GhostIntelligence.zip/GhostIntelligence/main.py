#!/usr/bin/env python3
"""
GhostSEC Discord Bot - Main Entry Point
Cyber Threat Intelligence Feed Bot with Multi-source Aggregation
"""

import asyncio
import os
import sys
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).parent))

from bot.bot import GhostSECBot
from utils.logger import setup_logger
from config.settings import Settings

async def main():
    """Main entry point for the GhostSEC bot"""
    # Setup logging
    logger = setup_logger()
    
    # Load settings
    settings = Settings()
    
    # Get Discord token from environment
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        logger.error("DISCORD_TOKEN environment variable not set")
        sys.exit(1)
    
    # Initialize and start bot
    bot = GhostSECBot(settings)
    
    try:
        logger.info("Starting GhostSEC Bot 👻")
        await bot.start(token)
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
    finally:
        await bot.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBot stopped by user")
    except Exception as e:
        print(f"Failed to start bot: {e}")
