"""
Duplicate Filter
Hash-based duplicate detection system for threat intelligence
"""

import hashlib
import json
import os
from pathlib import Path
import logging
from datetime import datetime, timedelta

class DuplicateFilter:
    def __init__(self, cache_file="data/seen_hashes.json", max_age_days=7):
        self.cache_file = Path(cache_file)
        self.max_age_days = max_age_days
        self.seen_hashes = self.load_cache()
        self.logger = logging.getLogger(__name__)
        
    def load_cache(self):
        """Load seen hashes from cache file"""
        try:
            if self.cache_file.exists():
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
                    # Clean old entries
                    self.clean_old_entries(data)
                    return data
            else:
                return {}
        except Exception as e:
            self.logger.error(f"Error loading duplicate cache: {e}")
            return {}
    
    def save_cache(self):
        """Save seen hashes to cache file"""
        try:
            import os
            import json
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump(self.seen_hashes, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving duplicate cache: {e}")
    
    def clean_old_entries(self, data):
        """Remove entries older than max_age_days"""
        cutoff_date = datetime.utcnow() - timedelta(days=self.max_age_days)
        cutoff_timestamp = cutoff_date.timestamp()
        
        keys_to_remove = []
        for hash_key, entry in data.items():
            if isinstance(entry, dict) and 'timestamp' in entry:
                try:
                    entry_timestamp = datetime.fromisoformat(entry['timestamp']).timestamp()
                    if entry_timestamp < cutoff_timestamp:
                        keys_to_remove.append(hash_key)
                except:
                    # Remove invalid entries
                    keys_to_remove.append(hash_key)
            elif isinstance(entry, (str, int, float)):
                # Old format, remove
                keys_to_remove.append(hash_key)
        
        for key in keys_to_remove:
            del data[key]
        
        if keys_to_remove:
            self.logger.info(f"Cleaned {len(keys_to_remove)} old cache entries")
    
    def generate_content_hash(self, threat_data):
        """Generate hash for threat content"""
        # Use multiple fields to create content hash
        content_fields = [
            threat_data.get('title', ''),
            threat_data.get('description', ''),
            threat_data.get('url', ''),
            str(threat_data.get('iocs', [])),
            threat_data.get('source', '')
        ]
        
        content_string = '|'.join(content_fields)
        return hashlib.sha256(content_string.encode('utf-8')).hexdigest()
    
    def generate_similarity_hash(self, threat_data):
        """Generate hash for similarity detection"""
        # Use only title and key IOCs for similarity
        title = threat_data.get('title', '').lower().strip()
        iocs = sorted(threat_data.get('iocs', []))[:5]  # First 5 IOCs
        
        similarity_string = f"{title}|{','.join(iocs)}"
        return hashlib.md5(similarity_string.encode('utf-8')).hexdigest()
    
    def is_duplicate(self, threat_data):
        """Check if threat data is a duplicate"""
        # Generate hashes
        content_hash = self.generate_content_hash(threat_data)
        similarity_hash = self.generate_similarity_hash(threat_data)
        
        # Check exact content match
        if content_hash in self.seen_hashes:
            self.logger.debug(f"Exact duplicate found: {content_hash}")
            return True
        
        # Check similarity match
        if similarity_hash in self.seen_hashes:
            self.logger.debug(f"Similar content found: {similarity_hash}")
            return True
        
        # Check for URL duplicates
        url = threat_data.get('url', '')
        if url:
            url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
            if url_hash in self.seen_hashes:
                self.logger.debug(f"URL duplicate found: {url_hash}")
                return True
        
        return False
    
    def mark_seen(self, threat_data):
        """Mark threat data as seen"""
        timestamp = datetime.utcnow().isoformat()
        
        # Store multiple hashes for comprehensive duplicate detection
        content_hash = self.generate_content_hash(threat_data)
        similarity_hash = self.generate_similarity_hash(threat_data)
        
        entry_data = {
            'timestamp': timestamp,
            'title': threat_data.get('title', '')[:100],  # Store truncated title for debugging
            'source': threat_data.get('source', ''),
            'category': threat_data.get('category', '')
        }
        
        self.seen_hashes[content_hash] = entry_data
        self.seen_hashes[similarity_hash] = entry_data
        
        # Store URL hash if available
        url = threat_data.get('url', '')
        if url:
            url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
            self.seen_hashes[url_hash] = entry_data
        
        # Save cache periodically
        if len(self.seen_hashes) % 10 == 0:
            self.save_cache()
    
    def get_cache_stats(self):
        """Get cache statistics"""
        total_entries = len(self.seen_hashes)
        
        # Count by source
        sources = {}
        categories = {}
        
        for entry in self.seen_hashes.values():
            if isinstance(entry, dict):
                source = entry.get('source', 'Unknown')
                category = entry.get('category', 'Unknown')
                
                sources[source] = sources.get(source, 0) + 1
                categories[category] = categories.get(category, 0) + 1
        
        return {
            'total_entries': total_entries,
            'sources': sources,
            'categories': categories,
            'cache_file_size': self.cache_file.stat().st_size if self.cache_file.exists() else 0
        }
    
    def clear_cache(self):
        """Clear all cached hashes"""
        self.seen_hashes = {}
        self.save_cache()
        self.logger.info("Duplicate detection cache cleared")
    
    def cleanup_cache(self):
        """Manual cleanup of old entries"""
        old_count = len(self.seen_hashes)
        self.clean_old_entries(self.seen_hashes)
        new_count = len(self.seen_hashes)
        
        if old_count != new_count:
            self.save_cache()
            self.logger.info(f"Cache cleanup: removed {old_count - new_count} old entries")
    
    def __del__(self):
        """Save cache on object destruction"""
        try:
            self.save_cache()
        except:
            pass
