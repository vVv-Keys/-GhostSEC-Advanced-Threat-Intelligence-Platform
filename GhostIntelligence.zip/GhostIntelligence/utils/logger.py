"""
Logging Configuration
Centralized logging setup for GhostSEC bot
"""

import logging
import os
import sys
from datetime import datetime
from pathlib import Path

def setup_logger(name="ghostsec", level=logging.INFO, log_file=None):
    """Setup logger with console and file output"""
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Prevent duplicate handlers
    if logger.handlers:
        return logger
    
    # Create formatters
    console_formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    file_formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(funcName)s() | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # File handler
    if log_file is None:
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        log_file = log_dir / f"ghostsec_{datetime.now().strftime('%Y%m%d')}.log"
    
    try:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)  # More detailed logging to file
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"Could not create file handler: {e}")
    
    # Set level based on environment variable
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
    if hasattr(logging, log_level):
        logger.setLevel(getattr(logging, log_level))
    
    return logger

class BotFilter(logging.Filter):
    """Custom filter for bot-specific logging"""
    
    def filter(self, record):
        # Filter out Discord.py debug messages unless specifically requested
        if record.name.startswith('discord') and record.levelno < logging.WARNING:
            return False
        
        # Filter out aiohttp debug messages
        if record.name.startswith('aiohttp') and record.levelno < logging.WARNING:
            return False
        
        return True

def setup_discord_logging():
    """Setup Discord.py specific logging"""
    discord_logger = logging.getLogger('discord')
    discord_logger.setLevel(logging.WARNING)  # Only warnings and errors
    
    # Add custom filter
    bot_filter = BotFilter()
    for handler in discord_logger.handlers:
        handler.addFilter(bot_filter)

def get_logger(name=None):
    """Get a logger instance"""
    if name is None:
        name = __name__
    
    return logging.getLogger(name)

# Performance logging decorator
def log_execution_time(logger=None):
    """Decorator to log function execution time"""
    import time
    import functools
    
    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = get_logger(func.__module__)
            
            start_time = time.time()
            try:
                result = await func(*args, **kwargs)
                execution_time = time.time() - start_time
                logger.debug(f"{func.__name__} executed in {execution_time:.3f}s")
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                logger.error(f"{func.__name__} failed after {execution_time:.3f}s: {e}")
                raise
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = get_logger(func.__module__)
            
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                logger.debug(f"{func.__name__} executed in {execution_time:.3f}s")
                return result
            except Exception as e:
                execution_time = time.time() - start_time
                logger.error(f"{func.__name__} failed after {execution_time:.3f}s: {e}")
                raise
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator

# Initialize logging on import
try:
    import asyncio
    setup_discord_logging()
except ImportError:
    pass
