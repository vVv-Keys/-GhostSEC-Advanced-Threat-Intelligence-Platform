"""
Feed Scheduler
Manages automated scheduling of threat intelligence feed updates
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Callable

class FeedScheduler:
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.scheduled_tasks = {}
        self.running = False
        
    async def start(self):
        """Start the scheduler"""
        if not self.running:
            self.running = True
            self.logger.info("Feed scheduler started")
    
    async def stop(self):
        """Stop the scheduler and cancel all tasks"""
        self.running = False
        
        for task_name, task in self.scheduled_tasks.items():
            if not task.done():
                task.cancel()
                self.logger.info(f"Cancelled scheduled task: {task_name}")
        
        self.scheduled_tasks.clear()
        self.logger.info("Feed scheduler stopped")
    
    def schedule_feed_updates(self, interval_minutes: int = 15):
        """Schedule regular feed updates"""
        async def update_task():
            while self.running:
                try:
                    self.logger.info("Starting scheduled feed update")
                    await self.bot.feed_manager.update_all_feeds()
                    self.logger.info("Scheduled feed update completed")
                except Exception as e:
                    self.logger.error(f"Error in scheduled feed update: {e}")
                
                # Wait for next interval
                await asyncio.sleep(interval_minutes * 60)
        
        if 'feed_updates' not in self.scheduled_tasks:
            task = asyncio.create_task(update_task())
            self.scheduled_tasks['feed_updates'] = task
            self.logger.info(f"Scheduled feed updates every {interval_minutes} minutes")
    
    def schedule_cache_cleanup(self, interval_hours: int = 6):
        """Schedule periodic cache cleanup"""
        async def cleanup_task():
            while self.running:
                try:
                    self.logger.info("Starting scheduled cache cleanup")
                    self.bot.duplicate_filter.cleanup_cache()
                    self.logger.info("Scheduled cache cleanup completed")
                except Exception as e:
                    self.logger.error(f"Error in scheduled cache cleanup: {e}")
                
                # Wait for next interval
                await asyncio.sleep(interval_hours * 3600)
        
        if 'cache_cleanup' not in self.scheduled_tasks:
            task = asyncio.create_task(cleanup_task())
            self.scheduled_tasks['cache_cleanup'] = task
            self.logger.info(f"Scheduled cache cleanup every {interval_hours} hours")
    
    def schedule_stats_report(self, interval_hours: int = 24):
        """Schedule periodic statistics reporting"""
        async def stats_task():
            while self.running:
                try:
                    await asyncio.sleep(interval_hours * 3600)  # Wait first, then report
                    
                    if self.running:
                        self.logger.info("Generating scheduled statistics report")
                        await self.generate_stats_report()
                except Exception as e:
                    self.logger.error(f"Error in scheduled stats report: {e}")
        
        if 'stats_report' not in self.scheduled_tasks:
            task = asyncio.create_task(stats_task())
            self.scheduled_tasks['stats_report'] = task
            self.logger.info(f"Scheduled stats report every {interval_hours} hours")
    
    async def generate_stats_report(self):
        """Generate and send statistics report"""
        try:
            # Get statistics
            uptime = datetime.utcnow() - self.bot.start_time
            cache_stats = self.bot.duplicate_filter.get_cache_stats()
            feed_status = await self.bot.feed_manager.get_feed_status()
            
            # Create summary
            report = {
                'timestamp': datetime.utcnow().isoformat(),
                'uptime_hours': uptime.total_seconds() / 3600,
                'alerts_sent': self.bot.alerts_sent,
                'feeds_processed': self.bot.feeds_processed,
                'cache_entries': cache_stats['total_entries'],
                'active_sources': feed_status['active_sources'],
                'total_sources': feed_status['total_sources']
            }
            
            self.logger.info(f"Stats report: {report}")
            
            # Optionally send to a dedicated stats channel
            # await self.send_stats_to_channel(report)
            
        except Exception as e:
            self.logger.error(f"Error generating stats report: {e}")
    
    def schedule_custom_task(self, name: str, func: Callable, interval_seconds: int):
        """Schedule a custom task"""
        async def custom_task():
            while self.running:
                try:
                    if asyncio.iscoroutinefunction(func):
                        await func()
                    else:
                        func()
                except Exception as e:
                    self.logger.error(f"Error in custom task {name}: {e}")
                
                await asyncio.sleep(interval_seconds)
        
        if name not in self.scheduled_tasks:
            task = asyncio.create_task(custom_task())
            self.scheduled_tasks[name] = task
            self.logger.info(f"Scheduled custom task '{name}' every {interval_seconds} seconds")
    
    def cancel_task(self, task_name: str):
        """Cancel a specific scheduled task"""
        if task_name in self.scheduled_tasks:
            task = self.scheduled_tasks[task_name]
            if not task.done():
                task.cancel()
            del self.scheduled_tasks[task_name]
            self.logger.info(f"Cancelled task: {task_name}")
    
    def get_scheduled_tasks(self) -> Dict[str, dict]:
        """Get information about all scheduled tasks"""
        task_info = {}
        
        for name, task in self.scheduled_tasks.items():
            task_info[name] = {
                'running': not task.done(),
                'cancelled': task.cancelled(),
                'exception': str(task.exception()) if task.done() and task.exception() else None
            }
        
        return task_info
    
    async def wait_for_tasks(self):
        """Wait for all scheduled tasks to complete"""
        if self.scheduled_tasks:
            await asyncio.gather(*self.scheduled_tasks.values(), return_exceptions=True)
