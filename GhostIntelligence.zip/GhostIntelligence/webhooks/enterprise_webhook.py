"""
Enterprise Webhook Integration
Custom webhook system for enterprise threat intelligence distribution
"""

import requests
import json
import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import hashlib
import hmac
import base64
from urllib.parse import urlparse
import os

class WebhookManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.webhooks = {}
        self.delivery_queue = asyncio.Queue()
        self.failed_deliveries = []
        self.webhook_stats = {}
        
        # Load webhook configurations
        self.load_webhooks()
        
        # Start delivery worker
        self.delivery_worker_task = None
        self.running = False
    
    def load_webhooks(self):
        """Load webhook configurations from file or environment"""
        webhook_config_file = Path("config/webhooks.json")
        
        if webhook_config_file.exists():
            try:
                with open(webhook_config_file, 'r') as f:
                    webhook_configs = json.load(f)
                    
                for config in webhook_configs.get('webhooks', []):
                    self.add_webhook(
                        name=config['name'],
                        url=config['url'],
                        secret=config.get('secret'),
                        filters=config.get('filters', {}),
                        headers=config.get('headers', {}),
                        enabled=config.get('enabled', True)
                    )
                    
                self.logger.info(f"Loaded {len(self.webhooks)} webhook configurations")
                
            except Exception as e:
                self.logger.error(f"Error loading webhook config: {e}")
        
        # Load from environment variables
        self.load_env_webhooks()
    
    def load_env_webhooks(self):
        """Load webhook URLs from environment variables"""
        # Enterprise webhook URLs
        enterprise_webhooks = [
            ('SPLUNK_WEBHOOK', 'Splunk Enterprise'),
            ('ELASTICSEARCH_WEBHOOK', 'Elasticsearch'),
            ('QRADAR_WEBHOOK', 'IBM QRadar'),
            ('SENTINEL_WEBHOOK', 'Microsoft Sentinel'),
            ('PHANTOM_WEBHOOK', 'Splunk Phantom'),
            ('DEMISTO_WEBHOOK', 'Cortex XSOAR'),
            ('SLACK_WEBHOOK', 'Slack Notifications'),
            ('TEAMS_WEBHOOK', 'Microsoft Teams'),
            ('JIRA_WEBHOOK', 'Jira Service Desk'),
            ('SERVICENOW_WEBHOOK', 'ServiceNow')
        ]
        
        for env_var, name in enterprise_webhooks:
            url = os.getenv(env_var)
            if url:
                self.add_webhook(
                    name=name,
                    url=url,
                    secret=os.getenv(f"{env_var}_SECRET"),
                    enabled=True
                )
    
    def add_webhook(self, name: str, url: str, secret: Optional[str] = None, 
                   filters: Dict = None, headers: Dict = None, enabled: bool = True):
        """Add a new webhook endpoint"""
        webhook_id = hashlib.md5(f"{name}:{url}".encode()).hexdigest()[:8]
        
        self.webhooks[webhook_id] = {
            'id': webhook_id,
            'name': name,
            'url': url,
            'secret': secret,
            'filters': filters or {},
            'headers': headers or {},
            'enabled': enabled,
            'created_at': datetime.utcnow().isoformat(),
            'last_delivery': None,
            'delivery_count': 0,
            'error_count': 0
        }
        
        # Initialize stats
        self.webhook_stats[webhook_id] = {
            'total_deliveries': 0,
            'successful_deliveries': 0,
            'failed_deliveries': 0,
            'last_success': None,
            'last_error': None,
            'average_response_time': 0
        }
        
        self.logger.info(f"Added webhook: {name} ({webhook_id})")
        return webhook_id
    
    def remove_webhook(self, webhook_id: str):
        """Remove a webhook endpoint"""
        if webhook_id in self.webhooks:
            name = self.webhooks[webhook_id]['name']
            del self.webhooks[webhook_id]
            if webhook_id in self.webhook_stats:
                del self.webhook_stats[webhook_id]
            self.logger.info(f"Removed webhook: {name} ({webhook_id})")
            return True
        return False
    
    def should_deliver(self, webhook: Dict, threat_data: Dict) -> bool:
        """Check if threat data matches webhook filters"""
        if not webhook.get('enabled', True):
            return False
        
        filters = webhook.get('filters', {})
        
        # Severity filter
        if 'min_severity' in filters:
            severity_levels = {'low': 1, 'medium': 2, 'high': 3, 'critical': 4}
            threat_severity = severity_levels.get(threat_data.get('severity', 'medium').lower(), 2)
            min_severity = severity_levels.get(filters['min_severity'].lower(), 1)
            
            if threat_severity < min_severity:
                return False
        
        # Category filter
        if 'categories' in filters and filters['categories']:
            threat_category = threat_data.get('category', '').lower()
            allowed_categories = [c.lower() for c in filters['categories']]
            
            if threat_category not in allowed_categories:
                return False
        
        # Source filter
        if 'sources' in filters and filters['sources']:
            threat_source = threat_data.get('source', '').lower()
            allowed_sources = [s.lower() for s in filters['sources']]
            
            if not any(source in threat_source for source in allowed_sources):
                return False
        
        # IOC count filter
        if 'min_iocs' in filters:
            ioc_count = len(threat_data.get('iocs', []))
            if ioc_count < filters['min_iocs']:
                return False
        
        # Keyword filter
        if 'keywords' in filters and filters['keywords']:
            threat_text = f"{threat_data.get('title', '')} {threat_data.get('description', '')}".lower()
            required_keywords = [k.lower() for k in filters['keywords']]
            
            if not any(keyword in threat_text for keyword in required_keywords):
                return False
        
        return True
    
    async def send_threat_webhook(self, threat_data: Dict):
        """Send threat data to all applicable webhooks"""
        if not self.webhooks:
            return
        
        for webhook_id, webhook in self.webhooks.items():
            if self.should_deliver(webhook, threat_data):
                await self.delivery_queue.put({
                    'webhook_id': webhook_id,
                    'threat_data': threat_data,
                    'timestamp': datetime.utcnow().isoformat()
                })
    
    async def delivery_worker(self):
        """Background worker to process webhook deliveries"""
        while self.running:
            try:
                # Get delivery task from queue
                delivery_task = await asyncio.wait_for(
                    self.delivery_queue.get(), timeout=1.0
                )
                
                await self.deliver_webhook(delivery_task)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Error in webhook delivery worker: {e}")
    
    async def deliver_webhook(self, delivery_task: Dict):
        """Deliver a single webhook"""
        webhook_id = delivery_task['webhook_id']
        threat_data = delivery_task['threat_data']
        
        if webhook_id not in self.webhooks:
            return
        
        webhook = self.webhooks[webhook_id]
        stats = self.webhook_stats[webhook_id]
        
        try:
            start_time = datetime.utcnow()
            
            # Prepare payload
            payload = self.prepare_payload(webhook, threat_data)
            
            # Prepare headers
            headers = {
                'Content-Type': 'application/json',
                'User-Agent': 'GhostSEC-Webhook/1.0',
                'X-GhostSEC-Event': 'threat.detected',
                'X-GhostSEC-Timestamp': delivery_task['timestamp']
            }
            
            # Add custom headers
            if webhook.get('headers'):
                headers.update(webhook['headers'])
            
            # Add signature if secret is provided
            if webhook.get('secret'):
                signature = self.generate_signature(payload, webhook['secret'])
                headers['X-GhostSEC-Signature'] = signature
            
            # Make HTTP request
            timeout = 30  # 30 second timeout
            
            async with asyncio.timeout(timeout):
                import aiohttp
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        webhook['url'],
                        json=payload,
                        headers=headers,
                        ssl=False  # Allow self-signed certificates for enterprise
                    ) as response:
                        response_time = (datetime.utcnow() - start_time).total_seconds()
                        
                        if response.status < 400:
                            # Success
                            stats['successful_deliveries'] += 1
                            stats['last_success'] = datetime.utcnow().isoformat()
                            webhook['last_delivery'] = datetime.utcnow().isoformat()
                            webhook['delivery_count'] += 1
                            
                            self.logger.debug(f"Webhook delivered successfully: {webhook['name']} ({response.status})")
                            
                        else:
                            # HTTP error
                            error_text = await response.text()
                            raise Exception(f"HTTP {response.status}: {error_text}")
                        
                        # Update response time average
                        total_deliveries = stats['total_deliveries']
                        current_avg = stats['average_response_time']
                        stats['average_response_time'] = (
                            (current_avg * total_deliveries + response_time) / (total_deliveries + 1)
                        )
            
            stats['total_deliveries'] += 1
            
        except Exception as e:
            # Delivery failed
            stats['failed_deliveries'] += 1
            stats['last_error'] = {
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e)
            }
            webhook['error_count'] += 1
            
            self.logger.error(f"Webhook delivery failed: {webhook['name']} - {e}")
            
            # Add to failed deliveries for retry
            self.failed_deliveries.append({
                'webhook_id': webhook_id,
                'threat_data': threat_data,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat(),
                'retry_count': 0
            })
    
    def prepare_payload(self, webhook: Dict, threat_data: Dict) -> Dict:
        """Prepare webhook payload based on webhook configuration"""
        # Base payload structure
        payload = {
            'event_type': 'threat_detected',
            'timestamp': datetime.utcnow().isoformat(),
            'source': 'GhostSEC',
            'webhook_name': webhook['name'],
            'threat': {
                'id': threat_data.get('hash'),
                'title': threat_data.get('title'),
                'description': threat_data.get('description'),
                'severity': threat_data.get('severity'),
                'category': threat_data.get('category'),
                'source': threat_data.get('source'),
                'url': threat_data.get('url'),
                'timestamp': threat_data.get('timestamp'),
                'iocs': threat_data.get('iocs', []),
                'tags': threat_data.get('tags', [])
            }
        }
        
        # Add ML analysis if available
        if threat_data.get('priority_analysis'):
            payload['threat']['priority_analysis'] = threat_data['priority_analysis']
        
        # Add MISP enrichment if available
        if threat_data.get('misp_enrichment'):
            payload['threat']['misp_enrichment'] = threat_data['misp_enrichment']
        
        # Add correlation data if available
        if threat_data.get('correlations'):
            payload['threat']['correlations'] = threat_data['correlations']
        
        # Platform-specific adaptations
        webhook_name = webhook['name'].lower()
        
        if 'splunk' in webhook_name:
            # Splunk HEC format
            payload = {
                'time': int(datetime.utcnow().timestamp()),
                'source': 'ghostsec',
                'sourcetype': 'threat_intelligence',
                'index': 'security',
                'event': payload
            }
        
        elif 'elasticsearch' in webhook_name:
            # Elasticsearch format
            payload['@timestamp'] = datetime.utcnow().isoformat()
            payload['event'] = {
                'dataset': 'threat_intelligence',
                'module': 'ghostsec'
            }
        
        elif 'qradar' in webhook_name or 'sentinel' in webhook_name:
            # SIEM format (CEF)
            payload['cef_format'] = self.convert_to_cef(threat_data)
        
        return payload
    
    def convert_to_cef(self, threat_data: Dict) -> str:
        """Convert threat data to Common Event Format (CEF)"""
        severity_map = {'low': 1, 'medium': 3, 'high': 7, 'critical': 10}
        severity_numeric = severity_map.get(threat_data.get('severity', 'medium').lower(), 3)
        
        cef = f"CEF:0|GhostSEC|ThreatIntel|1.0|{threat_data.get('category', 'threat')}|{threat_data.get('title', 'Threat Detected')}|{severity_numeric}|"
        
        # Add extension fields
        extensions = []
        
        if threat_data.get('source'):
            extensions.append(f"src={threat_data['source']}")
        
        if threat_data.get('url'):
            extensions.append(f"request={threat_data['url']}")
        
        if threat_data.get('iocs'):
            # Add first few IOCs
            for i, ioc in enumerate(threat_data['iocs'][:3]):
                extensions.append(f"cs{i+1}={ioc}")
        
        if threat_data.get('description'):
            # Truncate description for CEF
            desc = threat_data['description'][:200].replace('|', '\\|').replace('=', '\\=')
            extensions.append(f"msg={desc}")
        
        cef += ' '.join(extensions)
        return cef
    
    def generate_signature(self, payload: Dict, secret: str) -> str:
        """Generate HMAC signature for webhook payload"""
        payload_bytes = json.dumps(payload, sort_keys=True).encode('utf-8')
        signature = hmac.new(
            secret.encode('utf-8'),
            payload_bytes,
            hashlib.sha256
        ).hexdigest()
        return f"sha256={signature}"
    
    async def retry_failed_deliveries(self):
        """Retry failed webhook deliveries"""
        if not self.failed_deliveries:
            return
        
        max_retries = 3
        retry_backoff = [60, 300, 900]  # 1min, 5min, 15min
        
        current_time = datetime.utcnow()
        to_retry = []
        
        for failed_delivery in self.failed_deliveries[:]:
            retry_count = failed_delivery.get('retry_count', 0)
            
            if retry_count >= max_retries:
                # Max retries reached, remove from queue
                self.failed_deliveries.remove(failed_delivery)
                continue
            
            # Check if enough time has passed for retry
            failed_time = datetime.fromisoformat(failed_delivery['timestamp'])
            time_since_failure = (current_time - failed_time).total_seconds()
            
            if time_since_failure >= retry_backoff[retry_count]:
                to_retry.append(failed_delivery)
        
        # Retry deliveries
        for delivery in to_retry:
            delivery['retry_count'] += 1
            await self.delivery_queue.put({
                'webhook_id': delivery['webhook_id'],
                'threat_data': delivery['threat_data'],
                'timestamp': current_time.isoformat()
            })
            
            self.failed_deliveries.remove(delivery)
    
    def get_webhook_stats(self) -> Dict:
        """Get webhook delivery statistics"""
        total_webhooks = len(self.webhooks)
        enabled_webhooks = sum(1 for w in self.webhooks.values() if w.get('enabled', True))
        
        total_deliveries = sum(s['total_deliveries'] for s in self.webhook_stats.values())
        successful_deliveries = sum(s['successful_deliveries'] for s in self.webhook_stats.values())
        failed_deliveries = sum(s['failed_deliveries'] for s in self.webhook_stats.values())
        
        success_rate = (successful_deliveries / total_deliveries * 100) if total_deliveries > 0 else 0
        
        return {
            'total_webhooks': total_webhooks,
            'enabled_webhooks': enabled_webhooks,
            'total_deliveries': total_deliveries,
            'successful_deliveries': successful_deliveries,
            'failed_deliveries': failed_deliveries,
            'success_rate': round(success_rate, 2),
            'pending_retries': len(self.failed_deliveries),
            'queue_size': self.delivery_queue.qsize(),
            'individual_stats': self.webhook_stats
        }
    
    async def start(self):
        """Start the webhook manager"""
        self.running = True
        self.delivery_worker_task = asyncio.create_task(self.delivery_worker())
        self.logger.info("Webhook manager started")
    
    async def stop(self):
        """Stop the webhook manager"""
        self.running = False
        if self.delivery_worker_task:
            self.delivery_worker_task.cancel()
            try:
                await self.delivery_worker_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Webhook manager stopped")


# Create default webhook configuration file
def create_webhook_config():
    """Create default webhook configuration file"""
    config_dir = Path("config")
    config_dir.mkdir(exist_ok=True)
    
    webhook_config = {
        "version": "1.0",
        "description": "GhostSEC Enterprise Webhook Configuration",
        "webhooks": [
            {
                "name": "Security Operations Center",
                "url": "https://your-soc.company.com/api/webhooks/ghostsec",
                "secret": "your_webhook_secret_here",
                "enabled": True,
                "filters": {
                    "min_severity": "medium",
                    "categories": ["malware", "vulnerability", "breach", "apt"],
                    "min_iocs": 1
                },
                "headers": {
                    "X-API-Key": "your_api_key_here"
                }
            },
            {
                "name": "Slack Security Channel",
                "url": "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK",
                "enabled": True,
                "filters": {
                    "min_severity": "high"
                }
            }
        ]
    }
    
    config_file = config_dir / "webhooks.json"
    if not config_file.exists():
        with open(config_file, 'w') as f:
            json.dump(webhook_config, f, indent=2)
        
        print(f"Created webhook configuration template: {config_file}")
        print("Please edit the file with your actual webhook URLs and secrets")