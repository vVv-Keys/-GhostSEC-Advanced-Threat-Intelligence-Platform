"""
Configuration Settings
Centralized configuration management for GhostSEC bot
"""

import os
import json
from pathlib import Path
from typing import List, Dict, Any

class Settings:
    def __init__(self):
        self.config_dir = Path("config")
        self.config_file = self.config_dir / "bot_config.json"
        self.load_settings()
    
    def load_settings(self):
        """Load settings from file and environment variables"""
        # Default settings
        self.defaults = {
            'bot_name': 'GhostSEC',
            'bot_emoji': '👻',
            'command_prefix': '!ghost ',
            'update_interval_minutes': 15,
            'cache_cleanup_hours': 6,
            'stats_report_hours': 24,
            'max_cache_age_days': 7,
            'max_embed_length': 4096,
            'max_field_length': 1024,
            'max_iocs_per_alert': 10,
            'max_tags_per_alert': 15,
            'default_severity': 'medium',
            'rate_limit_delay': 2.0,
            'max_alerts_per_update': 50
        }
        
        # Load from file if exists
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    file_config = json.load(f)
                    self.defaults.update(file_config)
            except Exception as e:
                print(f"Error loading config file: {e}")
        
        # Override with environment variables
        self.load_env_overrides()
        
        # Set attributes
        for key, value in self.defaults.items():
            setattr(self, key.upper(), value)
    
    def load_env_overrides(self):
        """Load settings from environment variables"""
        env_mappings = {
            'GHOSTSEC_UPDATE_INTERVAL': ('update_interval_minutes', int),
            'GHOSTSEC_CACHE_CLEANUP_HOURS': ('cache_cleanup_hours', int),
            'GHOSTSEC_STATS_REPORT_HOURS': ('stats_report_hours', int),
            'GHOSTSEC_MAX_CACHE_AGE_DAYS': ('max_cache_age_days', int),
            'GHOSTSEC_MAX_ALERTS_PER_UPDATE': ('max_alerts_per_update', int),
            'GHOSTSEC_RATE_LIMIT_DELAY': ('rate_limit_delay', float),
            'GHOSTSEC_DEFAULT_SEVERITY': ('default_severity', str),
            'GHOSTSEC_COMMAND_PREFIX': ('command_prefix', str)
        }
        
        for env_var, (setting_key, type_func) in env_mappings.items():
            env_value = os.getenv(env_var)
            if env_value is not None:
                try:
                    self.defaults[setting_key] = type_func(env_value)
                except ValueError:
                    print(f"Invalid value for {env_var}: {env_value}")
    
    def save_settings(self):
        """Save current settings to file"""
        try:
            os.makedirs(self.config_dir, exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(self.defaults, f, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    @property
    def DEFAULT_CHANNELS(self) -> List[str]:
        """Default channel names to look for"""
        return [
            'threat-intel',
            'cybersec-alerts',
            'security-feed',
            'ghost-alerts',
            'cti-feed',
            'general'
        ]
    
    @property
    def SEVERITY_COLORS(self) -> Dict[str, int]:
        """Color codes for different severity levels"""
        return {
            'low': 0x00ff00,      # Green
            'medium': 0xffff00,   # Yellow  
            'high': 0xff8000,     # Orange
            'critical': 0xff0000  # Red
        }
    
    @property
    def CATEGORY_CHANNELS(self) -> Dict[str, str]:
        """Mapping of threat categories to channel names"""
        return {
            'malware': 'malware-alerts',
            'vulnerability': 'vuln-alerts',
            'breach': 'breach-alerts', 
            'phishing': 'phishing-alerts',
            'ransomware': 'ransomware-alerts',
            'apt': 'apt-alerts',
            'general': 'threat-intel',
            'critical': 'critical-alerts'
        }
    
    @property
    def USER_AGENT(self) -> str:
        """User agent string for HTTP requests"""
        return f"GhostSEC-Bot/1.0 (Discord Threat Intelligence Bot)"
    
    @property
    def REQUEST_TIMEOUT(self) -> int:
        """HTTP request timeout in seconds"""
        return int(os.getenv('GHOSTSEC_REQUEST_TIMEOUT', '30'))
    
    @property
    def MAX_CONCURRENT_FEEDS(self) -> int:
        """Maximum number of feeds to process concurrently"""
        return int(os.getenv('GHOSTSEC_MAX_CONCURRENT_FEEDS', '10'))
    
    @property
    def ENABLE_WEBHOOK_LOGGING(self) -> bool:
        """Enable webhook logging for monitoring"""
        return os.getenv('GHOSTSEC_WEBHOOK_LOGGING', 'false').lower() == 'true'
    
    @property
    def WEBHOOK_URL(self) -> str:
        """Webhook URL for external logging"""
        return os.getenv('GHOSTSEC_WEBHOOK_URL', '')
    
    @property
    def DEBUG_MODE(self) -> bool:
        """Enable debug mode"""
        return os.getenv('GHOSTSEC_DEBUG', 'false').lower() == 'true'
    
    def get_api_key(self, service_name: str) -> str:
        """Get API key for a specific service"""
        env_vars = {
            'alienvault': 'ALIENVAULT_API_KEY',
            'virustotal': 'VIRUSTOTAL_API_KEY', 
            'shodan': 'SHODAN_API_KEY',
            'xforce': 'XFORCE_API_KEY',
            'threatconnect': 'THREATCONNECT_API_KEY',
            'misp': 'MISP_API_KEY',
            'opencti': 'OPENCTI_API_KEY'
        }
        
        env_var = env_vars.get(service_name.lower())
        if env_var:
            return os.getenv(env_var, '')
        
        return ''
    
    def update_setting(self, key: str, value: Any):
        """Update a specific setting"""
        if hasattr(self, key.upper()):
            setattr(self, key.upper(), value)
            self.defaults[key.lower()] = value
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Get all current settings"""
        return {
            key: getattr(self, key) 
            for key in dir(self) 
            if key.isupper() and not key.startswith('_')
        }
