"""
Advanced Threat Correlation Engine
Real-time threat correlation and pattern analysis
"""

import networkx as nx
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import logging
import json
import asyncio
from typing import Dict, List, Tuple, Set
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import hashlib

class ThreatCorrelator:
    def __init__(self, max_history=5000):
        self.logger = logging.getLogger(__name__)
        self.max_history = max_history
        
        # Threat storage and indexing
        self.threat_history = []
        self.ioc_index = defaultdict(list)  # IOC -> [threat_ids]
        self.tag_index = defaultdict(list)  # tag -> [threat_ids]
        self.source_index = defaultdict(list)  # source -> [threat_ids]
        self.temporal_index = defaultdict(list)  # time_window -> [threat_ids]
        
        # Correlation graph
        self.correlation_graph = nx.Graph()
        
        # Pattern detection
        self.attack_patterns = {}
        self.campaign_clusters = {}
        self.tactic_sequences = defaultdict(list)
        
        # Text similarity engine
        self.text_vectorizer = TfidfVectorizer(
            max_features=1000,
            stop_words='english',
            ngram_range=(1, 2)
        )
        self.text_corpus = []
        self.text_vectors = None
        
        # Correlation rules
        self.correlation_rules = self.load_correlation_rules()
        
        # Statistics
        self.correlation_stats = {
            'total_correlations': 0,
            'campaign_detections': 0,
            'pattern_matches': 0,
            'temporal_clusters': 0
        }
    
    def add_threat(self, threat_data: Dict) -> Dict:
        """Add new threat and perform correlation analysis"""
        threat_id = threat_data.get('hash') or self.generate_threat_id(threat_data)
        threat_data['correlation_id'] = threat_id
        threat_data['added_timestamp'] = datetime.utcnow().isoformat()
        
        # Add to history
        self.threat_history.insert(0, threat_data)
        if len(self.threat_history) > self.max_history:
            self.cleanup_old_threats()
        
        # Update indices
        self.update_indices(threat_data, threat_id)
        
        # Perform correlation analysis
        correlations = self.correlate_threat(threat_data)
        
        # Update correlation graph
        self.update_correlation_graph(threat_id, correlations)
        
        # Detect patterns and campaigns
        patterns = self.detect_patterns(threat_data, correlations)
        campaigns = self.detect_campaigns(threat_data, correlations)
        
        # Generate correlation report
        correlation_report = {
            'threat_id': threat_id,
            'correlation_score': correlations.get('max_score', 0),
            'related_threats': len(correlations.get('related', [])),
            'pattern_matches': patterns,
            'campaign_indicators': campaigns,
            'temporal_clusters': self.find_temporal_clusters(threat_data),
            'confidence': self.calculate_correlation_confidence(correlations, patterns)
        }
        
        self.logger.info(f"Correlated threat {threat_id}: {correlation_report['related_threats']} related threats")
        
        return correlation_report
    
    def correlate_threat(self, threat_data: Dict) -> Dict:
        """Perform comprehensive threat correlation"""
        correlations = {
            'ioc_correlations': [],
            'textual_correlations': [],
            'temporal_correlations': [],
            'tactical_correlations': [],
            'source_correlations': [],
            'related': [],
            'max_score': 0
        }
        
        # IOC-based correlation
        ioc_correlations = self.correlate_by_iocs(threat_data)
        correlations['ioc_correlations'] = ioc_correlations
        
        # Textual similarity correlation
        text_correlations = self.correlate_by_text_similarity(threat_data)
        correlations['textual_correlations'] = text_correlations
        
        # Temporal correlation
        temporal_correlations = self.correlate_by_temporal_proximity(threat_data)
        correlations['temporal_correlations'] = temporal_correlations
        
        # Tactical correlation (TTPs)
        tactical_correlations = self.correlate_by_tactics(threat_data)
        correlations['tactical_correlations'] = tactical_correlations
        
        # Source correlation
        source_correlations = self.correlate_by_source_patterns(threat_data)
        correlations['source_correlations'] = source_correlations
        
        # Combine all correlations
        all_related = {}
        
        # Weight different correlation types
        weights = {
            'ioc': 0.4,
            'text': 0.2,
            'temporal': 0.15,
            'tactical': 0.15,
            'source': 0.1
        }
        
        for corr_type, weight in weights.items():
            if corr_type == 'ioc':
                related = ioc_correlations
            elif corr_type == 'text':
                related = text_correlations
            elif corr_type == 'temporal':
                related = temporal_correlations
            elif corr_type == 'tactical':
                related = tactical_correlations
            elif corr_type == 'source':
                related = source_correlations
            
            for item in related:
                threat_id = item['threat_id']
                score = item['score'] * weight
                
                if threat_id in all_related:
                    all_related[threat_id]['total_score'] += score
                    all_related[threat_id]['correlation_types'].append(corr_type)
                else:
                    all_related[threat_id] = {
                        'threat_id': threat_id,
                        'total_score': score,
                        'correlation_types': [corr_type],
                        'details': item
                    }
        
        # Sort by score and select top correlations
        sorted_correlations = sorted(
            all_related.values(),
            key=lambda x: x['total_score'],
            reverse=True
        )
        
        correlations['related'] = sorted_correlations[:20]  # Top 20 correlations
        correlations['max_score'] = max([c['total_score'] for c in sorted_correlations], default=0)
        
        return correlations
    
    def correlate_by_iocs(self, threat_data: Dict) -> List[Dict]:
        """Correlate threats based on shared IOCs"""
        threat_iocs = set(threat_data.get('iocs', []))
        if not threat_iocs:
            return []
        
        correlations = []
        related_threats = set()
        
        # Find threats with shared IOCs
        for ioc in threat_iocs:
            for related_id in self.ioc_index.get(ioc, []):
                related_threats.add(related_id)
        
        # Calculate correlation scores
        for related_id in related_threats:
            related_threat = self.get_threat_by_id(related_id)
            if not related_threat:
                continue
            
            related_iocs = set(related_threat.get('iocs', []))
            shared_iocs = threat_iocs & related_iocs
            
            if shared_iocs:
                # IOC correlation score based on Jaccard similarity
                jaccard_score = len(shared_iocs) / len(threat_iocs | related_iocs)
                
                # Boost score for high-value IOCs (hashes, specific IPs)
                high_value_shared = sum(1 for ioc in shared_iocs 
                                      if self.is_high_value_ioc(ioc))
                boost = high_value_shared * 0.2
                
                final_score = min(1.0, jaccard_score + boost)
                
                correlations.append({
                    'threat_id': related_id,
                    'score': final_score,
                    'shared_iocs': list(shared_iocs),
                    'correlation_type': 'ioc_overlap'
                })
        
        return sorted(correlations, key=lambda x: x['score'], reverse=True)
    
    def correlate_by_text_similarity(self, threat_data: Dict) -> List[Dict]:
        """Correlate threats based on textual similarity"""
        threat_text = f"{threat_data.get('title', '')} {threat_data.get('description', '')}"
        if not threat_text.strip():
            return []
        
        correlations = []
        
        try:
            # Add current threat text to corpus
            current_corpus = self.text_corpus + [threat_text]
            
            # Vectorize text
            vectors = self.text_vectorizer.fit_transform(current_corpus)
            current_vector = vectors[-1]
            
            # Calculate similarities
            similarities = cosine_similarity(current_vector, vectors[:-1]).flatten()
            
            # Find high similarity threats
            threshold = 0.3  # Minimum similarity threshold
            
            for i, similarity in enumerate(similarities):
                if similarity >= threshold and i < len(self.threat_history):
                    related_threat = self.threat_history[i]
                    
                    correlations.append({
                        'threat_id': related_threat.get('correlation_id'),
                        'score': float(similarity),
                        'similarity_score': float(similarity),
                        'correlation_type': 'textual_similarity'
                    })
            
        except Exception as e:
            self.logger.debug(f"Error in text correlation: {e}")
        
        return sorted(correlations, key=lambda x: x['score'], reverse=True)[:10]
    
    def correlate_by_temporal_proximity(self, threat_data: Dict) -> List[Dict]:
        """Correlate threats based on temporal proximity"""
        try:
            threat_time = datetime.fromisoformat(threat_data.get('timestamp', ''))
        except:
            threat_time = datetime.utcnow()
        
        correlations = []
        
        # Define time windows for correlation
        time_windows = [
            timedelta(minutes=30),
            timedelta(hours=2),
            timedelta(hours=6),
            timedelta(days=1)
        ]
        
        for window in time_windows:
            window_threats = []
            
            for historical_threat in self.threat_history[:500]:  # Check recent threats
                try:
                    hist_time = datetime.fromisoformat(historical_threat.get('timestamp', ''))
                    time_diff = abs(threat_time - hist_time)
                    
                    if time_diff <= window:
                        window_threats.append((historical_threat, time_diff))
                except:
                    continue
            
            # Score based on temporal proximity and other factors
            for hist_threat, time_diff in window_threats:
                # Base score decreases with time difference
                time_score = 1.0 - (time_diff.total_seconds() / window.total_seconds())
                
                # Boost for same category/severity
                category_boost = 0.2 if (threat_data.get('category') == 
                                       hist_threat.get('category')) else 0
                severity_boost = 0.1 if (threat_data.get('severity') == 
                                       hist_threat.get('severity')) else 0
                
                final_score = min(1.0, time_score + category_boost + severity_boost)
                
                if final_score >= 0.5:  # Minimum threshold
                    correlations.append({
                        'threat_id': hist_threat.get('correlation_id'),
                        'score': final_score,
                        'time_difference': str(time_diff),
                        'correlation_type': 'temporal_proximity'
                    })
        
        return sorted(correlations, key=lambda x: x['score'], reverse=True)[:15]
    
    def correlate_by_tactics(self, threat_data: Dict) -> List[Dict]:
        """Correlate threats based on attack tactics and techniques"""
        threat_tags = set(threat_data.get('tags', []))
        threat_category = threat_data.get('category', '').lower()
        
        # Define tactical patterns
        tactic_groups = {
            'initial_access': ['phishing', 'exploit', 'vulnerability', 'malware'],
            'persistence': ['registry', 'startup', 'scheduled', 'service'],
            'privilege_escalation': ['privilege', 'escalation', 'admin', 'root'],
            'defense_evasion': ['obfuscation', 'encryption', 'steganography', 'bypass'],
            'credential_access': ['credential', 'password', 'keylogger', 'dump'],
            'discovery': ['reconnaissance', 'enumeration', 'scanning', 'discovery'],
            'lateral_movement': ['lateral', 'movement', 'remote', 'psexec'],
            'collection': ['collection', 'data', 'sensitive', 'exfiltration'],
            'exfiltration': ['exfiltration', 'upload', 'transfer', 'steal'],
            'impact': ['ransomware', 'wiper', 'destruction', 'denial']
        }
        
        # Determine threat tactics
        threat_tactics = set()
        for tactic, keywords in tactic_groups.items():
            if any(keyword in threat_tags or keyword in threat_category 
                   for keyword in keywords):
                threat_tactics.add(tactic)
        
        correlations = []
        
        # Find threats with similar tactics
        for historical_threat in self.threat_history[:1000]:
            hist_tags = set(historical_threat.get('tags', []))
            hist_category = historical_threat.get('category', '').lower()
            
            # Determine historical threat tactics
            hist_tactics = set()
            for tactic, keywords in tactic_groups.items():
                if any(keyword in hist_tags or keyword in hist_category 
                       for keyword in keywords):
                    hist_tactics.add(tactic)
            
            # Calculate tactical similarity
            if threat_tactics and hist_tactics:
                shared_tactics = threat_tactics & hist_tactics
                jaccard_score = len(shared_tactics) / len(threat_tactics | hist_tactics)
                
                if jaccard_score >= 0.3:  # Minimum tactical similarity
                    correlations.append({
                        'threat_id': historical_threat.get('correlation_id'),
                        'score': jaccard_score,
                        'shared_tactics': list(shared_tactics),
                        'correlation_type': 'tactical_similarity'
                    })
        
        return sorted(correlations, key=lambda x: x['score'], reverse=True)[:10]
    
    def correlate_by_source_patterns(self, threat_data: Dict) -> List[Dict]:
        """Correlate threats from same or related sources"""
        threat_source = threat_data.get('source', '')
        if not threat_source:
            return []
        
        correlations = []
        
        # Find threats from same source
        for related_id in self.source_index.get(threat_source, []):
            related_threat = self.get_threat_by_id(related_id)
            if related_threat:
                # Score based on source reliability and recency
                source_score = 0.7  # Base score for same source
                
                # Boost for high-reliability sources
                high_reliability_sources = ['us-cert', 'nist', 'sans', 'fireeye']
                if any(source in threat_source.lower() for source in high_reliability_sources):
                    source_score += 0.2
                
                correlations.append({
                    'threat_id': related_id,
                    'score': min(1.0, source_score),
                    'correlation_type': 'source_pattern'
                })
        
        return correlations[:5]  # Limit source correlations
    
    def detect_patterns(self, threat_data: Dict, correlations: Dict) -> List[Dict]:
        """Detect attack patterns and TTPs"""
        patterns = []
        
        # Check for known attack patterns
        for pattern_name, pattern_def in self.correlation_rules.get('patterns', {}).items():
            if self.matches_pattern(threat_data, pattern_def):
                confidence = self.calculate_pattern_confidence(threat_data, pattern_def)
                
                patterns.append({
                    'pattern_name': pattern_name,
                    'pattern_type': pattern_def.get('type', 'generic'),
                    'confidence': confidence,
                    'indicators': pattern_def.get('indicators', [])
                })
        
        # Detect sequential patterns
        sequential_patterns = self.detect_sequential_patterns(threat_data, correlations)
        patterns.extend(sequential_patterns)
        
        self.correlation_stats['pattern_matches'] += len(patterns)
        
        return patterns
    
    def detect_campaigns(self, threat_data: Dict, correlations: Dict) -> List[Dict]:
        """Detect potential threat campaigns"""
        campaigns = []
        
        # Group related threats by similarity
        if correlations.get('related'):
            high_correlation_threats = [
                t for t in correlations['related'] 
                if t['total_score'] >= 0.6
            ]
            
            if len(high_correlation_threats) >= 3:  # Minimum for campaign
                campaign_indicators = self.analyze_campaign_indicators(
                    threat_data, high_correlation_threats
                )
                
                if campaign_indicators['confidence'] >= 0.7:
                    campaigns.append({
                        'campaign_type': 'coordinated_activity',
                        'threat_count': len(high_correlation_threats) + 1,
                        'confidence': campaign_indicators['confidence'],
                        'indicators': campaign_indicators,
                        'timespan': self.calculate_campaign_timespan(high_correlation_threats)
                    })
        
        self.correlation_stats['campaign_detections'] += len(campaigns)
        
        return campaigns
    
    def find_temporal_clusters(self, threat_data: Dict) -> List[Dict]:
        """Find temporal clusters of related threats"""
        try:
            threat_time = datetime.fromisoformat(threat_data.get('timestamp', ''))
        except:
            return []
        
        clusters = []
        time_window = timedelta(hours=1)
        
        # Find threats in time window
        cluster_threats = []
        for threat in self.threat_history[:100]:
            try:
                hist_time = datetime.fromisoformat(threat.get('timestamp', ''))
                if abs(threat_time - hist_time) <= time_window:
                    cluster_threats.append(threat)
            except:
                continue
        
        if len(cluster_threats) >= 3:  # Minimum cluster size
            cluster_analysis = self.analyze_temporal_cluster(cluster_threats)
            clusters.append(cluster_analysis)
            
            self.correlation_stats['temporal_clusters'] += 1
        
        return clusters
    
    def update_indices(self, threat_data: Dict, threat_id: str):
        """Update correlation indices with new threat"""
        # IOC index
        for ioc in threat_data.get('iocs', []):
            self.ioc_index[ioc].append(threat_id)
        
        # Tag index
        for tag in threat_data.get('tags', []):
            self.tag_index[tag].append(threat_id)
        
        # Source index
        if threat_data.get('source'):
            self.source_index[threat_data['source']].append(threat_id)
        
        # Temporal index
        try:
            threat_time = datetime.fromisoformat(threat_data.get('timestamp', ''))
            time_key = threat_time.strftime('%Y-%m-%d-%H')  # Hourly buckets
            self.temporal_index[time_key].append(threat_id)
        except:
            pass
        
        # Update text corpus
        threat_text = f"{threat_data.get('title', '')} {threat_data.get('description', '')}"
        if threat_text.strip():
            self.text_corpus.insert(0, threat_text)
            if len(self.text_corpus) > 1000:  # Limit corpus size
                self.text_corpus = self.text_corpus[:1000]
    
    def update_correlation_graph(self, threat_id: str, correlations: Dict):
        """Update the threat correlation graph"""
        # Add node for current threat
        self.correlation_graph.add_node(threat_id)
        
        # Add edges to related threats
        for related in correlations.get('related', []):
            related_id = related['threat_id']
            score = related['total_score']
            
            if score >= 0.5:  # Minimum edge weight
                self.correlation_graph.add_edge(
                    threat_id, related_id, 
                    weight=score,
                    correlation_types=related.get('correlation_types', [])
                )
    
    def get_threat_by_id(self, threat_id: str) -> Dict:
        """Get threat data by correlation ID"""
        for threat in self.threat_history:
            if threat.get('correlation_id') == threat_id:
                return threat
        return None
    
    def is_high_value_ioc(self, ioc: str) -> bool:
        """Determine if IOC is high-value for correlation"""
        # File hashes are high-value
        if re.match(r'^[a-fA-F0-9]{32,64}$', ioc):
            return True
        
        # Specific IP addresses (not common ranges)
        if re.match(r'^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$', ioc):
            # Exclude common private/reserved ranges
            private_ranges = ['192.168.', '10.', '172.16.', '127.', '169.254.']
            if not any(ioc.startswith(pr) for pr in private_ranges):
                return True
        
        # Specific domains (not common TLDs)
        if '.' in ioc and not ioc.endswith(('.com', '.org', '.net')):
            return True
        
        return False
    
    def generate_threat_id(self, threat_data: Dict) -> str:
        """Generate unique threat ID"""
        content = f"{threat_data.get('title', '')}{threat_data.get('description', '')}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def calculate_correlation_confidence(self, correlations: Dict, patterns: List[Dict]) -> float:
        """Calculate overall correlation confidence"""
        base_confidence = min(0.8, correlations.get('max_score', 0))
        
        # Boost for multiple correlation types
        correlation_types = set()
        for related in correlations.get('related', []):
            correlation_types.update(related.get('correlation_types', []))
        
        type_boost = len(correlation_types) * 0.05
        
        # Boost for pattern matches
        pattern_boost = len(patterns) * 0.1
        
        return min(1.0, base_confidence + type_boost + pattern_boost)
    
    def cleanup_old_threats(self):
        """Clean up old threats and update indices"""
        # Remove oldest threats
        while len(self.threat_history) > self.max_history:
            old_threat = self.threat_history.pop()
            old_id = old_threat.get('correlation_id')
            
            # Clean up indices
            for ioc in old_threat.get('iocs', []):
                if old_id in self.ioc_index[ioc]:
                    self.ioc_index[ioc].remove(old_id)
                    if not self.ioc_index[ioc]:
                        del self.ioc_index[ioc]
            
            # Clean up other indices similarly...
            # (Simplified for brevity)
    
    def get_correlation_statistics(self) -> Dict:
        """Get correlation engine statistics"""
        return {
            **self.correlation_stats,
            'threat_history_size': len(self.threat_history),
            'ioc_index_size': len(self.ioc_index),
            'correlation_graph_nodes': self.correlation_graph.number_of_nodes(),
            'correlation_graph_edges': self.correlation_graph.number_of_edges(),
            'text_corpus_size': len(self.text_corpus)
        }
    
    def load_correlation_rules(self) -> Dict:
        """Load correlation rules and patterns"""
        # Default correlation rules
        return {
            'patterns': {
                'apt_campaign': {
                    'type': 'advanced_persistent_threat',
                    'indicators': ['apt', 'targeted', 'sophisticated', 'persistence'],
                    'min_indicators': 2
                },
                'ransomware_campaign': {
                    'type': 'ransomware',
                    'indicators': ['ransomware', 'encryption', 'payment', 'bitcoin'],
                    'min_indicators': 1
                }
            }
        }
    
    def matches_pattern(self, threat_data: Dict, pattern_def: Dict) -> bool:
        """Check if threat matches a correlation pattern"""
        indicators = pattern_def.get('indicators', [])
        min_indicators = pattern_def.get('min_indicators', 1)
        
        threat_text = f"{threat_data.get('title', '')} {threat_data.get('description', '')}".lower()
        threat_tags = [tag.lower() for tag in threat_data.get('tags', [])]
        
        matched_indicators = 0
        for indicator in indicators:
            if (indicator.lower() in threat_text or 
                indicator.lower() in threat_tags):
                matched_indicators += 1
        
        return matched_indicators >= min_indicators
    
    def calculate_pattern_confidence(self, threat_data: Dict, pattern_def: Dict) -> float:
        """Calculate confidence score for pattern match"""
        # Simplified confidence calculation
        return 0.8  # Placeholder
    
    def detect_sequential_patterns(self, threat_data: Dict, correlations: Dict) -> List[Dict]:
        """Detect sequential attack patterns"""
        # Placeholder for sequential pattern detection
        return []
    
    def analyze_campaign_indicators(self, threat_data: Dict, related_threats: List[Dict]) -> Dict:
        """Analyze indicators for potential threat campaign"""
        # Simplified campaign analysis
        return {'confidence': 0.8, 'indicators': []}
    
    def calculate_campaign_timespan(self, threats: List[Dict]) -> str:
        """Calculate timespan of potential campaign"""
        return "24 hours"  # Placeholder
    
    def analyze_temporal_cluster(self, threats: List[Dict]) -> Dict:
        """Analyze temporal cluster of threats"""
        return {
            'cluster_size': len(threats),
            'time_window': '1 hour',
            'cluster_type': 'temporal_burst'
        }